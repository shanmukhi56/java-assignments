/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import HeroBanner from './components/HeroBanner';
import PolicyCatalog from './components/PolicyCatalog';
import PolicyCalculator from './components/PolicyCalculator';
import ClaimPortal from './components/ClaimPortal';
import CustomerDashboard from './components/CustomerDashboard';
import FaqAndBranches from './components/FaqAndBranches';
import AiAdvisorModal from './components/AiAdvisorModal';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import CheckoutPaymentModal from './components/CheckoutPaymentModal';
import PaymentReceiptModal from './components/PaymentReceiptModal';
import TaxCertificateModal from './components/TaxCertificateModal';
import AdminDashboardView from './components/AdminDashboardView';
import { 
  getCurrentCustomerProfile, 
  setCurrentAuthenticatedUser,
  getActiveSupabaseUser,
  signOutCustomer,
  getCustomerPolicies, 
  getCustomerPayments, 
  getCustomerClaims, 
  createCustomerClaim,
  supabase
} from './services/supabase';
import { Claim, CustomerProfile, PaymentTransaction, UserPolicy } from './types';
import { Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'plans' | 'calculator' | 'claims' | 'dashboard' | 'payments' | 'admin' | 'faq'>('plans');
  
  // Current Authenticated Customer
  const [currentCustomer, setCurrentCustomer] = useState<CustomerProfile | null>(null);
  
  // Customer-scoped reactive data
  const [userPolicies, setUserPolicies] = useState<UserPolicy[]>([]);
  const [payments, setPayments] = useState<PaymentTransaction[]>([]);
  const [claims, setClaims] = useState<Claim[]>([]);
  
  // Modals
  const [isAiAdvisorOpen, setIsAiAdvisorOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'admin'>('login');
  const [checkoutPolicy, setCheckoutPolicy] = useState<UserPolicy | null>(null);
  const [viewingReceipt, setViewingReceipt] = useState<PaymentTransaction | null>(null);
  const [isTaxModalOpen, setIsTaxModalOpen] = useState<boolean>(false);

  // Reload customer data strictly scoped to active customer ID
  const reloadData = useCallback(() => {
    const cust = getCurrentCustomerProfile();
    setCurrentCustomer(cust);

    if (cust) {
      const pols = getCustomerPolicies(cust.id);
      const pmts = getCustomerPayments(cust.id);
      const clms = getCustomerClaims(cust.id);
      setUserPolicies(pols);
      setPayments(pmts);
      setClaims(clms);
    } else {
      setUserPolicies([]);
      setPayments([]);
      setClaims([]);
    }
  }, []);

  // Initialize on mount & bind Supabase Auth Session listener
  useEffect(() => {
    let authSubscription: any = null;

    // Check initial active session
    getActiveSupabaseUser().then((cust) => {
      setCurrentCustomer(cust);
      if (cust) {
        setUserPolicies(getCustomerPolicies(cust.id));
        setPayments(getCustomerPayments(cust.id));
        setClaims(getCustomerClaims(cust.id));
      } else {
        setUserPolicies([]);
        setPayments([]);
        setClaims([]);
      }
    });

    if (supabase) {
      const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
        if (session?.user) {
          const cust = await getActiveSupabaseUser();
          setCurrentCustomer(cust);
          if (cust) {
            setUserPolicies(getCustomerPolicies(cust.id));
            setPayments(getCustomerPayments(cust.id));
            setClaims(getCustomerClaims(cust.id));
          }
        } else {
          const stored = getCurrentCustomerProfile();
          setCurrentCustomer(stored);
          if (stored) {
            setUserPolicies(getCustomerPolicies(stored.id));
            setPayments(getCustomerPayments(stored.id));
            setClaims(getCustomerClaims(stored.id));
          } else {
            setUserPolicies([]);
            setPayments([]);
            setClaims([]);
          }
        }
      });
      authSubscription = subscription;
    }

    return () => {
      if (authSubscription) {
        authSubscription.unsubscribe();
      }
    };
  }, []);

  // Open Auth Modal in specific mode
  const handleOpenAuth = (mode: 'login' | 'register' | 'admin' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  // Handle switching or registering user
  const handleSelectCustomer = (customer: CustomerProfile) => {
    setCurrentAuthenticatedUser(customer);
    setCurrentCustomer(customer);
    setUserPolicies(getCustomerPolicies(customer.id));
    setPayments(getCustomerPayments(customer.id));
    setClaims(getCustomerClaims(customer.id));
    setIsAuthModalOpen(false);
  };

  // Immediate logout returning to unauthenticated header state
  const handleSignOut = () => {
    signOutCustomer();
    setCurrentCustomer(null);
    setUserPolicies([]);
    setPayments([]);
    setClaims([]);
    if (activeTab === 'admin') {
      setActiveTab('plans');
    }
  };

  // Handle starting purchase from catalog or calculator
  const handleInitiatePolicyCheckout = (policy: UserPolicy) => {
    if (!currentCustomer) {
      handleOpenAuth('register');
      return;
    }
    setCheckoutPolicy(policy);
  };

  // Callback when purchase & initial payment succeeds
  const handlePolicyPurchaseSuccess = (purchasedPolicy: UserPolicy, transaction: PaymentTransaction) => {
    reloadData();
    setCheckoutPolicy(null);
    setViewingReceipt(transaction);
  };

  // Handle filing a new claim
  const handleAddNewClaim = async (newClaim: Claim) => {
    if (currentCustomer) {
      await createCustomerClaim(currentCustomer, newClaim);
      reloadData();
    }
  };

  const handleSelectPlanForCalculation = (planId: string) => {
    setActiveTab('calculator');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F9FA] text-[#1E293B] font-['Roboto',sans-serif]">
      {/* Institutional Top Navbar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openAiAdvisor={() => setIsAiAdvisorOpen(true)}
        claimCount={claims.length}
        userPolicyCount={userPolicies.length}
        customer={currentCustomer}
        onOpenAuth={handleOpenAuth}
        onSignOut={handleSignOut}
      />

      {/* Hero Banner for main landing */}
      {activeTab === 'plans' && (
        <HeroBanner
          onNavigate={(tab) => setActiveTab(tab as any)}
          openAiAdvisor={() => setIsAiAdvisorOpen(true)}
        />
      )}

      {/* Main Dynamic View Content */}
      <main className="flex-1">
        {activeTab === 'plans' && (
          <PolicyCatalog
            onSelectPlanForCalculation={handleSelectPlanForCalculation}
            onQuickBuy={handleInitiatePolicyCheckout}
          />
        )}

        {activeTab === 'calculator' && (
          <PolicyCalculator
            onBuyPolicy={handleInitiatePolicyCheckout}
            onNavigateToClaims={() => setActiveTab('claims')}
          />
        )}

        {activeTab === 'claims' && (
          <ClaimPortal
            claims={claims}
            userPolicies={userPolicies}
            customer={currentCustomer}
            onAddNewClaim={handleAddNewClaim}
          />
        )}

        {activeTab === 'dashboard' && (
          <CustomerDashboard
            customer={currentCustomer}
            userPolicies={userPolicies}
            payments={payments}
            onRefreshData={reloadData}
            onNavigateToCalculator={() => setActiveTab('calculator')}
            onNavigateToClaims={() => setActiveTab('claims')}
            onOpenReceipt={(payment) => setViewingReceipt(payment)}
            onOpenTaxCertificate={() => setIsTaxModalOpen(true)}
            onOpenAuth={() => handleOpenAuth('login')}
          />
        )}

        {activeTab === 'admin' && (
          <AdminDashboardView
            onOpenReceipt={(payment) => setViewingReceipt(payment)}
          />
        )}

        {activeTab === 'faq' && (
          <FaqAndBranches
            openAiAdvisor={() => setIsAiAdvisorOpen(true)}
          />
        )}
      </main>

      {/* Institutional Footer */}
      <Footer onNavigate={(tab) => setActiveTab(tab as any)} />

      {/* Floating AI Advisor Action Button */}
      <button
        onClick={() => setIsAiAdvisorOpen(true)}
        className="fixed bottom-6 right-6 z-40 p-3.5 sm:px-5 sm:py-3 rounded-full bg-gradient-to-r from-amber-400 via-[#F3BA2F] to-amber-500 hover:brightness-110 active:scale-95 text-[#002B5C] font-extrabold shadow-2xl flex items-center gap-2 border-2 border-white/80 transition-all group no-print"
        aria-label="Ask SmartInsure AI Advisor"
      >
        <Sparkles className="w-5 h-5 fill-[#002B5C] group-hover:rotate-12 transition-transform" />
        <span className="hidden sm:inline text-xs tracking-wide">
          Ask AI Advisor
        </span>
      </button>

      {/* AI Insurance Advisor Modal */}
      <AiAdvisorModal
        isOpen={isAiAdvisorOpen}
        onClose={() => setIsAiAdvisorOpen(false)}
      />

      {/* Auth / Profile Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentCustomer={currentCustomer}
        onLoginSuccess={handleSelectCustomer}
        initialMode={authModalMode}
      />

      {/* Checkout / Payment Modal */}
      {checkoutPolicy && currentCustomer && (
        <CheckoutPaymentModal
          isOpen={!!checkoutPolicy}
          onClose={() => setCheckoutPolicy(null)}
          customer={currentCustomer}
          policyInput={{
            policyId: checkoutPolicy.policyId,
            policyName: checkoutPolicy.policyName,
            category: checkoutPolicy.category,
            sumAssured: checkoutPolicy.sumAssured,
            baseAnnualPremium: checkoutPolicy.premiumAmount,
            policyTermYears: 20,
            premiumPayingTermYears: checkoutPolicy.totalInstallments || 15,
            taxSection: checkoutPolicy.taxBenefitSection || 'Section 80C'
          }}
          onPaymentSuccess={handlePolicyPurchaseSuccess}
          onOpenReceipt={(payment) => setViewingReceipt(payment)}
        />
      )}

      {/* Payment Receipt Modal */}
      <PaymentReceiptModal
        isOpen={!!viewingReceipt}
        onClose={() => setViewingReceipt(null)}
        payment={viewingReceipt}
        customer={currentCustomer}
      />

      {/* Tax Certificate Modal */}
      <TaxCertificateModal
        isOpen={isTaxModalOpen}
        onClose={() => setIsTaxModalOpen(false)}
        customer={currentCustomer}
        payments={payments}
      />
    </div>
  );
}
