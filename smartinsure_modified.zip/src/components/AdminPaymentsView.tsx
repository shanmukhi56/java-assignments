import { useState, useMemo } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  FileText, 
  Download, 
  TrendingUp, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  Calendar,
  Building,
  RefreshCw
} from 'lucide-react';
import { PaymentStatus, PaymentTransaction } from '../types';
import { getAllSystemPayments } from '../services/supabase';

interface AdminPaymentsViewProps {
  onOpenReceipt: (payment: PaymentTransaction) => void;
}

export default function AdminPaymentsView({ onOpenReceipt }: AdminPaymentsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | PaymentStatus>('ALL');
  const [refreshKey, setRefreshKey] = useState(0);

  const allPayments = useMemo(() => {
    return getAllSystemPayments();
  }, [refreshKey]);

  const filteredPayments = useMemo(() => {
    return allPayments.filter(p => {
      const matchSearch =
        p.transactionReference.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.policyNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.policyName.toLowerCase().includes(searchTerm.toLowerCase());

      const matchStatus = statusFilter === 'ALL' || p.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [allPayments, searchTerm, statusFilter]);

  // Aggregate metrics computed ONLY from real transactions
  const totalVolume = allPayments
    .filter(p => p.status === 'SUCCESS')
    .reduce((sum, p) => sum + p.totalAmount, 0);

  const successfulCount = allPayments.filter(p => p.status === 'SUCCESS').length;
  const failedCount = allPayments.filter(p => p.status === 'FAILED').length;
  const totalGstCollected = allPayments
    .filter(p => p.status === 'SUCCESS')
    .reduce((sum, p) => sum + p.gstAmount, 0);

  const handleExportCsv = () => {
    if (filteredPayments.length === 0) return;

    const headers = ['Txn Reference', 'Receipt Number', 'Date', 'Customer Name', 'Customer Email', 'PAN', 'Policy Number', 'Policy Name', 'Method', 'Bank UTR', 'Base Amount', 'GST Amount', 'Total Amount', 'Tax Section', 'Status'];
    const rows = filteredPayments.map(p => [
      p.transactionReference,
      p.receiptNumber,
      new Date(p.paymentDate).toISOString(),
      `"${p.customerName.replace(/"/g, '""')}"`,
      p.customerEmail,
      p.customerPan || '',
      p.policyNumber,
      `"${p.policyName.replace(/"/g, '""')}"`,
      p.paymentMethod,
      p.bankRefNumber || '',
      p.baseAmount,
      p.gstAmount,
      p.totalAmount,
      p.taxDeductionSection,
      p.status
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SmartInsure_Treasury_Ledger_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header Banner */}
      <div className="bg-[#002B5C] text-white p-6 rounded-2xl shadow-lg border-b-4 border-[#F3BA2F] flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase bg-[#F3BA2F] text-[#002B5C] px-2 py-0.5 rounded">
              Institutional Admin
            </span>
            <span className="text-xs text-amber-200">IRDAI Audit &amp; Central Reconciliation</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black font-['Poppins'] mt-1">
            Real-Time System Payments &amp; Treasury Ledger
          </h2>
          <p className="text-xs text-slate-300">
            Consolidated ledger of authenticated customer transactions and premium credits.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 rounded-xl bg-[#F3BA2F] hover:bg-amber-400 text-[#002B5C] font-bold text-xs flex items-center gap-2 transition-all shadow"
            title="Download CSV Ledger"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setRefreshKey(prev => prev + 1)}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-2 transition-all border border-white/10"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync Treasury</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Total Settled Volume</span>
          <p className="text-xl font-black text-[#002B5C] font-['Poppins']">
            ₹{totalVolume.toLocaleString('en-IN')}
          </p>
          <p className="text-[10px] text-emerald-600 font-bold">✓ 100% Real Authenticated Records</p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Successful Transactions</span>
          <p className="text-xl font-black text-emerald-700 font-['Poppins']">
            {successfulCount}
          </p>
          <p className="text-[10px] text-slate-400">Captured by Bank Gateways</p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Declined / Failed Txns</span>
          <p className="text-xl font-black text-rose-700 font-['Poppins']">
            {failedCount}
          </p>
          <p className="text-[10px] text-slate-400">Simulated / Gateway Errors</p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Statutory GST Remittance (18%)</span>
          <p className="text-xl font-black text-slate-800 font-['Poppins']">
            ₹{totalGstCollected.toLocaleString('en-IN')}
          </p>
          <p className="text-[10px] text-blue-600 font-semibold">Government Revenue Account</p>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search by Txn Ref, Receipt #, Customer Name, Email, PAN or Policy..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-500" />
          <span className="text-xs font-bold text-slate-600">Status:</span>
          {(['ALL', 'SUCCESS', 'FAILED'] as const).map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                statusFilter === st
                  ? 'bg-[#002B5C] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* All Transactions Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {filteredPayments.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <FileText className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">No payment transactions found</h4>
            <p className="text-xs text-slate-500">
              Transactions performed by customers will appear in this central audit log.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#002B5C] text-white text-[10px] uppercase font-bold tracking-wider">
                <tr>
                  <th className="p-3">Txn Reference &amp; Receipt #</th>
                  <th className="p-3">Customer (Assessee)</th>
                  <th className="p-3">Policy Particulars</th>
                  <th className="p-3">Method &amp; Bank UTR</th>
                  <th className="p-3">Tax Clause</th>
                  <th className="p-3 text-right">Amount (INR)</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredPayments.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3">
                      <p className="font-bold text-[#002B5C] font-mono">{p.transactionReference}</p>
                      <p className="text-[10px] text-slate-500 font-mono">Rec: {p.receiptNumber}</p>
                      <p className="text-[10px] text-slate-400">
                        {new Date(p.paymentDate).toLocaleString('en-IN', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </td>

                    <td className="p-3">
                      <p className="font-bold text-slate-900">{p.customerName}</p>
                      <p className="text-[10px] text-slate-500">{p.customerEmail}</p>
                      {p.customerPan && (
                        <span className="font-mono text-[10px] bg-slate-100 px-1 py-0.5 rounded font-bold text-slate-700">
                          PAN: {p.customerPan}
                        </span>
                      )}
                    </td>

                    <td className="p-3">
                      <p className="font-bold text-slate-800">{p.policyName}</p>
                      <p className="text-[10px] font-mono text-slate-500">{p.policyNumber}</p>
                      <span className="text-[9px] uppercase font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
                        {p.planCategory}
                      </span>
                    </td>

                    <td className="p-3">
                      <p className="font-semibold text-slate-700">{p.paymentMethod}</p>
                      <p className="text-[10px] font-mono text-slate-400 truncate max-w-[140px]">
                        {p.bankRefNumber || 'Direct Gateway'}
                      </p>
                    </td>

                    <td className="p-3">
                      <span className="font-bold text-emerald-800 text-[11px]">
                        {p.taxDeductionSection}
                      </span>
                    </td>

                    <td className="p-3 text-right">
                      <p className="font-bold text-slate-900 text-sm font-['Poppins']">
                        ₹{p.totalAmount.toLocaleString('en-IN')}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        (Base: ₹{p.baseAmount.toLocaleString('en-IN')} + GST)
                      </p>
                    </td>

                    <td className="p-3 text-center">
                      <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        p.status === 'SUCCESS'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {p.status === 'SUCCESS' ? '✓ SUCCESS' : '✕ FAILED'}
                      </span>
                    </td>

                    <td className="p-3 text-center">
                      <button
                        onClick={() => onOpenReceipt(p)}
                        className="px-2.5 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold text-[11px] flex items-center gap-1 mx-auto transition-all"
                        title="View Official Receipt"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Receipt</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
