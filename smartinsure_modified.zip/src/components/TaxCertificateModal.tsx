import { useState } from 'react';
import { 
  Shield, 
  X, 
  Printer, 
  Award, 
  FileText, 
  Calendar, 
  CheckCircle2,
  AlertCircle,
  Download,
  Loader2
} from 'lucide-react';
import { CustomerProfile, PaymentTransaction } from '../types';
import { downloadElementAsPdf, triggerPrintDialog } from '../utils/pdfDownloader';

interface TaxCertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: CustomerProfile | null;
  payments: PaymentTransaction[];
}

export default function TaxCertificateModal({
  isOpen,
  onClose,
  customer,
  payments
}: TaxCertificateModalProps) {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  if (!isOpen) return null;

  // Filter only successful payments belonging to this customer
  const successfulPayments = payments.filter(p => p.status === 'SUCCESS');

  // Sum eligible amounts
  const totalPaid80C = successfulPayments
    .filter(p => p.taxDeductionSection.includes('80C') || p.taxDeductionSection.includes('80CCC'))
    .reduce((sum, p) => sum + p.totalAmount, 0);

  const totalPaid80D = successfulPayments
    .filter(p => p.taxDeductionSection.includes('80D'))
    .reduce((sum, p) => sum + p.totalAmount, 0);

  const grandTotal = totalPaid80C + totalPaid80D;

  const currentYear = new Date().getFullYear();
  const financialYear = `FY ${currentYear - 1}-${currentYear.toString().slice(-2)}`;
  const assessmentYear = `AY ${currentYear}-${(currentYear + 1).toString().slice(-2)}`;

  const handleDownloadPdf = async () => {
    await downloadElementAsPdf(
      'tax-certificate-document',
      `SmartInsure_Tax_Certificate_FY_${currentYear - 1}_${currentYear}`,
      setIsGeneratingPdf
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 print:p-0 print:bg-white print:static">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border-4 border-[#002B5C] overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in printable-document print:border-2 print:border-slate-800 print:max-h-none print:shadow-none print:rounded-none">
        {/* Header Bar (Hidden in print) */}
        <div className="bg-[#002B5C] text-white p-4 px-6 flex items-center justify-between border-b-4 border-[#F3BA2F] no-print">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base font-['Poppins']">
                Annual Income Tax Exemption Certificate
              </h3>
              <p className="text-xs text-amber-200">
                Under Section 80C, 80CCC &amp; 80D of the Income Tax Act, 1961
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {successfulPayments.length > 0 && (
              <>
                <button
                  onClick={handleDownloadPdf}
                  disabled={isGeneratingPdf}
                  className="px-3.5 py-1.5 rounded-lg bg-[#F3BA2F] hover:bg-amber-400 text-[#002B5C] text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 disabled:opacity-50"
                  title="Download PDF directly"
                >
                  {isGeneratingPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{isGeneratingPdf ? 'Exporting...' : 'Download PDF'}</span>
                </button>

                <button
                  onClick={triggerPrintDialog}
                  className="px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
                  title="Print Tax Certificate"
                >
                  <Printer className="w-4 h-4 text-[#F3BA2F]" />
                  <span className="hidden sm:inline">Print</span>
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Body */}
        <div 
          id="tax-certificate-document"
          className="p-8 overflow-y-auto space-y-6 text-xs text-slate-700 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:16px_16px] printable-content print:p-6 print:overflow-visible print:bg-white"
        >
          {/* ZERO PAYMENTS HANDLING */}
          {successfulPayments.length === 0 ? (
            <div className="p-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-bold text-[#002B5C] font-['Poppins']">
                No Eligible Tax Receipt Available
              </h4>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                You haven't made any premium payments in the current financial year ({financialYear}) under account <strong>{customer?.fullName || 'Active User'}</strong>. Once you buy a policy or pay a renewal premium, your verified statutory Form 80C/80D certificate will be generated here automatically.
              </p>
              <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-[#002B5C] text-[#F3BA2F] font-bold text-xs shadow hover:bg-[#001D40] transition-all"
              >
                Return to Dashboard
              </button>
            </div>
          ) : (
            <>
              {/* Institutional Header */}
              <div className="text-center pb-4 border-b-2 border-slate-300">
                <p className="text-base font-black text-[#002B5C] font-['Poppins'] uppercase tracking-wide">
                  SmartInsure National Life Assurance Corporation of India
                </p>
                <p className="text-lg font-black text-slate-900 font-['Poppins'] mt-1">
                  PREMIUM PAID CERTIFICATE FOR INCOME TAX EXEMPTION
                </p>
                <p className="text-xs font-bold text-slate-600 mt-0.5">
                  Financial Year: <span className="text-[#002B5C]">{financialYear}</span> | Assessment Year: <span className="text-[#002B5C]">{assessmentYear}</span>
                </p>
                <p className="text-[10px] text-slate-400 mt-1">
                  Issued under Rule 21AA of Income Tax Rules 1962 &amp; IRDAI Circular 2025/TAX/771
                </p>
              </div>

              {/* Assessee (Customer) Profile Box */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Name of Assessee (Policyholder)</p>
                  <p className="font-bold text-slate-900 text-sm">{customer?.fullName || 'Registered Policyholder'}</p>
                  <p className="text-slate-500 text-[11px] mt-0.5">{customer?.email}</p>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Permanent Account Number (PAN)</p>
                  <p className="font-mono font-bold text-[#002B5C] text-sm">{customer?.panNumber || 'N/A'}</p>
                  <p className="text-slate-500 text-[11px] mt-0.5">{customer?.address || 'India'}</p>
                </div>
              </div>

              {/* Payments Table */}
              <div className="border border-slate-300 rounded-xl overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-[#002B5C] text-white text-[10px] uppercase">
                    <tr>
                      <th className="p-2.5">Policy No. &amp; Plan</th>
                      <th className="p-2.5">Transaction ID &amp; Date</th>
                      <th className="p-2.5">Eligible Section</th>
                      <th className="p-2.5 text-right">Premium (INR)</th>
                      <th className="p-2.5 text-right">GST 18%</th>
                      <th className="p-2.5 text-right">Total Paid (INR)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white text-xs">
                    {successfulPayments.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50/50">
                        <td className="p-2.5">
                          <p className="font-bold text-slate-900 font-mono text-[11px]">{p.policyNumber}</p>
                          <p className="text-[10px] text-slate-500">{p.policyName}</p>
                        </td>
                        <td className="p-2.5">
                          <p className="font-mono text-[11px] text-[#002B5C]">{p.transactionReference}</p>
                          <p className="text-[10px] text-slate-500">
                            {new Date(p.paymentDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                          </p>
                        </td>
                        <td className="p-2.5">
                          <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
                            {p.taxDeductionSection}
                          </span>
                        </td>
                        <td className="p-2.5 text-right font-mono">
                          ₹{p.baseAmount.toLocaleString('en-IN')}
                        </td>
                        <td className="p-2.5 text-right font-mono text-slate-500">
                          ₹{p.gstAmount.toLocaleString('en-IN')}
                        </td>
                        <td className="p-2.5 text-right font-mono font-bold text-slate-900">
                          ₹{p.totalAmount.toLocaleString('en-IN')}
                        </td>
                      </tr>
                    ))}

                    <tr className="bg-slate-100 font-bold border-t-2 border-slate-300">
                      <td colSpan={3} className="p-3 text-[#002B5C] font-['Poppins']">
                        Total Eligible Deduction under Chapter VI-A (Income Tax Act)
                      </td>
                      <td colSpan={3} className="p-3 text-right text-base font-black text-[#002B5C] font-['Poppins']">
                        ₹{grandTotal.toLocaleString('en-IN')}.00
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Tax Notes */}
              <div className="space-y-1.5 p-3.5 bg-blue-50/70 rounded-xl border border-blue-200 text-[11px] text-blue-950">
                <p className="font-bold text-blue-900">Actuarial Tax Exemption Clauses:</p>
                <p>1. Life insurance premium paid up to ₹1,50,000 qualifies for deduction under <strong>Section 80C / 80CCC</strong>.</p>
                <p>2. Health insurance premiums qualify under <strong>Section 80D</strong> up to ₹25,000 (individual/family) or ₹50,000/₹75,000 (senior citizens).</p>
                <p>3. All maturity proceeds and sum assured death claims are 100% exempt from income tax under <strong>Section 10(10D)</strong>.</p>
              </div>

              {/* Digital Seal */}
              <div className="flex items-center justify-between pt-4 border-t-2 border-slate-200">
                <div className="flex items-center gap-2">
                  <Award className="w-8 h-8 text-[#002B5C]" />
                  <div>
                    <p className="text-[10px] font-bold uppercase text-slate-400">Digital Tax Seal</p>
                    <p className="text-xs font-bold text-slate-800">SmartInsure Tax Compliance Cell</p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="font-serif italic font-bold text-slate-800 text-sm">V. K. Shrivastava</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Authorized Signatory &amp; Actuary</p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
