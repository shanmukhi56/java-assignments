import { useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import {
  ShieldCheck, FileCheck2, ClipboardCheck, Clock3, XCircle, CheckCircle2,
  Search, RefreshCw, Eye, ChevronRight, AlertTriangle, UserRound, FileText
} from 'lucide-react';
import { Claim } from '../types';
import { getAllSystemClaims, updateSystemClaimDocument, updateSystemClaimDecision } from '../services/supabase';
import AdminPaymentsView from './AdminPaymentsView';

interface Props { onOpenReceipt: (payment: any) => void; }
type Section = 'overview' | 'verification' | 'approvals' | 'payments';

export default function AdminDashboardView({ onOpenReceipt }: Props) {
  const [section, setSection] = useState<Section>('overview');
  const [refresh, setRefresh] = useState(0);
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<Claim | null>(null);

  const claims = useMemo(() => getAllSystemClaims(), [refresh]);
  const pendingDocs = claims.reduce((n, c) => n + c.documents.filter(d => d.status === 'Pending Review' || d.status === 'Required').length, 0);
  const verifiedDocs = claims.reduce((n, c) => n + c.documents.filter(d => d.status === 'Verified').length, 0);
  const pendingApprovals = claims.filter(c => !['Approved', 'Settled', 'Rejected'].includes(c.status)).length;
  const approved = claims.filter(c => c.status === 'Approved' || c.status === 'Settled').length;

  const filtered = claims.filter(c => {
    const q = query.toLowerCase();
    return !q || [c.claimNumber, c.policyNumber, c.policyHolderName, c.claimType].some(v => v.toLowerCase().includes(q));
  });

  const refreshAll = () => { setSelected(null); setRefresh(v => v + 1); };

  const verifyDocument = (claim: Claim, index: number, status: 'Verified' | 'Required') => {
    updateSystemClaimDocument(claim.id, index, status);
    setSelected({ ...claim, documents: claim.documents.map((d, i) => i === index ? { ...d, status } : d) });
    setRefresh(v => v + 1);
  };

  const decide = (claim: Claim, decision: 'Approved' | 'Rejected') => {
    updateSystemClaimDecision(claim.id, decision);
    setSelected({ ...claim, status: decision });
    setRefresh(v => v + 1);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-6 animate-in fade-in">
      <div className="bg-[#002B5C] text-white rounded-2xl p-6 shadow-xl border-b-4 border-[#F3BA2F]">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-purple-400/15 text-purple-200 text-[10px] font-bold uppercase tracking-wider mb-2">
              <ShieldCheck className="w-3.5 h-3.5" /> Institutional Administration
            </div>
            <h2 className="text-2xl sm:text-3xl font-black font-['Poppins']">SmartInsure Admin Control Center</h2>
            <p className="text-sm text-slate-300 mt-1">Review customer documents, verify KYC/claim evidence, and approve or reject applications.</p>
          </div>
          <button onClick={refreshAll} className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold">
            <RefreshCw className="w-4 h-4" /> Refresh records
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Metric icon={<Clock3 />} label="Pending approvals" value={pendingApprovals} />
        <Metric icon={<FileCheck2 />} label="Documents to review" value={pendingDocs} />
        <Metric icon={<CheckCircle2 />} label="Verified documents" value={verifiedDocs} />
        <Metric icon={<ClipboardCheck />} label="Approved claims" value={approved} />
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-2 flex flex-wrap gap-2">
        {([
          ['overview', 'Dashboard'], ['verification', 'Document Verification'], ['approvals', 'Approval Module'], ['payments', 'Treasury & Payments']
        ] as [Section, string][]).map(([key, label]) => (
          <button key={key} onClick={() => setSection(key)} className={`px-4 py-2.5 rounded-xl text-xs font-bold transition ${section === key ? 'bg-[#002B5C] text-white' : 'text-slate-600 hover:bg-slate-100'}`}>
            {label}
          </button>
        ))}
      </div>

      {section === 'payments' ? <AdminPaymentsView onOpenReceipt={onOpenReceipt} /> : section === 'overview' ? (
        <div className="grid lg:grid-cols-3 gap-5">
          <QuickCard title="Document Verification" value={pendingDocs} description="Uploaded evidence awaiting an administrator review." onClick={() => setSection('verification')} icon={<FileCheck2 />} />
          <QuickCard title="Approval Queue" value={pendingApprovals} description="Claims currently progressing through review and audit." onClick={() => setSection('approvals')} icon={<ClipboardCheck />} />
          <QuickCard title="Risk Alerts" value={claims.filter(c => c.documents.some(d => d.status === 'Required')).length} description="Records with required or incomplete documents." onClick={() => setSection('verification')} icon={<AlertTriangle />} />
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row gap-3 md:items-center justify-between">
            <div>
              <h3 className="font-bold text-[#002B5C] font-['Poppins']">{section === 'verification' ? 'Document Verification Queue' : 'Claim Approval Queue'}</h3>
              <p className="text-xs text-slate-500 mt-1">Select a record to inspect documents and update its decision.</p>
            </div>
            <div className="relative w-full md:w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search claim, policy, customer..." className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-xs outline-none focus:ring-2 focus:ring-[#002B5C]" />
            </div>
          </div>
          {filtered.length === 0 ? (
            <div className="p-12 text-center text-slate-500"><FileText className="w-10 h-10 mx-auto mb-3 text-slate-300" /><p className="font-bold text-slate-700">No records found</p><p className="text-xs mt-1">New customer claims will automatically appear here.</p></div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filtered.map(claim => <ClaimRow key={claim.id} claim={claim} onOpen={() => setSelected(claim)} />)}
            </div>
          )}
        </div>
      )}

      {selected && <ReviewDrawer claim={selected} onClose={() => setSelected(null)} onVerify={verifyDocument} onDecide={decide} />}
    </div>
  );
}

function Metric({ icon, label, value }: { icon: ReactNode; label: string; value: number }) {
  return <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm"><div className="w-9 h-9 rounded-xl bg-blue-50 text-[#002B5C] flex items-center justify-center mb-3">{icon}</div><div className="text-2xl font-black text-[#002B5C]">{value}</div><div className="text-[11px] font-bold text-slate-500 uppercase tracking-wide mt-1">{label}</div></div>;
}
function QuickCard({ title, value, description, onClick, icon }: any) {
  return <button onClick={onClick} className="text-left bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition"><div className="flex justify-between"><span className="w-10 h-10 rounded-xl bg-slate-100 text-[#002B5C] flex items-center justify-center">{icon}</span><ChevronRight className="w-5 h-5 text-slate-400" /></div><div className="text-2xl font-black text-[#002B5C] mt-5">{value}</div><h3 className="font-bold text-slate-800 mt-1">{title}</h3><p className="text-xs text-slate-500 mt-1 leading-relaxed">{description}</p></button>;
}
function ClaimRow({ claim, onOpen }: { claim: Claim; onOpen: () => void }) {
  const pending = claim.documents.filter(d => d.status !== 'Verified').length;
  return <div className="p-4 sm:p-5 flex flex-col md:flex-row md:items-center gap-4"><div className="flex-1 min-w-0"><div className="flex items-center gap-2 flex-wrap"><span className="font-bold text-[#002B5C] text-sm">{claim.claimNumber}</span><span className="text-[10px] px-2 py-1 rounded-full bg-slate-100 text-slate-600 font-bold">{claim.status}</span></div><div className="flex flex-wrap gap-3 mt-2 text-xs text-slate-500"><span className="inline-flex items-center gap-1"><UserRound className="w-3.5 h-3.5" />{claim.policyHolderName}</span><span>Policy: {claim.policyNumber}</span><span>{claim.claimType}</span></div></div><div className="flex items-center gap-3"><div className={`text-xs font-bold ${pending ? 'text-amber-700' : 'text-emerald-700'}`}>{pending ? `${pending} document${pending > 1 ? 's' : ''} pending` : 'All documents verified'}</div><button onClick={onOpen} className="px-3 py-2 rounded-lg bg-[#002B5C] text-white text-xs font-bold inline-flex items-center gap-1.5"><Eye className="w-3.5 h-3.5" /> Review</button></div></div>;
}
function ReviewDrawer({ claim, onClose, onVerify, onDecide }: { claim: Claim; onClose: () => void; onVerify: (c: Claim, i: number, s: 'Verified' | 'Required') => void; onDecide: (c: Claim, d: 'Approved' | 'Rejected') => void }) {
  return <div className="fixed inset-0 z-[80] bg-slate-900/50 flex justify-end" onClick={onClose}><aside onClick={e => e.stopPropagation()} className="w-full max-w-xl h-full bg-white shadow-2xl overflow-y-auto"><div className="sticky top-0 bg-[#002B5C] text-white p-5 flex items-center justify-between z-10"><div><p className="text-[10px] uppercase tracking-wider text-amber-300 font-bold">Review record</p><h3 className="font-black text-lg">{claim.claimNumber}</h3></div><button onClick={onClose} className="text-white/80 hover:text-white text-2xl">×</button></div><div className="p-5 space-y-6"><div className="bg-slate-50 rounded-xl p-4"><div className="text-sm font-bold text-slate-800">{claim.policyHolderName}</div><div className="text-xs text-slate-500 mt-1">{claim.claimType} · ₹{claim.claimAmount.toLocaleString('en-IN')} · Policy {claim.policyNumber}</div></div><section><h4 className="font-bold text-[#002B5C] mb-3">Document Verification</h4><div className="space-y-3">{claim.documents.map((doc, i) => <div key={`${doc.name}-${i}`} className="border border-slate-200 rounded-xl p-4"><div className="flex items-start justify-between gap-3"><div><div className="text-sm font-bold text-slate-800">{doc.name}</div><div className="text-[11px] text-slate-500 mt-1">{doc.type}</div></div><span className={`text-[10px] px-2 py-1 rounded-full font-bold ${doc.status === 'Verified' ? 'bg-emerald-100 text-emerald-700' : doc.status === 'Required' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>{doc.status}</span></div><div className="flex gap-2 mt-3"><button onClick={() => onVerify(claim, i, 'Verified')} className="flex-1 py-2 rounded-lg bg-emerald-600 text-white text-xs font-bold"><CheckCircle2 className="w-3.5 h-3.5 inline mr-1" /> Verify</button><button onClick={() => onVerify(claim, i, 'Required')} className="flex-1 py-2 rounded-lg bg-red-50 text-red-700 border border-red-200 text-xs font-bold"><XCircle className="w-3.5 h-3.5 inline mr-1" /> Request again</button></div></div>)}</div></section><section className="border-t border-slate-200 pt-5"><h4 className="font-bold text-[#002B5C] mb-2">Final Approval</h4><p className="text-xs text-slate-500 mb-3">Approve only after all required documents are verified. Rejection should be used when the claim/application fails review.</p><div className="grid grid-cols-2 gap-3"><button onClick={() => onDecide(claim, 'Rejected')} className="py-3 rounded-xl border border-red-200 bg-red-50 text-red-700 font-bold text-xs"><XCircle className="w-4 h-4 inline mr-1" /> Reject</button><button onClick={() => onDecide(claim, 'Approved')} disabled={claim.documents.some(d => d.status !== 'Verified')} className="py-3 rounded-xl bg-emerald-600 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold text-xs"><CheckCircle2 className="w-4 h-4 inline mr-1" /> Approve claim</button></div></section></div></aside></div>;
}
