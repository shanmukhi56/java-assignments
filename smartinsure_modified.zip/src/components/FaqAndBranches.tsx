import { useState } from 'react';
import { 
  HelpCircle, 
  MapPin, 
  Phone, 
  Clock, 
  ChevronDown, 
  ChevronUp, 
  ShieldCheck, 
  MessageSquare, 
  Building2,
  FileQuestion,
  ExternalLink
} from 'lucide-react';
import { FAQS, BRANCH_OFFICES } from '../data/mockData';

interface FaqAndBranchesProps {
  openAiAdvisor: () => void;
}

export default function FaqAndBranches({ openAiAdvisor }: FaqAndBranchesProps) {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-12">
      {/* FAQ Section */}
      <div>
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#002B5C]/10 text-[#002B5C] text-xs font-bold mb-2">
            <HelpCircle className="w-3.5 h-3.5 text-[#F3BA2F]" />
            Frequently Asked Questions &amp; Guidelines
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold font-['Poppins'] text-[#002B5C]">
            Insurance Policies, Claims &amp; Tax Rules
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Everything you need to know regarding policy underwriting, claim processing, tax exemptions, and policy loans.
          </p>
        </div>

        <div className="max-w-3xl mx-auto space-y-3">
          {FAQS.map((faq, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm transition-all"
              >
                <button
                  onClick={() => toggleFaq(idx)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 font-bold text-sm text-[#002B5C] hover:bg-slate-50 transition-colors"
                >
                  <span className="font-['Poppins']">{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-[#F3BA2F] shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* AI Helper Banner */}
        <div className="max-w-3xl mx-auto mt-6 p-5 rounded-2xl bg-gradient-to-r from-[#002B5C] to-[#003875] text-white flex flex-wrap items-center justify-between gap-4 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-sm font-['Poppins']">Have a specific insurance query?</p>
              <p className="text-xs text-slate-300">Ask our SmartInsure AI Actuary for instant personalized advice.</p>
            </div>
          </div>
          <button
            onClick={openAiAdvisor}
            className="px-4 py-2 rounded-xl bg-[#F3BA2F] hover:bg-amber-400 text-[#002B5C] font-bold text-xs shadow transition-all"
          >
            Launch AI Advisor
          </button>
        </div>
      </div>

      {/* Branch & Zonal Offices Network */}
      <div className="pt-8 border-t border-slate-200">
        <div className="mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold mb-2">
            <Building2 className="w-3.5 h-3.5 text-emerald-700" />
            Nationwide Institutional Branch Network
          </div>
          <h3 className="text-2xl font-bold font-['Poppins'] text-[#002B5C]">
            Divisional &amp; Zonal Service Centers
          </h3>
          <p className="text-xs text-slate-600 mt-1">
            Walk into any of our 2,000+ branch centers or connect directly with our regional service officers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {BRANCH_OFFICES.map((branch, i) => (
            <div
              key={i}
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-[#002B5C]/40 transition-all space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#002B5C] px-2 py-0.5 bg-blue-50 rounded">
                  {branch.city}
                </span>
                <MapPin className="w-4 h-4 text-rose-600" />
              </div>

              <h4 className="font-bold text-xs text-slate-800 font-['Poppins']">
                {branch.type}
              </h4>

              <p className="text-[11px] text-slate-500 leading-relaxed">
                {branch.address}
              </p>

              <div className="pt-2 border-t border-slate-100 text-[11px] space-y-1 text-slate-600">
                <div className="flex items-center gap-1.5 font-medium">
                  <Phone className="w-3 h-3 text-[#002B5C]" />
                  <span>{branch.phone}</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>{branch.timing}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
