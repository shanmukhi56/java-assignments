import { useState, useId } from 'react';
import { 
  ShieldCheck, 
  CreditCard, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Lock, 
  ArrowRight, 
  Building, 
  QrCode, 
  Smartphone, 
  FileText, 
  Printer, 
  Sparkles,
  Download,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { CustomerProfile, PaymentMethod, PaymentTransaction, UserPolicy } from '../types';
import { processPolicyPurchaseAndPayment, PolicyPurchaseInput } from '../services/supabase';

interface CheckoutPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer: CustomerProfile;
  policyInput: {
    policyId: string;
    policyName: string;
    category: string;
    sumAssured: number;
    baseAnnualPremium: number;
    policyTermYears: number;
    premiumPayingTermYears: number;
    taxSection: string;
  };
  onPaymentSuccess: (policy: UserPolicy, payment: PaymentTransaction) => void;
  onOpenReceipt: (payment: PaymentTransaction) => void;
}

export default function CheckoutPaymentModal({
  isOpen,
  onClose,
  customer,
  policyInput,
  onPaymentSuccess,
  onOpenReceipt
}: CheckoutPaymentModalProps) {
  // Step in Checkout: 1: Details & Method -> 2: Success
  const [step, setStep] = useState<'checkout' | 'processing' | 'success' | 'failed'>('checkout');
  
  // Nominee Details
  const [nomineeName, setNomineeName] = useState('Immediate Family Nominee');
  const [nomineeRelation, setNomineeRelation] = useState('Spouse (100% Share)');

  // Payment Selection
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [upiVpa, setUpiVpa] = useState(`${customer.email.split('@')[0]}@okaxis`);
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8842');
  const [cardExpiry, setCardExpiry] = useState('08/29');
  const [cardCvv, setCardCvv] = useState('•••');
  const [cardHolder, setCardHolder] = useState(customer.fullName);

  // Failure simulation toggle (for testing failed payment flows per prompt requirements)
  const [simulateFailure, setSimulateFailure] = useState(false);

  // Completed objects
  const [completedPolicy, setCompletedPolicy] = useState<UserPolicy | null>(null);
  const [completedPayment, setCompletedPayment] = useState<PaymentTransaction | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Submitting guard to prevent duplicate payment submissions
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const basePremium = policyInput.baseAnnualPremium;
  const gstAmount = Math.round(basePremium * 0.18);
  const totalAmount = basePremium + gstAmount;

  const handlePayNow = async () => {
    if (isProcessing) return; // Prevent duplicate clicks
    setIsProcessing(true);
    setStep('processing');
    setErrorMessage(null);

    const purchaseData: PolicyPurchaseInput = {
      policyId: policyInput.policyId,
      policyName: policyInput.policyName,
      category: policyInput.category,
      sumAssured: policyInput.sumAssured,
      premiumAmount: basePremium,
      gstAmount: gstAmount,
      totalAmount: totalAmount,
      premiumFrequency: 'Yearly',
      policyTermYears: policyInput.policyTermYears,
      premiumPayingTermYears: policyInput.premiumPayingTermYears,
      nomineeName: nomineeName.trim() || 'Designated Family Nominee',
      nomineeRelation: nomineeRelation.trim() || 'Immediate Family',
      paymentMethod: paymentMethod,
      taxSection: policyInput.taxSection,
      simulateFailure: simulateFailure
    };

    // Realistic processing delay for bank gateway handshake
    setTimeout(async () => {
      const res = await processPolicyPurchaseAndPayment(customer, purchaseData);
      setIsProcessing(false);

      if (res.success && res.policy && res.payment) {
        setCompletedPolicy(res.policy);
        setCompletedPayment(res.payment);
        setStep('success');
        onPaymentSuccess(res.policy, res.payment);
      } else {
        setStep('failed');
        setErrorMessage(res.error || 'Payment failed. Please try again.');
        if (res.payment) {
          setCompletedPayment(res.payment);
        }
      }
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border-2 border-[#002B5C] overflow-hidden max-h-[90vh] flex flex-col animate-in fade-in">
        {/* Gateway Header */}
        <div className="bg-[#002B5C] text-white p-5 flex items-center justify-between border-b-2 border-[#F3BA2F]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold shadow-md">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base font-['Poppins']">
                  SmartInsure Official Payment Gateway
                </h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded border border-emerald-400/30">
                  256-Bit SSL Encrypted
                </span>
              </div>
              <p className="text-xs text-amber-200">
                Payer: <strong>{customer.fullName}</strong> ({customer.email}) • PAN: {customer.panNumber}
              </p>
            </div>
          </div>

          {step !== 'processing' && (
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* STEP 1: CHECKOUT & PAYMENT METHOD SELECTION */}
        {step === 'checkout' && (
          <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-700">
            {/* Policy & Amount Breakdown Box */}
            <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50/50 rounded-2xl border border-blue-200/80 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-blue-200/60 pb-2">
                <div>
                  <span className="text-[10px] font-bold uppercase text-blue-900 bg-blue-100 px-2 py-0.5 rounded">
                    {policyInput.category} Assurance Plan
                  </span>
                  <h4 className="text-sm font-bold text-[#002B5C] font-['Poppins'] mt-1">
                    {policyInput.policyName}
                  </h4>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-slate-500">Life Sum Assured:</span>
                  <p className="text-sm font-black text-slate-900 font-['Poppins']">
                    ₹{policyInput.sumAssured.toLocaleString('en-IN')}
                  </p>
                </div>
              </div>

              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between text-slate-600">
                  <span>Annual Base Premium:</span>
                  <span className="font-semibold text-slate-800">₹{basePremium.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Statutory GST @ 18% (CGST 9% + SGST 9%):</span>
                  <span className="font-semibold text-slate-800">₹{gstAmount.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Section Tax Exemption:</span>
                  <span className="font-bold text-emerald-700">{policyInput.taxSection}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-blue-200 text-sm">
                  <span className="font-bold text-[#002B5C]">Total Amount Payable Now:</span>
                  <span className="font-black text-lg text-[#002B5C] font-['Poppins']">
                    ₹{totalAmount.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            </div>

            {/* Nominee Details Section */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                Designated Policy Nominee (Beneficiary)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Nominee Full Name *</label>
                  <input
                    type="text"
                    required
                    value={nomineeName}
                    onChange={e => setNomineeName(e.target.value)}
                    placeholder="e.g. Priya Sharma"
                    className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Relationship to Policyholder *</label>
                  <select
                    value={nomineeRelation}
                    onChange={e => setNomineeRelation(e.target.value)}
                    className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-[#002B5C]"
                  >
                    <option value="Spouse (100% Share)">Spouse (100% Share)</option>
                    <option value="Child / Son (100% Share)">Child / Son (100% Share)</option>
                    <option value="Child / Daughter (100% Share)">Child / Daughter (100% Share)</option>
                    <option value="Mother (100% Share)">Mother (100% Share)</option>
                    <option value="Father (100% Share)">Father (100% Share)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                Select Secure Payment Method
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'UPI', label: 'Instant UPI', icon: Smartphone },
                  { id: 'Credit / Debit Card', label: 'Cards (Visa/MC)', icon: CreditCard },
                  { id: 'Net Banking', label: 'NetBanking', icon: Building },
                  { id: 'NEFT / RTGS', label: 'Bank NEFT', icon: ShieldCheck }
                ].map(m => {
                  const Icon = m.icon;
                  const active = paymentMethod === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPaymentMethod(m.id as any)}
                      className={`p-3 rounded-xl border text-center font-bold text-xs flex flex-col items-center gap-1.5 transition-all ${
                        active
                          ? 'bg-[#002B5C] text-white border-[#002B5C] shadow-sm'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${active ? 'text-[#F3BA2F]' : 'text-slate-500'}`} />
                      <span className="text-[11px]">{m.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Sub-panels for selected method */}
              {paymentMethod === 'UPI' && (
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 animate-in fade-in">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Enter UPI Virtual Payment Address (VPA / ID)
                    </label>
                    <input
                      type="text"
                      value={upiVpa}
                      onChange={e => setUpiVpa(e.target.value)}
                      placeholder="username@okhdfcbank"
                      className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-[#002B5C]"
                    />
                    <p className="text-[10px] text-slate-400 mt-1">
                      Google Pay, PhonePe, Paytm, BHIM, Cred, Amazon Pay supported.
                    </p>
                  </div>
                </div>
              )}

              {paymentMethod === 'Credit / Debit Card' && (
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 animate-in fade-in">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Card Number</label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={e => setCardNumber(e.target.value)}
                      className="w-full text-xs font-mono font-semibold p-2.5 rounded-xl border border-slate-300 bg-white"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-600 mb-1">Expiry Date</label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={e => setCardExpiry(e.target.value)}
                        className="w-full text-xs font-mono p-2 rounded-lg border border-slate-300 bg-white text-center"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-600 mb-1">CVV Code</label>
                      <input
                        type="password"
                        maxLength={3}
                        value={cardCvv}
                        onChange={e => setCardCvv(e.target.value)}
                        className="w-full text-xs font-mono p-2 rounded-lg border border-slate-300 bg-white text-center"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-600 mb-1">Cardholder Name</label>
                      <input
                        type="text"
                        value={cardHolder}
                        onChange={e => setCardHolder(e.target.value)}
                        className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                      />
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'Net Banking' && (
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 animate-in fade-in">
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Select Bank</label>
                  <select
                    value={selectedBank}
                    onChange={e => setSelectedBank(e.target.value)}
                    className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-[#002B5C]"
                  >
                    <option value="HDFC Bank">HDFC Bank (Instant NEFT / IMPS)</option>
                    <option value="State Bank of India">State Bank of India (SBI)</option>
                    <option value="ICICI Bank">ICICI Bank</option>
                    <option value="Axis Bank">Axis Bank</option>
                    <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                    <option value="Punjab National Bank">Punjab National Bank</option>
                  </select>
                </div>
              )}

              {paymentMethod === 'NEFT / RTGS' && (
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5 text-slate-600">
                  <p className="font-bold text-[#002B5C]">Virtual Escrow Account Details:</p>
                  <p>Bank: <strong>Reserve Bank Clearing Gateway (SmartInsure)</strong></p>
                  <p>A/C Number: <strong className="font-mono">SMARTIN-{customer.panNumber}</strong></p>
                  <p>IFSC Code: <strong className="font-mono">SMAR0000001</strong></p>
                </div>
              )}
            </div>

            {/* Test Simulation Controls (for user testing failed state) */}
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-700" />
                <span className="text-[11px] text-amber-900 font-semibold">
                  Test Gateway Error Response:
                </span>
              </div>
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={simulateFailure}
                  onChange={e => setSimulateFailure(e.target.checked)}
                  className="w-4 h-4 accent-rose-600"
                />
                <span className="text-[11px] font-bold text-rose-800">
                  Simulate Bank Failure
                </span>
              </label>
            </div>
          </div>
        )}

        {/* STEP: PROCESSING ANIMATION */}
        {step === 'processing' && (
          <div className="p-12 text-center space-y-4">
            <div className="w-16 h-16 rounded-full border-4 border-[#002B5C] border-t-[#F3BA2F] animate-spin mx-auto"></div>
            <h4 className="text-base font-bold text-[#002B5C] font-['Poppins']">
              Connecting with Central Banking Gateway...
            </h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Please do not refresh or hit the back button. Authorizing payment of ₹{totalAmount.toLocaleString('en-IN')} for {customer.fullName}.
            </p>
          </div>
        )}

        {/* STEP: SUCCESS CONFIRMATION */}
        {step === 'success' && completedPayment && completedPolicy && (
          <div className="p-8 overflow-y-auto space-y-6 text-center animate-in fade-in">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                Transaction Successful • Status: 100% COMPLETED
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#002B5C] font-['Poppins'] mt-2">
                Policy Bond Issued &amp; Activated Instantly!
              </h3>
              <p className="text-xs text-slate-600 mt-1 max-w-md mx-auto">
                Your payment of <strong>₹{completedPayment.totalAmount.toLocaleString('en-IN')}</strong> has been received. Your digital policy bond is now live in your vault.
              </p>
            </div>

            {/* Docket summary card */}
            <div className="max-w-md mx-auto bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Transaction Reference:</span>
                <strong className="font-mono text-[#002B5C]">{completedPayment.transactionReference}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Official Receipt Number:</span>
                <strong className="font-mono text-emerald-700">{completedPayment.receiptNumber}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Allocated Policy Number:</span>
                <strong className="font-mono text-slate-900">{completedPolicy.policyNumber}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Policyholder Name:</span>
                <span className="font-bold text-slate-800">{customer.fullName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Bank Settlement UTR:</span>
                <span className="font-mono text-[11px] text-slate-700">{completedPayment.bankRefNumber}</span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenReceipt(completedPayment);
                }}
                className="px-5 py-2.5 rounded-xl bg-[#002B5C] hover:bg-[#001D40] text-[#F3BA2F] font-bold text-xs shadow flex items-center gap-1.5 transition-all active:scale-95"
              >
                <Printer className="w-4 h-4 text-[#F3BA2F]" />
                <span>View &amp; Print Official Receipt</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs transition-all"
              >
                Go to My Policies Portfolio
              </button>
            </div>
          </div>
        )}

        {/* STEP: PAYMENT FAILED */}
        {step === 'failed' && (
          <div className="p-8 text-center space-y-6 animate-in fade-in">
            <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-10 h-10" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold">
                Transaction Status: FAILED
              </span>
              <h3 className="text-xl font-bold text-rose-900 font-['Poppins'] mt-2">
                Payment Failed. Please Try Again.
              </h3>
              <p className="text-xs text-rose-700 mt-1 max-w-sm mx-auto">
                {errorMessage || 'The bank gateway rejected the transaction. No amount has been deducted from your account.'}
              </p>
            </div>

            <div className="pt-2 flex justify-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setSimulateFailure(false);
                  setStep('checkout');
                }}
                className="px-5 py-2.5 rounded-xl bg-[#002B5C] text-[#F3BA2F] font-bold text-xs shadow flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Payment</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* FOOTER ACTIONS (Only on Checkout Step) */}
        {step === 'checkout' && (
          <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-4">
            <div>
              <p className="text-[10px] text-slate-500">Amount Payable</p>
              <p className="text-base font-black text-[#002B5C] font-['Poppins']">
                ₹{totalAmount.toLocaleString('en-IN')}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-200 font-bold text-xs"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={isProcessing}
                onClick={handlePayNow}
                className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:scale-[0.98] text-white font-bold text-xs shadow-md flex items-center gap-2 transition-all disabled:opacity-50"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Authorize &amp; Pay ₹{totalAmount.toLocaleString('en-IN')}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
