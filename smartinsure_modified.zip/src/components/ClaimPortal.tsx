import { useState, FormEvent, ChangeEvent } from 'react';
import { 
  FileText, 
  Search, 
  PlusCircle, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  User, 
  Phone, 
  Calendar, 
  ArrowRight, 
  FileCheck, 
  ShieldCheck, 
  UploadCloud, 
  BadgeAlert,
  Building,
  Check,
  ChevronRight,
  Printer,
  Sparkles,
  Award,
  X,
  Download,
  Loader2
} from 'lucide-react';
import { Claim, CustomerProfile, UserPolicy } from '../types';
import { downloadElementAsPdf, triggerPrintDialog } from '../utils/pdfDownloader';

interface ClaimPortalProps {
  claims: Claim[];
  userPolicies: UserPolicy[];
  customer?: CustomerProfile | null;
  onAddNewClaim: (claim: Claim) => void;
}

export default function ClaimPortal({ claims, userPolicies, customer, onAddNewClaim }: ClaimPortalProps) {
  const [activeSubTab, setActiveSubTab] = useState<'track' | 'file'>('track');
  const [selectedClaimNumber, setSelectedClaimNumber] = useState<string>(
    claims[0]?.claimNumber || ''
  );
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedClaimForReport, setSelectedClaimForReport] = useState<Claim | null>(null);
  const [isGeneratingClaimPdf, setIsGeneratingClaimPdf] = useState(false);

  // Form State for filing a new claim
  const [formPolicyNumber, setFormPolicyNumber] = useState<string>(
    userPolicies[0]?.policyNumber || ''
  );
  const [formHolderName, setFormHolderName] = useState<string>(customer?.fullName || '');
  const [formClaimType, setFormClaimType] = useState<Claim['claimType']>('Hospitalization Reimbursement');
  const [formAmount, setFormAmount] = useState<number>(50000);
  const [formDate, setFormDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [formHospital, setFormHospital] = useState<string>('');
  const [formNotes, setFormNotes] = useState<string>('');
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<Claim | null>(null);

  // Active claim object to track
  const currentClaim = (claims.find(
    c => c.claimNumber.toLowerCase() === selectedClaimNumber.toLowerCase()
  ) || claims[0]) || null;

  // Submit Handler
  const handleSubmitNewClaim = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const generatedClaimNumber = `CLM-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const todayFormatted = new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });

      const estDate = new Date();
      estDate.setDate(estDate.getDate() + 5);
      const estFormatted = estDate.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });

      const matchedPolicy = userPolicies.find(p => p.policyNumber === formPolicyNumber);
      const customerId = customer?.id || matchedPolicy?.customerId || 'cust-authenticated';

      const newClaimObj: Claim = {
        id: `clm-${Date.now()}`,
        customerId: customerId,
        claimNumber: generatedClaimNumber,
        policyNumber: formPolicyNumber || 'POL-GENERAL',
        policyHolderName: formHolderName || customer?.fullName || 'Verified Policyholder',
        claimType: formClaimType,
        claimAmount: formAmount,
        dateOfIncident: formDate,
        dateSubmitted: new Date().toISOString().split('T')[0],
        status: 'Document Verification',
        stageNumber: 2,
        estimatedSettlementDate: estFormatted,
        hospitalOrPlace: formHospital || 'Registered Medical Facility',
        assignedSurveyor: {
          name: 'Rajesh Nair (Sr. Claims Auditor)',
          phone: '+91 98450 11982',
          badgeId: 'SURV-INSP-8831'
        },
        timeline: [
          {
            title: 'Claim Registered Online',
            date: `${todayFormatted}, 10:00 AM`,
            description: 'Digital claim intimation token generated with automatic pre-authorization check.',
            completed: true
          },
          {
            title: 'Document & Invoice Assessment',
            date: 'In Progress (Active Stage)',
            description: 'Uploaded medical vouchers and doctor discharge summary under automated OCR verification.',
            completed: false,
            current: true
          },
          {
            title: 'Surveyor / Medical Audit',
            date: `Scheduled within 48 Hours`,
            description: 'Hospital desk cross-check and medical ledger inspection.',
            completed: false
          },
          {
            title: 'TPA Final Clearance',
            date: `Expected ${estFormatted}`,
            description: 'Final claim amount adjudication and settlement note generation.',
            completed: false
          },
          {
            title: 'Settlement & NEFT Fund Transfer',
            date: `Expected ${estFormatted}`,
            description: 'Direct credit to policyholder registered bank account.',
            completed: false
          }
        ],
        documents: uploadedFiles.length > 0 ? uploadedFiles.map(name => ({
          name,
          type: 'Uploaded Document',
          status: 'Pending Review'
        })) : [
          { name: 'Hospital Discharge Summary', type: 'Medical Report', status: 'Verified' },
          { name: 'Final Pharmacy Bills & Invoices', type: 'Billing Document', status: 'Pending Review' },
          { name: 'Bank Account Cancelled Cheque', type: 'Banking Info', status: 'Verified' }
        ],
        notes: formNotes
      };

      onAddNewClaim(newClaimObj);
      setIsSubmitting(false);
      setSubmissionSuccess(newClaimObj);
      setSelectedClaimNumber(newClaimObj.claimNumber);
      setActiveSubTab('track');
    }, 900);
  };

  const handleSimulateFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const fileName = e.target.files[0].name;
      setUploadedFiles(prev => [...prev, fileName]);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
      {/* Title & Stats Strip */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Express Claim Redressal SLA • 98.92% Settlement Ratio
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold font-['Poppins'] text-[#002B5C]">
            Smart Claim Center &amp; Live Tracking
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Track multi-stage surveyor and TPA audit progression, or intimate a new cashless/reimbursement claim.
          </p>
        </div>

        {/* Action Toggle Switch */}
        <div className="bg-slate-200/80 p-1 rounded-xl flex items-center gap-1">
          <button
            onClick={() => setActiveSubTab('track')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeSubTab === 'track'
                ? 'bg-[#002B5C] text-white shadow-md'
                : 'text-slate-700 hover:text-[#002B5C]'
            }`}
          >
            Live Claim Status Tracker
          </button>
          <button
            onClick={() => setActiveSubTab('file')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeSubTab === 'file'
                ? 'bg-emerald-700 text-white shadow-md'
                : 'text-slate-700 hover:text-emerald-800'
            }`}
          >
            + Intimate / File New Claim
          </button>
        </div>
      </div>

      {/* SUB-VIEW 1: LIVE TRACKER */}
      {activeSubTab === 'track' && (
        <div className="space-y-8">
          {claims.length === 0 ? (
            <div className="p-12 text-center bg-slate-50/80 rounded-2xl border-2 border-dashed border-slate-300 space-y-4">
              <div className="w-16 h-16 rounded-full bg-blue-100 text-[#002B5C] flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-bold text-[#002B5C] font-['Poppins']">
                No Active Claims Registered
              </h4>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                You currently have no claim intimations in progress. When you register a cashless hospitalization, critical illness payout, or maturity claim, live status updates and surveyor milestones will appear here.
              </p>
              <div className="pt-2 flex justify-center">
                <button
                  onClick={() => setActiveSubTab('file')}
                  className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>+ Intimate / File New Claim</span>
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Quick Select & Search Header */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Select Active Claim:
                  </span>
                  {claims.map(c => (
                    <button
                      key={c.id}
                      onClick={() => setSelectedClaimNumber(c.claimNumber)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        selectedClaimNumber === c.claimNumber
                          ? 'bg-[#002B5C] text-[#F3BA2F] shadow-sm'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {c.claimNumber} ({c.status})
                    </button>
                  ))}
                </div>

                {/* Claim Lookup Search */}
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Enter Claim ID..."
                    value={searchQuery}
                    onChange={e => {
                      setSearchQuery(e.target.value);
                      const matched = claims.find(c =>
                        c.claimNumber.toLowerCase().includes(e.target.value.toLowerCase())
                      );
                      if (matched) setSelectedClaimNumber(matched.claimNumber);
                    }}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002B5C]"
                  />
                </div>
              </div>

              {currentClaim ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Left Column: Multi-Stage Milestone Timeline (7 Cols) */}
              <div className="lg:col-span-7 bg-white p-6 sm:p-7 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Settlement Progression
                    </span>
                    <h3 className="text-lg font-bold text-[#002B5C] font-['Poppins']">
                      Claim Milestone Pipeline
                    </h3>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    currentClaim.status === 'Settled'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-amber-100 text-amber-900 border border-amber-300'
                  }`}>
                    Current Status: {currentClaim.status}
                  </span>
                </div>

                {/* 5-Step Visual Stepper Bar */}
                <div className="grid grid-cols-5 gap-1.5 text-center">
                  {['Intimated', 'Doc Review', 'Inspection', 'TPA Audit', 'Settled'].map((stg, i) => {
                    const stepNum = i + 1;
                    const isDone = stepNum < currentClaim.stageNumber || currentClaim.status === 'Settled';
                    const isCurrent = stepNum === currentClaim.stageNumber && currentClaim.status !== 'Settled';

                    return (
                      <div key={stg} className="space-y-1">
                        <div className={`h-2 rounded-full transition-all ${
                          isDone 
                            ? 'bg-emerald-500' 
                            : isCurrent 
                              ? 'bg-[#F3BA2F] animate-pulse' 
                              : 'bg-slate-200'
                        }`} />
                        <p className={`text-[10px] font-semibold truncate ${
                          isDone 
                            ? 'text-emerald-700' 
                            : isCurrent 
                              ? 'text-[#002B5C] font-bold' 
                              : 'text-slate-400'
                        }`}>
                          {stg}
                        </p>
                      </div>
                    );
                  })}
                </div>

                {/* Detailed Timeline Events List */}
                <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                  {currentClaim.timeline.map((item, idx) => (
                    <div key={idx} className="relative group">
                      {/* Node Icon */}
                      <div className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        item.completed
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : item.current
                            ? 'bg-[#F3BA2F] text-[#002B5C] ring-4 ring-amber-100'
                            : 'bg-slate-200 text-slate-500'
                      }`}>
                        {item.completed ? '✓' : idx + 1}
                      </div>

                      {/* Content */}
                      <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                        <div className="flex flex-wrap items-center justify-between gap-1 mb-1">
                          <h4 className="font-bold text-xs text-slate-800">{item.title}</h4>
                          <span className="text-[11px] font-medium text-slate-500">{item.date}</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Uploaded Documents Status */}
                <div className="pt-4 border-t border-slate-100">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3">
                    Verification of Submitted Documents
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {currentClaim.documents.map((doc, i) => (
                      <div key={i} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                        <div className="flex items-center gap-2">
                          <FileCheck className="w-4 h-4 text-[#002B5C]" />
                          <span className="font-medium text-slate-700 truncate max-w-[150px]">{doc.name}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          doc.status === 'Verified' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {doc.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Claim Summary & Surveyor Info (5 Cols) */}
              <div className="lg:col-span-5 space-y-6">
                {/* Claim Docket Card */}
                <div className="bg-gradient-to-b from-[#002B5C] to-[#001D40] text-white p-6 rounded-2xl shadow-xl border-2 border-[#F3BA2F]/40 space-y-5">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div>
                      <p className="text-[10px] text-amber-300 font-semibold uppercase">Official Claim Reference</p>
                      <h3 className="text-xl font-bold font-['Poppins'] text-[#F3BA2F]">
                        {currentClaim.claimNumber}
                      </h3>
                    </div>
                    <span className="px-2.5 py-1 text-xs rounded bg-white/10 text-white font-medium">
                      {currentClaim.claimType}
                    </span>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-300">Policy Number:</span>
                      <strong className="text-white">{currentClaim.policyNumber}</strong>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-slate-300">Policyholder Name:</span>
                      <strong className="text-white">{currentClaim.policyHolderName}</strong>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-slate-300">Claim Amount:</span>
                      <strong className="text-xl font-black text-emerald-400 font-['Poppins']">
                        ₹{currentClaim.claimAmount.toLocaleString('en-IN')}
                      </strong>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-slate-300">Date Submitted:</span>
                      <span className="text-slate-200">{currentClaim.dateSubmitted}</span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-slate-300">Estimated Settlement:</span>
                      <strong className="text-amber-300">{currentClaim.estimatedSettlementDate}</strong>
                    </div>

                    {currentClaim.hospitalOrPlace && (
                      <div className="flex justify-between">
                        <span className="text-slate-300">Hospital / Facility:</span>
                        <span className="text-right text-slate-200 max-w-[180px] truncate">
                          {currentClaim.hospitalOrPlace}
                        </span>
                      </div>
                    )}

                    {currentClaim.settlementUtr && (
                      <div className="p-3 bg-emerald-900/50 border border-emerald-500 rounded-xl space-y-1">
                        <p className="text-[10px] text-emerald-300 font-semibold uppercase">Direct NEFT Bank Reference (UTR)</p>
                        <p className="font-mono text-xs font-bold text-white">{currentClaim.settlementUtr}</p>
                      </div>
                    )}
                  </div>

                  {/* Surveyor / Medical Auditor Contact */}
                  {currentClaim.assignedSurveyor && (
                    <div className="pt-3 border-t border-white/10">
                      <p className="text-[11px] text-amber-200 font-bold uppercase tracking-wider mb-2">
                        Assigned TPA / Surveyor Officer:
                      </p>
                      <div className="p-3 rounded-xl bg-white/10 border border-white/15 text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white">{currentClaim.assignedSurveyor.name}</span>
                          <span className="text-[10px] text-amber-300">{currentClaim.assignedSurveyor.badgeId}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-slate-300 text-[11px]">
                          <Phone className="w-3 h-3 text-[#F3BA2F]" />
                          <span>Direct Support: {currentClaim.assignedSurveyor.phone}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Print / Download Claim Certificate */}
                  <button
                    onClick={() => setSelectedClaimForReport(currentClaim)}
                    className="w-full py-2.5 px-4 rounded-xl bg-white/15 hover:bg-white/25 text-white font-semibold text-xs transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
                    title="View & Print Official Claim Statement"
                  >
                    <Printer className="w-4 h-4 text-[#F3BA2F]" />
                    <span>View &amp; Print Official Claim Statement</span>
                  </button>
                </div>

                {/* Emergency Assistance Box */}
                <div className="bg-blue-50 p-4 rounded-2xl border border-blue-200 space-y-2">
                  <div className="flex items-center gap-2 text-blue-900 font-bold text-xs">
                    <Building className="w-4 h-4 text-blue-700" />
                    <span>TPA Cashless Pre-Authorization Desk</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Need immediate cashless authorization at a network hospital? Our 24x7 desk approves within 15 minutes.
                  </p>
                  <p className="text-xs font-bold text-blue-900">
                    Emergency Desk: 1800-762-784 (Ext. 2)
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white p-8 rounded-2xl border text-center text-slate-500">
              No claim found matching the searched ID.
            </div>
          )}
        </>
      )}
    </div>
  )}

      {/* SUB-VIEW 2: FILE NEW CLAIM FORM */}
      {activeSubTab === 'file' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm max-w-3xl mx-auto">
          <div className="border-b border-slate-100 pb-4 mb-6">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              Step 1 of 1 • Online Claim Intimation
            </span>
            <h3 className="text-xl font-bold font-['Poppins'] text-[#002B5C] mt-1">
              File An Insurance Claim Form
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Intimate hospitalizations, death benefits, critical illness, or maturity claims with instant OCR audit.
            </p>
          </div>

          <form onSubmit={handleSubmitNewClaim} className="space-y-6">
            {/* Policy & Holder Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Policy Number *
                </label>
                {userPolicies.length > 0 ? (
                  <select
                    value={formPolicyNumber}
                    onChange={e => setFormPolicyNumber(e.target.value)}
                    className="w-full text-xs font-semibold p-3 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-[#002B5C]"
                    required
                  >
                    {userPolicies.map(p => (
                      <option key={p.id} value={p.policyNumber}>
                        {p.policyNumber} — {p.policyName}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    value={formPolicyNumber}
                    onChange={e => setFormPolicyNumber(e.target.value)}
                    placeholder="e.g. POL-884920193 or your Policy Number"
                    className="w-full text-xs font-semibold p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
                    required
                  />
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Policyholder / Patient Full Name *
                </label>
                <input
                  type="text"
                  value={formHolderName}
                  onChange={e => setFormHolderName(e.target.value)}
                  placeholder="Full Legal Name"
                  className="w-full text-xs font-semibold p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
                  required
                />
              </div>
            </div>

            {/* Claim Type & Amount */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Claim Type *
                </label>
                <select
                  value={formClaimType}
                  onChange={e => setFormClaimType(e.target.value as any)}
                  className="w-full text-xs font-semibold p-3 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-[#002B5C]"
                  required
                >
                  <option value="Hospitalization Reimbursement">Hospitalization Reimbursement</option>
                  <option value="Critical Illness">Critical Illness Shield Payout</option>
                  <option value="Death Benefit">Death Benefit (Nominee Intimation)</option>
                  <option value="Maturity Claim">Maturity &amp; Survival Benefit</option>
                  <option value="Accidental Disability">Accidental Disability Rider</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Estimated Claim Value (₹) *
                </label>
                <input
                  type="number"
                  min="1000"
                  max="50000000"
                  value={formAmount}
                  onChange={e => setFormAmount(Number(e.target.value))}
                  className="w-full text-xs font-bold p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
                  required
                />
              </div>
            </div>

            {/* Date & Hospital/Place */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Date of Admission / Eventuality *
                </label>
                <input
                  type="date"
                  value={formDate}
                  onChange={e => setFormDate(e.target.value)}
                  className="w-full text-xs font-semibold p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Hospital / Facility Name *
                </label>
                <input
                  type="text"
                  value={formHospital}
                  onChange={e => setFormHospital(e.target.value)}
                  placeholder="e.g. Apollo Hospital, Fortis, etc."
                  className="w-full text-xs font-semibold p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
                  required
                />
              </div>
            </div>

            {/* Diagnostic Details Notes */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Medical Diagnosis &amp; Event Summary
              </label>
              <textarea
                rows={2}
                value={formNotes}
                onChange={e => setFormNotes(e.target.value)}
                placeholder="Briefly describe the illness or reason for claim..."
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
              />
            </div>

            {/* Document Upload Area */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-2">
                Upload Supporting Documents (Discharge Summary, Bills, Identity)
              </label>
              <div className="border-2 border-dashed border-slate-300 rounded-2xl p-6 text-center hover:bg-slate-50 transition-colors cursor-pointer relative">
                <input
                  type="file"
                  onChange={handleSimulateFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />
                <UploadCloud className="w-8 h-8 text-[#002B5C] mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-700">
                  Click or Drag &amp; Drop to Upload Documents (PDF, JPG, PNG)
                </p>
                <p className="text-[10px] text-slate-400 mt-1">
                  Discharge Summary, Pharmacy Invoices, Doctor Prescription, Cancelled Cheque
                </p>
              </div>

              {/* Uploaded files list */}
              {uploadedFiles.length > 0 && (
                <div className="mt-3 space-y-1.5">
                  {uploadedFiles.map((fn, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-emerald-50 border border-emerald-200 text-xs">
                      <div className="flex items-center gap-2 text-emerald-900 font-medium">
                        <FileCheck className="w-4 h-4 text-emerald-600" />
                        <span>{fn}</span>
                      </div>
                      <span className="text-[10px] text-emerald-700 font-bold">Ready for OCR ✓</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Submit Button */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setActiveSubTab('track')}
                className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:scale-[0.98] text-white font-bold text-xs shadow-md flex items-center gap-2 transition-all disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Generating Token...</span>
                ) : (
                  <>
                    <span>Submit &amp; Generate Claim Token</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: OFFICIAL CLAIM INTIMATION & STATUS REPORT */}
      {/* ========================================================= */}
      {selectedClaimForReport && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 print:p-0 print:bg-white print:static">
          <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border-4 border-[#002B5C] overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in printable-document print:border-2 print:border-slate-800 print:max-h-none print:shadow-none print:rounded-none">
            {/* Top Action Bar (Hidden in Print) */}
            <div className="bg-[#002B5C] text-white p-4 px-6 flex items-center justify-between border-b-4 border-[#F3BA2F] no-print">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-base font-['Poppins'] text-white">
                    Official Claim Intimation &amp; Status Statement
                  </h3>
                  <p className="text-xs text-amber-200">
                    Ref: <strong className="font-mono">{selectedClaimForReport.claimNumber}</strong> • TPA Claims Cell
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={async () => {
                    await downloadElementAsPdf(
                      'claim-status-document',
                      `SmartInsure_Claim_Docket_${selectedClaimForReport.claimNumber}`,
                      setIsGeneratingClaimPdf
                    );
                  }}
                  disabled={isGeneratingClaimPdf}
                  className="px-3.5 py-1.5 rounded-lg bg-[#F3BA2F] hover:bg-amber-400 text-[#002B5C] text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 disabled:opacity-50"
                  title="Download Official Statement PDF"
                >
                  {isGeneratingClaimPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{isGeneratingClaimPdf ? 'Exporting...' : 'Download PDF'}</span>
                </button>

                <button
                  onClick={triggerPrintDialog}
                  className="px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
                  title="Print Official Statement"
                >
                  <Printer className="w-4 h-4 text-[#F3BA2F]" />
                  <span className="hidden sm:inline">Print</span>
                </button>
                <button
                  onClick={() => setSelectedClaimForReport(null)}
                  className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
                  title="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Body */}
            <div 
              id="claim-status-document"
              className="p-8 overflow-y-auto space-y-6 text-xs text-slate-700 bg-[radial-gradient(#f1f5f9_1px,transparent_1px)] [background-size:16px_16px] printable-content print:p-6 print:overflow-visible print:bg-white"
            >
              {/* Institutional Header */}
              <div className="text-center pb-4 border-b-2 border-slate-300">
                <div className="flex items-center justify-center gap-2">
                  <span className="text-xl font-black text-[#002B5C] font-['Poppins'] tracking-tight">
                    Smart<span className="text-[#d99f18]">Insure</span>
                  </span>
                  <span className="text-[10px] uppercase font-bold bg-[#002B5C] text-white px-2 py-0.5 rounded">
                    Claims Depository
                  </span>
                </div>
                <p className="text-[11px] font-bold uppercase tracking-widest text-[#002B5C] mt-1">
                  SmartInsure National Life Assurance Corporation of India
                </p>
                <p className="text-lg font-black text-slate-900 font-['Poppins'] mt-1">
                  STATUTORY CLAIM INTIMATION &amp; STATUS DOCKET
                </p>
                <p className="text-xs text-slate-600 font-mono mt-0.5">
                  Claim Token: <strong className="text-[#002B5C]">{selectedClaimForReport.claimNumber}</strong> | Intimated: {selectedClaimForReport.dateSubmitted}
                </p>
                <p className="text-[10px] text-slate-400">
                  Central Claims Management &amp; TPA Authorization Cell • IRDAI Reg. 512
                </p>
              </div>

              {/* Claimant & Claim Particulars Grid */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Policyholder / Claimant</p>
                  <p className="font-bold text-slate-900 text-sm">{selectedClaimForReport.policyHolderName}</p>
                  {customer?.email && <p className="text-slate-500 text-[11px]">{customer.email}</p>}
                  {customer?.panNumber && <p className="text-slate-500 text-[11px]">PAN: <strong className="font-mono">{customer.panNumber}</strong></p>}
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Policy Reference Number</p>
                  <p className="font-mono font-bold text-[#002B5C] text-sm">{selectedClaimForReport.policyNumber}</p>
                  <p className="text-slate-600 text-[11px] mt-0.5">Claim Nature: <strong>{selectedClaimForReport.claimType}</strong></p>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Claimed Value (INR)</p>
                  <p className="font-black text-[#002B5C] text-base">
                    ₹{selectedClaimForReport.claimAmount.toLocaleString('en-IN')}.00
                  </p>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Current Adjudication Stage</p>
                  <span className={`inline-block px-2.5 py-0.5 rounded text-xs font-bold mt-0.5 ${
                    selectedClaimForReport.status === 'Settled'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-amber-100 text-amber-900 border border-amber-300'
                  }`}>
                    {selectedClaimForReport.status} (Stage {selectedClaimForReport.stageNumber} of 5)
                  </span>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Date of Incident / Admission</p>
                  <p className="font-semibold text-slate-800">{selectedClaimForReport.dateOfIncident}</p>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Hospital / Medical Facility</p>
                  <p className="font-semibold text-slate-800">{selectedClaimForReport.hospitalOrPlace || 'Registered Medical Center'}</p>
                </div>

                {selectedClaimForReport.settlementUtr && (
                  <div className="col-span-2 p-3 bg-emerald-50 rounded-lg border border-emerald-200 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold uppercase text-emerald-800">Settlement NEFT Bank Reference</p>
                      <p className="font-mono text-xs font-bold text-emerald-950">{selectedClaimForReport.settlementUtr}</p>
                    </div>
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                      Funds Dispatched ✓
                    </span>
                  </div>
                )}
              </div>

              {/* Milestone Pipeline Timeline Table */}
              <div className="border border-slate-300 rounded-xl overflow-hidden">
                <div className="bg-[#002B5C] text-white p-2.5 text-xs font-bold uppercase tracking-wider">
                  Audit Trail &amp; Processing Milestones
                </div>
                <table className="w-full text-left">
                  <thead className="bg-slate-100 text-[10px] uppercase text-slate-600 border-b border-slate-200">
                    <tr>
                      <th className="p-2.5">Milestone Step</th>
                      <th className="p-2.5">Scheduled / Completed Date</th>
                      <th className="p-2.5">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white text-xs">
                    {selectedClaimForReport.timeline.map((step, idx) => (
                      <tr key={idx}>
                        <td className="p-2.5">
                          <p className="font-bold text-slate-800">{step.title}</p>
                          <p className="text-[10px] text-slate-500">{step.description}</p>
                        </td>
                        <td className="p-2.5 text-slate-600 text-[11px] whitespace-nowrap">
                          {step.date}
                        </td>
                        <td className="p-2.5">
                          {step.completed ? (
                            <span className="text-emerald-700 font-bold text-[10px] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                              Completed ✓
                            </span>
                          ) : step.current ? (
                            <span className="text-amber-800 font-bold text-[10px] bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                              In Progress ⏳
                            </span>
                          ) : (
                            <span className="text-slate-400 text-[10px]">
                              Pending
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Documents Checklist & Surveyor Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <p className="font-bold text-[#002B5C] uppercase text-[10px] tracking-wider">Submitted Document Ledger:</p>
                  <ul className="space-y-1.5">
                    {selectedClaimForReport.documents.map((d, i) => (
                      <li key={i} className="flex items-center justify-between text-[11px] text-slate-700">
                        <span className="truncate max-w-[180px]">• {d.name}</span>
                        <span className="font-bold text-emerald-700 text-[10px]">{d.status}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                  <p className="font-bold text-[#002B5C] uppercase text-[10px] tracking-wider">Assigned TPA Surveyor:</p>
                  <p className="font-bold text-slate-900 text-xs">{selectedClaimForReport.assignedSurveyor?.name || 'Central Claims Assessor'}</p>
                  <p className="text-[11px] text-slate-500">Badge ID: <strong className="font-mono text-slate-700">{selectedClaimForReport.assignedSurveyor?.badgeId || 'TPA-MED-092'}</strong></p>
                  <p className="text-[11px] text-slate-500">Direct Helpline: {selectedClaimForReport.assignedSurveyor?.phone || '1800-762-784'}</p>
                </div>
              </div>

              {/* Statutory Redressal Note */}
              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-[10px] text-blue-950 leading-relaxed">
                <strong>IRDAI Protection Clause:</strong> As per Protection of Policyholders' Interests Regulations, claims without dispute are settled within 30 days of last document receipt. For unresolved grievances, policyholders may approach the Insurance Ombudsman.
              </div>

              {/* Digital Seal & Signature */}
              <div className="flex items-center justify-between pt-4 border-t-2 border-slate-200">
                <div className="flex items-center gap-2">
                  <Award className="w-8 h-8 text-[#002B5C]" />
                  <div>
                    <p className="text-[10px] font-bold uppercase text-slate-400">Authenticated By</p>
                    <p className="text-xs font-bold text-slate-800">SmartInsure TPA Claims Board</p>
                    <p className="text-[10px] text-slate-400">Digital Intimation Reference Encrypted</p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="font-serif italic font-bold text-slate-900 text-base">Dr. R. K. Mukherjee</p>
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Chief Medical Officer &amp; TPA Claims Head</p>
                  <p className="text-[10px] text-slate-400">SmartInsure Corporation of India</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
