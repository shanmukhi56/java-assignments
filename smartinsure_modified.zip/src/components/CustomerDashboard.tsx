import { useState, useMemo } from 'react';
import { 
  UserCheck, 
  Shield, 
  Calendar, 
  Download, 
  CreditCard, 
  AlertTriangle, 
  CheckCircle2, 
  FileText, 
  Lock, 
  Award, 
  ChevronRight, 
  ArrowRight, 
  X,
  Printer,
  Sparkles,
  Heart,
  TrendingUp,
  Percent,
  Search,
  Filter,
  RefreshCw,
  Clock,
  AlertCircle,
  HelpCircle,
  Loader2
} from 'lucide-react';
import { CustomerProfile, PaymentMethod, PaymentTransaction, UserPolicy } from '../types';
import { processRenewalPayment } from '../services/supabase';
import { downloadElementAsPdf, triggerPrintDialog } from '../utils/pdfDownloader';

interface CustomerDashboardProps {
  customer: CustomerProfile | null;
  userPolicies: UserPolicy[];
  payments: PaymentTransaction[];
  onRefreshData: () => void;
  onNavigateToCalculator: () => void;
  onNavigateToClaims: () => void;
  onOpenReceipt: (payment: PaymentTransaction) => void;
  onOpenTaxCertificate: () => void;
  onOpenAuth: () => void;
}

export default function CustomerDashboard({
  customer,
  userPolicies,
  payments,
  onRefreshData,
  onNavigateToCalculator,
  onNavigateToClaims,
  onOpenReceipt,
  onOpenTaxCertificate,
  onOpenAuth
}: CustomerDashboardProps) {
  const [activeTab, setActiveTab] = useState<'policies' | 'payments'>('policies');
  const [selectedPolicyForBond, setSelectedPolicyForBond] = useState<UserPolicy | null>(null);
  const [isGeneratingBondPdf, setIsGeneratingBondPdf] = useState(false);

  // Renewal Payment Modal State
  const [payingPolicy, setPayingPolicy] = useState<UserPolicy | null>(null);
  const [renewalMethod, setRenewalMethod] = useState<PaymentMethod>('UPI');
  const [renewalUpiVpa, setRenewalUpiVpa] = useState(
    customer ? `${customer.email.split('@')[0]}@okbank` : 'customer@okbank'
  );
  const [simulateFailure, setSimulateFailure] = useState(false);
  const [isProcessingRenewal, setIsProcessingRenewal] = useState(false);
  const [renewalError, setRenewalError] = useState<string | null>(null);

  // Payments Search & Filter
  const [paymentSearch, setPaymentSearch] = useState('');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState<'ALL' | 'SUCCESS' | 'FAILED'>('ALL');

  // Customer identity
  const customerName = customer?.fullName || 'Guest Customer';
  const customerEmail = customer?.email || '';
  const customerPan = customer?.panNumber || 'N/A';

  // Portfolio aggregates calculated strictly from authenticated data
  const totalSumAssured = userPolicies.reduce((acc, p) => acc + p.sumAssured, 0);
  const totalAnnualPremium = userPolicies.reduce((acc, p) => acc + p.premiumAmount, 0);
  const totalVestedBonus = userPolicies.reduce((acc, p) => acc + p.accumulatedBonus, 0);

  // Total Premium Paid is calculated ONLY from successful transactions belonging to this customer
  const totalPremiumPaid = useMemo(() => {
    return payments
      .filter(p => p.status === 'SUCCESS')
      .reduce((sum, p) => sum + p.totalAmount, 0);
  }, [payments]);

  // Filtered payments list
  const filteredPayments = useMemo(() => {
    return payments.filter(p => {
      const matchSearch =
        p.transactionReference.toLowerCase().includes(paymentSearch.toLowerCase()) ||
        p.receiptNumber.toLowerCase().includes(paymentSearch.toLowerCase()) ||
        p.policyNumber.toLowerCase().includes(paymentSearch.toLowerCase()) ||
        p.policyName.toLowerCase().includes(paymentSearch.toLowerCase());

      const matchStatus = paymentStatusFilter === 'ALL' || p.status === paymentStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [payments, paymentSearch, paymentStatusFilter]);

  // Handle renewal payment submission
  const handleExecuteRenewal = async () => {
    if (!payingPolicy || !customer || isProcessingRenewal) return;

    setIsProcessingRenewal(true);
    setRenewalError(null);

    const res = await processRenewalPayment(customer, payingPolicy, renewalMethod, simulateFailure);
    setIsProcessingRenewal(false);

    if (res.success && res.payment) {
      setPayingPolicy(null);
      onRefreshData();
      onOpenReceipt(res.payment);
    } else {
      setRenewalError(res.error || 'Payment failed. Please try again.');
      if (res.payment) {
        onRefreshData();
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 animate-in fade-in">
      {/* Customer Header Banner */}
      <div className="bg-[#002B5C] text-white p-6 rounded-2xl shadow-lg border-b-4 border-[#F3BA2F] mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-amber-300 text-xs font-bold mb-2 border border-white/10">
              <UserCheck className="w-3.5 h-3.5 text-[#F3BA2F]" />
              <span>Customer Policy Vault • Assessee: <strong>{customerName}</strong></span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-['Poppins'] text-white">
              Insurance Portfolio &amp; Payments Hub
            </h2>
            <p className="text-xs sm:text-sm text-slate-200 mt-1 max-w-2xl">
              PAN: <strong className="font-mono text-amber-300">{customerPan}</strong> • Email: {customerEmail} • Sovereign Single Depository Account
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onOpenTaxCertificate}
              className="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs flex items-center gap-1.5 transition-all border border-white/15"
            >
              <FileText className="w-3.5 h-3.5 text-[#F3BA2F]" />
              <span>Annual Tax Certificate (80C)</span>
            </button>

            <button
              onClick={onNavigateToCalculator}
              className="px-4 py-2 rounded-xl bg-[#F3BA2F] hover:bg-[#e0aa28] text-[#002B5C] font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <span>+ Buy New Policy</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Aggregate KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-gradient-to-br from-[#002B5C] to-[#003875] text-white p-5 rounded-2xl shadow-md border border-[#F3BA2F]/30">
          <p className="text-[11px] text-amber-300 font-semibold uppercase tracking-wider">Total Active Life Cover</p>
          <p className="text-2xl font-extrabold text-white mt-1 font-['Poppins']">
            ₹{(totalSumAssured / 10000000).toFixed(2)} Cr
          </p>
          <p className="text-[10px] text-slate-300 mt-1">
            {userPolicies.length} Active {userPolicies.length === 1 ? 'Policy' : 'Policies'} in Vault
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
          <p className="text-[11px] text-slate-500 font-semibold uppercase tracking-wider">Total Premium Paid</p>
          <p className="text-2xl font-black text-emerald-700 mt-1 font-['Poppins']">
            ₹{totalPremiumPaid.toLocaleString('en-IN')}
          </p>
          <p className="text-[10px] text-slate-400 mt-1">
            {payments.filter(p => p.status === 'SUCCESS').length} Successful {payments.filter(p => p.status === 'SUCCESS').length === 1 ? 'Payment' : 'Payments'}
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
          <p className="text-[11px] text-slate-500 font-semibold uppercase tracking-wider">Annual Renewal Commitment</p>
          <p className="text-2xl font-extrabold text-[#002B5C] mt-1 font-['Poppins']">
            ₹{totalAnnualPremium.toLocaleString('en-IN')}
          </p>
          <p className="text-[10px] text-emerald-700 font-bold mt-1">Sec 80C Tax-Exempt</p>
        </div>

        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
          <p className="text-[11px] text-slate-500 font-semibold uppercase tracking-wider">Vested Compound Bonuses</p>
          <p className="text-2xl font-extrabold text-amber-700 mt-1 font-['Poppins']">
            ₹{totalVestedBonus.toLocaleString('en-IN')}
          </p>
          <p className="text-[10px] text-slate-400 mt-1">Accrued to your policy accounts</p>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex border-b border-slate-200 mb-6 gap-2">
        <button
          onClick={() => setActiveTab('policies')}
          className={`pb-3 px-4 font-bold text-xs sm:text-sm font-['Poppins'] border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'policies'
              ? 'border-[#002B5C] text-[#002B5C]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>My Active Policies ({userPolicies.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('payments')}
          className={`pb-3 px-4 font-bold text-xs sm:text-sm font-['Poppins'] border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'payments'
              ? 'border-[#002B5C] text-[#002B5C]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>My Payments &amp; Transactions ({payments.length})</span>
        </button>
      </div>

      {/* ========================================================= */}
      {/* TAB 1: MY ACTIVE POLICIES */}
      {/* ========================================================= */}
      {activeTab === 'policies' && (
        <div className="space-y-6">
          {userPolicies.length === 0 ? (
            /* ZERO POLICIES CLEAN STATE */
            <div className="p-12 text-center bg-slate-50/80 rounded-2xl border-2 border-dashed border-slate-300 space-y-4">
              <div className="w-16 h-16 rounded-full bg-blue-100 text-[#002B5C] flex items-center justify-center mx-auto">
                <Shield className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-bold text-[#002B5C] font-['Poppins']">
                No Active Policies Found
              </h4>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                You currently have no insurance policies in your portfolio. Get institutional sovereign life coverage, retirement pension, or critical illness protection with instant online issuance.
              </p>
              <div className="pt-2 flex justify-center gap-3">
                <button
                  onClick={onNavigateToCalculator}
                  className="px-6 py-2.5 rounded-xl bg-[#002B5C] hover:bg-[#001D40] text-[#F3BA2F] font-bold text-xs shadow-md transition-all flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Browse Plans &amp; Calculate Quote</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {userPolicies.map(pol => {
                const isGrace = pol.status === 'Grace Period';
                const baseRenewal = pol.premiumAmount;
                const gstRenewal = Math.round(baseRenewal * 0.18);
                const totalRenewal = baseRenewal + gstRenewal;

                return (
                  <div
                    key={pol.id}
                    className="bg-white rounded-2xl border border-slate-200 hover:border-[#002B5C]/40 shadow-sm hover:shadow-md transition-all flex flex-col justify-between overflow-hidden"
                  >
                    {/* Header */}
                    <div className="p-5 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">
                          {pol.policyNumber}
                        </span>
                        <h4 className="text-sm font-bold text-[#002B5C] font-['Poppins'] mt-0.5">
                          {pol.policyName}
                        </h4>
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        pol.status === 'Active'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : isGrace
                            ? 'bg-amber-100 text-amber-900 border border-amber-300 animate-pulse'
                            : 'bg-slate-100 text-slate-700'
                      }`}>
                        {pol.status}
                      </span>
                    </div>

                    {/* Body Details */}
                    <div className="p-5 space-y-3 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Life Sum Assured:</span>
                        <strong className="text-slate-800 text-sm font-extrabold font-['Poppins']">
                          ₹{pol.sumAssured.toLocaleString('en-IN')}
                        </strong>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-500">Renewal Premium:</span>
                        <strong className="text-[#002B5C] font-bold">
                          ₹{pol.premiumAmount.toLocaleString('en-IN')} ({pol.premiumFrequency})
                        </strong>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-500">Next Due Date:</span>
                        <strong className={isGrace ? 'text-amber-800 font-bold' : 'text-slate-700'}>
                          {pol.nextDueDate}
                        </strong>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-500">Nominee Registered:</span>
                        <span className="text-slate-700 font-medium truncate max-w-[160px] text-right">
                          {pol.nomineeName}
                        </span>
                      </div>

                      {pol.accumulatedBonus > 0 && (
                        <div className="flex justify-between pt-2 border-t border-slate-100">
                          <span className="text-slate-500">Accrued Bonus:</span>
                          <span className="text-emerald-700 font-bold">
                            ₹{pol.accumulatedBonus.toLocaleString('en-IN')}
                          </span>
                        </div>
                      )}

                      {/* Progress bar */}
                      <div className="pt-2">
                        <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                          <span>Paid: {pol.paidInstallments}/{pol.totalInstallments} Yrs</span>
                          <span>Maturity: {pol.maturityDate}</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-1.5">
                          <div
                            className="bg-[#002B5C] h-1.5 rounded-full"
                            style={{ width: `${(pol.paidInstallments / pol.totalInstallments) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="p-5 pt-0 space-y-2">
                      <button
                        onClick={() => {
                          setPayingPolicy(pol);
                          setRenewalError(null);
                          setSimulateFailure(false);
                        }}
                        className="w-full py-2.5 px-3 rounded-xl bg-[#002B5C] hover:bg-[#001D40] text-[#F3BA2F] font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-all"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Pay Renewal Premium Online</span>
                      </button>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => setSelectedPolicyForBond(pol)}
                          className="py-2 px-2.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-[11px] font-semibold flex items-center justify-center gap-1"
                        >
                          <Download className="w-3 h-3 text-slate-400" />
                          <span>Digital Bond</span>
                        </button>

                        <button
                          onClick={onNavigateToClaims}
                          className="py-2 px-2.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-[11px] font-semibold flex items-center justify-center gap-1"
                        >
                          <FileText className="w-3 h-3 text-emerald-600" />
                          <span>Intimate Claim</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 2: MY PAYMENTS & TRANSACTION HISTORY */}
      {/* ========================================================= */}
      {activeTab === 'payments' && (
        <div className="space-y-6">
          {/* Search & Filter Toolbar */}
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={paymentSearch}
                onChange={e => setPaymentSearch(e.target.value)}
                placeholder="Search payments by Txn Ref, Receipt # or Policy..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#002B5C]"
              />
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">Status:</span>
              {(['ALL', 'SUCCESS', 'FAILED'] as const).map(st => (
                <button
                  key={st}
                  onClick={() => setPaymentStatusFilter(st)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    paymentStatusFilter === st
                      ? 'bg-[#002B5C] text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* ZERO PAYMENTS CLEAN STATE */}
          {filteredPayments.length === 0 ? (
            <div className="p-12 text-center bg-slate-50/80 rounded-2xl border-2 border-dashed border-slate-300 space-y-4">
              <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
                <CreditCard className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-bold text-[#002B5C] font-['Poppins']">
                No Payments Found
              </h4>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                You haven't made any payments yet. Browse our insurance plans or use the Smart Quote Calculator to purchase a policy or pay a renewal.
              </p>
              <div className="pt-2">
                <button
                  onClick={onNavigateToCalculator}
                  className="px-6 py-2.5 rounded-xl bg-[#002B5C] hover:bg-[#001D40] text-[#F3BA2F] font-bold text-xs shadow-md transition-all"
                >
                  Explore Plans &amp; Buy Policy
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#002B5C] text-white text-[10px] uppercase font-bold tracking-wider">
                    <tr>
                      <th className="p-3">Transaction Date &amp; Ref</th>
                      <th className="p-3">Official Receipt #</th>
                      <th className="p-3">Policy Particulars</th>
                      <th className="p-3">Payment Method</th>
                      <th className="p-3 text-right">Amount (INR)</th>
                      <th className="p-3 text-center">Status</th>
                      <th className="p-3 text-center">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {filteredPayments.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3">
                          <p className="font-bold text-[#002B5C] font-mono">{p.transactionReference}</p>
                          <p className="text-[10px] text-slate-500">
                            {new Date(p.paymentDate).toLocaleString('en-IN', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </p>
                        </td>

                        <td className="p-3 font-mono font-bold text-slate-800">
                          {p.receiptNumber}
                        </td>

                        <td className="p-3">
                          <p className="font-bold text-slate-800">{p.policyName}</p>
                          <p className="text-[10px] font-mono text-slate-500">{p.policyNumber}</p>
                          <span className="text-[9px] uppercase font-bold text-emerald-800 bg-emerald-50 px-1 py-0.2 rounded">
                            {p.taxDeductionSection}
                          </span>
                        </td>

                        <td className="p-3">
                          <p className="font-semibold text-slate-700">{p.paymentMethod}</p>
                          <p className="text-[10px] font-mono text-slate-400 truncate max-w-[120px]">
                            {p.bankRefNumber || 'Gateway'}
                          </p>
                        </td>

                        <td className="p-3 text-right font-mono">
                          <p className="font-bold text-slate-900 text-sm font-['Poppins']">
                            ₹{p.totalAmount.toLocaleString('en-IN')}
                          </p>
                          <p className="text-[10px] text-slate-400">
                            (Base: ₹{p.baseAmount.toLocaleString('en-IN')} + GST)
                          </p>
                        </td>

                        <td className="p-3 text-center">
                          <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            p.status === 'SUCCESS'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}>
                            {p.status === 'SUCCESS' ? '✓ SUCCESS' : '✕ FAILED'}
                          </span>
                        </td>

                        <td className="p-3 text-center">
                          <button
                            onClick={() => onOpenReceipt(p)}
                            className="px-2.5 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#002B5C] font-bold text-[11px] flex items-center gap-1 mx-auto transition-all"
                            title="View Official Verified Receipt"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>Receipt</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: PAY RENEWAL PREMIUM (AUTHENTICATED FLOW) */}
      {/* ========================================================= */}
      {payingPolicy && customer && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border-2 border-[#002B5C] overflow-hidden animate-in fade-in">
            <div className="bg-[#002B5C] text-white p-5 flex items-center justify-between border-b-2 border-[#F3BA2F]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base font-['Poppins']">
                    Pay Annual Renewal Premium
                  </h3>
                  <p className="text-[11px] text-amber-200">
                    Payer: {customer.fullName} • Policy: {payingPolicy.policyNumber}
                  </p>
                </div>
              </div>

              {!isProcessingRenewal && (
                <button
                  onClick={() => setPayingPolicy(null)}
                  className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            <div className="p-6 space-y-4 text-xs text-slate-700">
              {renewalError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2 text-rose-800">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{renewalError}</span>
                </div>
              )}

              {/* Policy Financials */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Policy Plan:</span>
                  <span className="font-bold text-slate-900">{payingPolicy.policyName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Base Premium (Yearly):</span>
                  <span className="font-semibold text-slate-800">₹{payingPolicy.premiumAmount.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">GST @ 18%:</span>
                  <span className="font-semibold text-slate-800">
                    ₹{Math.round(payingPolicy.premiumAmount * 0.18).toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-200 text-sm">
                  <span className="font-bold text-[#002B5C]">Total Renewal Amount:</span>
                  <span className="font-black text-lg text-[#002B5C] font-['Poppins']">
                    ₹{(payingPolicy.premiumAmount + Math.round(payingPolicy.premiumAmount * 0.18)).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Payment Method */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-800 uppercase">
                  Select Payment Method
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'UPI', label: 'Instant UPI' },
                    { id: 'Net Banking', label: 'NetBanking' },
                    { id: 'Credit / Debit Card', label: 'Debit / Card' }
                  ].map(m => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setRenewalMethod(m.id as any)}
                      className={`p-2.5 rounded-xl border text-center font-bold text-xs transition-all ${
                        renewalMethod === m.id
                          ? 'bg-[#002B5C] text-white border-[#002B5C] shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              {renewalMethod === 'UPI' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    UPI ID / VPA
                  </label>
                  <input
                    type="text"
                    value={renewalUpiVpa}
                    onChange={e => setRenewalUpiVpa(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 bg-white font-semibold text-xs focus:ring-2 focus:ring-[#002B5C]"
                  />
                </div>
              )}

              {/* Error Simulation Toggle */}
              <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between text-[11px]">
                <span className="text-amber-900 font-semibold">Test Failure Response:</span>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={simulateFailure}
                    onChange={e => setSimulateFailure(e.target.checked)}
                    className="w-4 h-4 accent-rose-600"
                  />
                  <span className="text-rose-800 font-bold">Simulate Bank Decline</span>
                </label>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPayingPolicy(null)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isProcessingRenewal}
                  onClick={handleExecuteRenewal}
                  className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
                >
                  {isProcessingRenewal ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent animate-spin rounded-full" />
                      <span>Authorizing Bank...</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-3.5 h-3.5" />
                      <span>Pay ₹{(payingPolicy.premiumAmount + Math.round(payingPolicy.premiumAmount * 0.18)).toLocaleString('en-IN')}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: DIGITAL POLICY BOND CERTIFICATE */}
      {/* ========================================================= */}
      {selectedPolicyForBond && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 print:p-0 print:bg-white print:static">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border-4 border-[#002B5C] overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in printable-document print:border-2 print:border-slate-800 print:max-h-none print:shadow-none print:rounded-none">
            {/* Top Bar (Hidden in Print) */}
            <div className="bg-[#002B5C] text-white p-5 flex items-center justify-between border-b-4 border-[#F3BA2F] no-print">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg font-['Poppins'] text-white">
                    Official Digital Insurance Policy Bond
                  </h3>
                  <p className="text-xs text-amber-200">
                    Statutory Life Assurance Contract Document • IRDAI Reg. 512
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={async () => {
                    await downloadElementAsPdf(
                      'policy-bond-document',
                      `SmartInsure_Policy_Bond_${selectedPolicyForBond.policyNumber}`,
                      setIsGeneratingBondPdf
                    );
                  }}
                  disabled={isGeneratingBondPdf}
                  className="px-3.5 py-1.5 rounded-lg bg-[#F3BA2F] hover:bg-amber-400 text-[#002B5C] text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 disabled:opacity-50"
                  title="Download Policy Bond PDF"
                >
                  {isGeneratingBondPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{isGeneratingBondPdf ? 'Exporting...' : 'Download PDF'}</span>
                </button>
                <button
                  onClick={triggerPrintDialog}
                  className="px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
                  title="Print Policy Bond"
                >
                  <Printer className="w-4 h-4 text-[#F3BA2F]" />
                  <span className="hidden sm:inline">Print</span>
                </button>
                <button
                  onClick={() => setSelectedPolicyForBond(null)}
                  className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
                  title="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div 
              id="policy-bond-document"
              className="p-8 overflow-y-auto space-y-6 text-xs text-slate-700 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] printable-content print:p-6 print:overflow-visible print:bg-white"
            >
              {/* Institutional Header */}
              <div className="text-center pb-4 border-b-2 border-slate-300">
                <div className="flex items-center justify-center gap-2">
                  <span className="text-xl font-black text-[#002B5C] font-['Poppins'] tracking-tight">
                    Smart<span className="text-[#d99f18]">Insure</span>
                  </span>
                  <span className="text-[10px] uppercase font-bold bg-[#002B5C] text-white px-2 py-0.5 rounded">
                    Sovereign Bond
                  </span>
                </div>
                <p className="text-[11px] font-bold uppercase tracking-widest text-[#002B5C] mt-1">
                  SmartInsure National Life Assurance Corporation of India
                </p>
                <p className="text-lg font-black text-slate-900 font-['Poppins'] mt-1">
                  OFFICIAL SCHEDULE OF LIFE INSURANCE POLICY
                </p>
                <p className="text-xs text-slate-600 font-mono mt-0.5">
                  Policy Contract Number: <strong className="text-[#002B5C]">{selectedPolicyForBond.policyNumber}</strong>
                </p>
                <p className="text-[10px] text-slate-400">
                  CIN: L66010DL2000GOI104821 • IRDAI Registered Assurance Entity
                </p>
              </div>

              {/* Policy Schedule Grid */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50/80 rounded-xl border border-slate-200">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Name of Life Assured (Proposer)</p>
                  <p className="font-bold text-slate-900 text-sm">{selectedPolicyForBond.customerName || customerName}</p>
                  <p className="text-slate-500 text-[11px] mt-0.5">{customer?.email}</p>
                  {customer?.panNumber && (
                    <p className="text-slate-500 text-[11px]">PAN: <strong className="font-mono text-slate-700">{customer.panNumber}</strong></p>
                  )}
                  {customer?.address && (
                    <p className="text-slate-500 text-[10px] leading-tight mt-1">{customer.address}</p>
                  )}
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Plan Title &amp; Table Number</p>
                  <p className="font-bold text-[#002B5C] text-sm">{selectedPolicyForBond.policyName}</p>
                  <p className="text-slate-600 text-[11px]">Assurance Category: <span className="font-semibold capitalize">{selectedPolicyForBond.category}</span></p>
                  <p className="text-slate-600 text-[11px]">Status: <span className="font-bold text-emerald-700">✓ In Force (Active)</span></p>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Guaranteed Sum Assured</p>
                  <p className="font-black text-[#002B5C] text-base">
                    ₹{selectedPolicyForBond.sumAssured.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-slate-500">100% Tax-Free under Sec 10(10D)</p>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Modal Installment Premium</p>
                  <p className="font-bold text-slate-900 text-base">
                    ₹{selectedPolicyForBond.premiumAmount.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[10px] text-emerald-700 font-semibold">Eligible under Section 80C</p>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Date of Commencement</p>
                  <p className="font-semibold text-slate-800">{selectedPolicyForBond.startDate}</p>
                </div>

                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Date of Maturity</p>
                  <p className="font-semibold text-slate-800">{selectedPolicyForBond.maturityDate}</p>
                </div>

                <div className="col-span-2 pt-2 border-t border-slate-200">
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Designated Beneficial Nominee</p>
                  <p className="font-bold text-slate-900">
                    {selectedPolicyForBond.nomineeName} <span className="text-slate-500 font-normal">({selectedPolicyForBond.nomineeRelation} • 100% Share)</span>
                  </p>
                </div>
              </div>

              {/* Statutory Guarantee Box */}
              <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-950 leading-relaxed">
                <strong>Statutory Guarantee &amp; Payout Undertaking:</strong> The Sum Assured, vested reversionary bonuses, and terminal additions under this policy are guaranteed in terms of the statutory charter. In the event of death of the life assured or survival to the maturity date, proceeds shall be settled expeditiously.
              </div>

              {/* Digital Seal & Signatures */}
              <div className="flex items-center justify-between pt-4 border-t-2 border-slate-200">
                <div className="flex items-center gap-2.5">
                  <Award className="w-9 h-9 text-[#002B5C]" />
                  <div>
                    <p className="text-[10px] font-bold uppercase text-slate-400">Authenticated By</p>
                    <p className="text-xs font-bold text-slate-800">SmartInsure Central Depository</p>
                    <p className="text-[10px] text-slate-400">Digital Vault Cryptographic Hash Verified</p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="font-serif italic font-bold text-slate-900 text-base">V. K. Shrivastava</p>
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Chief Actuary &amp; Underwriting Officer</p>
                  <p className="text-[10px] text-slate-400">SmartInsure Corporation of India</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
