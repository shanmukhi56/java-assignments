import { ShieldCheck, TrendingUp, Clock, FileCheck, CheckCircle2, ChevronRight, ArrowRight, Award, Lock, Sparkles } from 'lucide-react';

interface HeroBannerProps {
  onNavigate: (tab: 'plans' | 'calculator' | 'claims' | 'dashboard' | 'faq') => void;
  openAiAdvisor: () => void;
}

export default function HeroBanner({ onNavigate, openAiAdvisor }: HeroBannerProps) {
  return (
    <div className="bg-gradient-to-b from-[#002B5C] via-[#003875] to-[#002B5C] text-white pt-8 pb-12 px-4 sm:px-8 border-b border-[#F3BA2F]/30 relative overflow-hidden">
      {/* Subtle institutional watermark background */}
      <div className="absolute right-0 top-0 w-96 h-96 bg-[#F3BA2F]/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
      <div className="absolute left-1/3 bottom-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto">
        {/* Main Pitch & Trust Badge */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-amber-300 text-xs font-semibold mb-4 backdrop-blur-sm">
            <ShieldCheck className="w-4 h-4 text-[#F3BA2F]" />
            <span>ISO 9001:2015 & IRDAI Licensed Institutional Portal</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold font-['Poppins'] tracking-tight text-white leading-tight">
            Institutional Protection &amp; <br />
            <span className="text-[#F3BA2F]">Intelligent Claim Assurance</span>
          </h1>

          <p className="mt-4 text-slate-200 text-sm sm:text-base leading-relaxed">
            Personalized life coverage, guaranteed wealth creation, and automated cashless claim processing backed by 70+ years of institutional trust.
          </p>

          {/* Direct CTA Bar */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => onNavigate('calculator')}
              className="px-6 py-3 rounded-xl bg-[#F3BA2F] hover:bg-[#e0aa28] text-[#002B5C] font-bold text-sm shadow-lg hover:shadow-xl transition-all flex items-center gap-2"
            >
              <span>Get Recommended Plan &amp; Quote</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('claims')}
              className="px-5 py-3 rounded-xl bg-white/15 hover:bg-white/25 text-white font-semibold text-sm border border-white/20 transition-all flex items-center gap-2"
            >
              <span>Track / Intimate a Claim</span>
              <ChevronRight className="w-4 h-4 text-slate-300" />
            </button>

            <button
              onClick={openAiAdvisor}
              className="px-4 py-3 rounded-xl bg-slate-900/60 hover:bg-slate-900/80 text-amber-300 font-semibold text-sm border border-amber-400/30 transition-all flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Ask AI Advisor</span>
            </button>
          </div>
        </div>

        {/* 4 Interactive Quick Action Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Card 1 */}
          <div 
            onClick={() => onNavigate('calculator')}
            className="group bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-5 border border-white/15 hover:border-[#F3BA2F]/60 cursor-pointer transition-all hover:-translate-y-1 shadow-md"
          >
            <div className="w-10 h-10 rounded-xl bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold mb-3 shadow-md group-hover:scale-105 transition-transform">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h2 className="text-base font-bold text-white mb-1 group-hover:text-[#F3BA2F] transition-colors">
              Premium &amp; Maturity Calculator
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Calculate instant premiums, bonus returns &amp; Section 80C tax savings.
            </p>
            <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-[#F3BA2F]">
              <span>Calculate Now</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2 */}
          <div 
            onClick={() => onNavigate('claims')}
            className="group bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-5 border border-white/15 hover:border-emerald-400/60 cursor-pointer transition-all hover:-translate-y-1 shadow-md"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center font-bold mb-3 shadow-md group-hover:scale-105 transition-transform">
              <Clock className="w-5 h-5" />
            </div>
            <h2 className="text-base font-bold text-white mb-1 group-hover:text-emerald-400 transition-colors">
              Smart Fast-Track Claims
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Register cashless intimation or track live TPA &amp; surveyor milestones.
            </p>
            <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-emerald-400">
              <span>Track or File Claim</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3 */}
          <div 
            onClick={() => onNavigate('dashboard')}
            className="group bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-5 border border-white/15 hover:border-cyan-400/60 cursor-pointer transition-all hover:-translate-y-1 shadow-md"
          >
            <div className="w-10 h-10 rounded-xl bg-cyan-500 text-white flex items-center justify-center font-bold mb-3 shadow-md group-hover:scale-105 transition-transform">
              <FileCheck className="w-5 h-5" />
            </div>
            <h2 className="text-base font-bold text-white mb-1 group-hover:text-cyan-300 transition-colors">
              Pay Renewal &amp; Receipts
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              1-Click UPI/Netbanking premium clearance with instant tax receipts.
            </p>
            <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-cyan-300">
              <span>Go to Policy Vault</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 4 */}
          <div 
            onClick={() => onNavigate('plans')}
            className="group bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-5 border border-white/15 hover:border-amber-400/60 cursor-pointer transition-all hover:-translate-y-1 shadow-md"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold mb-3 shadow-md group-hover:scale-105 transition-transform">
              <Lock className="w-5 h-5" />
            </div>
            <h2 className="text-base font-bold text-white mb-1 group-hover:text-amber-300 transition-colors">
              Explore All 6 Plans
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Compare Term, Guaranteed Endowment, Child Future &amp; Critical Shield.
            </p>
            <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-amber-300">
              <span>View All Plans</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>

        {/* Institutional Trust Badges & Stats */}
        <div className="pt-6 border-t border-white/10 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="p-3 bg-white/5 rounded-xl border border-white/10">
            <p className="text-2xl sm:text-3xl font-black text-[#F3BA2F] font-['Poppins']">98.92%</p>
            <p className="text-xs text-slate-300 mt-0.5">Claim Settlement Ratio</p>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/10">
            <p className="text-2xl sm:text-3xl font-black text-emerald-400 font-['Poppins']">&lt; 4 Hours</p>
            <p className="text-xs text-slate-300 mt-0.5">Express Claim Intimation SLA</p>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/10">
            <p className="text-2xl sm:text-3xl font-black text-cyan-300 font-['Poppins']">14,200+</p>
            <p className="text-xs text-slate-300 mt-0.5">Cashless Hospital Network</p>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/10">
            <p className="text-2xl sm:text-3xl font-black text-amber-300 font-['Poppins']">100%</p>
            <p className="text-xs text-slate-300 mt-0.5">Sovereign Capital Assurance</p>
          </div>
        </div>
      </div>
    </div>
  );
}
