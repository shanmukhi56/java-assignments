import { useState, useRef, useEffect } from 'react';
import { 
  Shield, 
  PhoneCall, 
  FileText, 
  UserCheck, 
  Sparkles, 
  Menu, 
  X,
  Award,
  Layers,
  User,
  LogOut,
  ChevronDown,
  ShieldAlert,
  LogIn,
  UserPlus,
  Lock
} from 'lucide-react';
import { CustomerProfile } from '../types';

interface HeaderProps {
  activeTab: 'plans' | 'calculator' | 'claims' | 'dashboard' | 'payments' | 'admin' | 'faq';
  setActiveTab: (tab: 'plans' | 'calculator' | 'claims' | 'dashboard' | 'payments' | 'admin' | 'faq') => void;
  openAiAdvisor: () => void;
  claimCount: number;
  userPolicyCount: number;
  customer: CustomerProfile | null;
  onOpenAuth: (mode?: 'login' | 'register' | 'admin') => void;
  onSignOut: () => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  openAiAdvisor,
  claimCount,
  userPolicyCount,
  customer,
  onOpenAuth,
  onSignOut
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const isAdmin = customer?.role === 'admin';

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setUserDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-[#002B5C] text-white shadow-md border-b-2 border-[#F3BA2F] no-print">
      {/* Top Institutional Trust Bar */}
      <div className="bg-[#001D40] text-xs py-1.5 px-4 sm:px-8 border-b border-white/10">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1 text-[#F3BA2F] font-semibold">
              <Award className="w-3.5 h-3.5" />
              Sovereign &amp; IRDAI Regulated Security
            </span>
            <span className="hidden md:inline text-white/40">|</span>
            <span className="hidden md:inline text-slate-300">
              Claim Settlement Ratio: <strong className="text-emerald-400 font-bold">98.92% (FY25-26)</strong>
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-300">
            <div className="flex items-center gap-1.5 text-amber-300 font-medium">
              <PhoneCall className="w-3.5 h-3.5 text-[#F3BA2F]" />
              <span>24x7 Helpline: <strong>1800-762-784</strong></span>
            </div>
            <span className="hidden sm:inline text-white/40">|</span>
            <span className="hidden sm:inline text-xs text-slate-300">ISO 27001 Certified Vault</span>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3 flex items-center justify-between gap-4">
        {/* Brand & Logo */}
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => setActiveTab('plans')}
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#F3BA2F] to-[#d99f18] p-0.5 shadow-lg flex items-center justify-center">
            <div className="w-full h-full bg-[#002B5C] rounded-[9px] flex items-center justify-center">
              <Shield className="w-5 h-5 text-[#F3BA2F] group-hover:scale-110 transition-transform" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-lg font-black tracking-tight text-white font-['Poppins']">
                Insure<span className="text-[#F3BA2F]">secure</span>
              </span>
              <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-[#F3BA2F]/20 text-[#F3BA2F] border border-[#F3BA2F]/30 tracking-wider">
                Official
              </span>
            </div>
            <p className="text-[10px] text-slate-300">
              National Life &amp; Health Assurance Vault
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 text-xs sm:text-sm">
          <button
            onClick={() => setActiveTab('plans')}
            className={`px-3 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'plans'
                ? 'bg-white/15 text-[#F3BA2F] font-bold border-b-2 border-[#F3BA2F]'
                : 'text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Layers className="w-4 h-4" />
              Insurance Plans
            </span>
          </button>

          <button
            onClick={() => setActiveTab('calculator')}
            className={`px-3 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'calculator'
                ? 'bg-white/15 text-[#F3BA2F] font-bold border-b-2 border-[#F3BA2F]'
                : 'text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-300" />
              Smart Calculator
            </span>
          </button>

          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-3 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'dashboard'
                ? 'bg-white/15 text-[#F3BA2F] font-bold border-b-2 border-[#F3BA2F]'
                : 'text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-cyan-400" />
              My Policies &amp; Payments {customer ? `(${userPolicyCount})` : ''}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('claims')}
            className={`px-3 py-2 rounded-lg font-medium transition-all relative ${
              activeTab === 'claims'
                ? 'bg-white/15 text-[#F3BA2F] font-bold border-b-2 border-[#F3BA2F]'
                : 'text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-emerald-400" />
              Claim Center
              {claimCount > 0 && (
                <span className="px-1.5 py-0.2 text-[10px] bg-emerald-500 text-white font-bold rounded-full">
                  {claimCount}
                </span>
              )}
            </span>
          </button>

          {isAdmin && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`px-3 py-2 rounded-lg font-medium transition-all ${
                activeTab === 'admin'
                  ? 'bg-purple-600/30 text-purple-200 font-bold border-b-2 border-purple-400'
                  : 'text-purple-200 hover:text-white hover:bg-purple-600/20'
              }`}
            >
              <span className="flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-purple-300" />
                Admin Treasury
              </span>
            </button>
          )}

          <button
            onClick={() => setActiveTab('faq')}
            className={`px-3 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'faq'
                ? 'bg-white/15 text-[#F3BA2F] font-bold border-b-2 border-[#F3BA2F]'
                : 'text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            Help
          </button>
        </nav>

        {/* Right Actions: Auth State & AI Advisor */}
        <div className="flex items-center gap-2">
          {/* AI Advisor Button */}
          <button
            onClick={openAiAdvisor}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-[#F3BA2F] text-[#002B5C] font-bold text-xs shadow hover:brightness-105 active:scale-95 transition-all"
            title="Ask SmartInsure AI Advisor"
          >
            <Sparkles className="w-3.5 h-3.5 fill-[#002B5C]" />
            <span className="hidden sm:inline">AI Advisor</span>
          </button>

          {/* Authentication UI: Authenticated Dropdown vs Unauthenticated Sign In & Register */}
          {customer ? (
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-semibold text-white transition-all shadow-sm"
              >
                <div className="w-6 h-6 rounded-full bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-black text-[11px] shadow-sm">
                  {customer.fullName ? customer.fullName.trim().charAt(0).toUpperCase() : 'U'}
                </div>
                <span className="hidden sm:inline max-w-[130px] truncate font-medium">
                  {customer.fullName}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-300 transition-transform duration-200" />
              </button>

              {/* Authenticated User Dropdown Menu */}
              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200 text-slate-800 text-xs py-2 z-50 animate-in fade-in">
                  <div className="px-4 py-3 border-b border-slate-100 bg-slate-50 rounded-t-2xl">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                        Active Account
                      </span>
                      {customer.role === 'admin' ? (
                        <span className="text-[9px] bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full font-bold border border-purple-200">
                          Administrator
                        </span>
                      ) : (
                        <span className="text-[9px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold border border-emerald-200">
                          Policyholder
                        </span>
                      )}
                    </div>
                    <p className="font-bold text-[#002B5C] text-sm truncate">{customer.fullName}</p>
                    <p className="text-slate-500 text-[11px] truncate">{customer.email}</p>
                    {customer.panNumber && (
                      <div className="mt-1.5 flex items-center gap-1.5">
                        <span className="text-[10px] font-mono bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-bold">
                          PAN: {customer.panNumber}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="p-1.5 space-y-1">
                    <button
                      onClick={() => {
                        setActiveTab('dashboard');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 text-slate-700 font-medium flex items-center gap-2.5 transition-colors"
                    >
                      <UserCheck className="w-4 h-4 text-blue-700" />
                      <span>My Profile &amp; Policies</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('claims');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 text-slate-700 font-medium flex items-center gap-2.5 transition-colors"
                    >
                      <FileText className="w-4 h-4 text-emerald-600" />
                      <span>Claim Center</span>
                    </button>

                    {isAdmin && (
                      <button
                        onClick={() => {
                          setActiveTab('admin');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-purple-50 text-purple-900 font-medium flex items-center gap-2.5 transition-colors"
                      >
                        <ShieldAlert className="w-4 h-4 text-purple-700" />
                        <span>Admin Treasury Ledger</span>
                      </button>
                    )}
                  </div>

                  <div className="pt-1.5 border-t border-slate-100 p-1.5">
                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        onSignOut();
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-rose-50 text-rose-700 font-bold flex items-center gap-2.5 transition-colors"
                    >
                      <LogOut className="w-4 h-4 text-rose-600" />
                      <span>Logout</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="hidden sm:flex items-center gap-2">
              <button
                onClick={() => onOpenAuth('login')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-semibold text-white transition-all shadow-sm"
              >
                <LogIn className="w-3.5 h-3.5 text-slate-200" />
                <span>Sign In</span>
              </button>

              <button
                onClick={() => onOpenAuth('register')}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#F3BA2F] hover:bg-[#e0aa28] text-[#002B5C] font-extrabold text-xs shadow-md transition-all active:scale-95"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Register</span>
              </button>

              <button
                onClick={() => onOpenAuth('admin')}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-900/40 hover:bg-purple-900/60 border border-purple-400/30 text-purple-200 text-xs font-medium transition-all"
                title="Institutional Administrator Login"
              >
                <Lock className="w-3 h-3 text-purple-300" />
                <span className="hidden xl:inline">Admin</span>
              </button>
            </div>
          )}

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-200 hover:text-white hover:bg-white/10"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#001D40] border-t border-white/10 px-4 py-3 space-y-2 text-xs">
          {customer ? (
            <div className="p-3 bg-white/10 rounded-xl mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-black text-xs">
                  {customer.fullName ? customer.fullName.trim().charAt(0).toUpperCase() : 'U'}
                </div>
                <div>
                  <p className="font-bold text-white text-xs">{customer.fullName}</p>
                  <p className="text-[10px] text-slate-300 truncate">{customer.email}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onSignOut();
                }}
                className="px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 font-bold text-[11px] flex items-center gap-1"
              >
                <LogOut className="w-3 h-3" />
                <span>Logout</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 pb-2 border-b border-white/10">
              <button
                onClick={() => { onOpenAuth('login'); setMobileMenuOpen(false); }}
                className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-white/15 text-white font-bold"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
              <button
                onClick={() => { onOpenAuth('register'); setMobileMenuOpen(false); }}
                className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-[#F3BA2F] text-[#002B5C] font-extrabold shadow"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Register</span>
              </button>
            </div>
          )}

          <button
            onClick={() => { setActiveTab('plans'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium ${
              activeTab === 'plans' ? 'bg-[#002B5C] text-[#F3BA2F]' : 'text-slate-200'
            }`}
          >
            <span className="flex items-center gap-2"><Layers className="w-4 h-4" /> Insurance Plans</span>
          </button>

          <button
            onClick={() => { setActiveTab('calculator'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium ${
              activeTab === 'calculator' ? 'bg-[#002B5C] text-[#F3BA2F]' : 'text-slate-200'
            }`}
          >
            <span className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-amber-300" /> Smart Calculator</span>
          </button>

          <button
            onClick={() => { setActiveTab('dashboard'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium ${
              activeTab === 'dashboard' ? 'bg-[#002B5C] text-[#F3BA2F]' : 'text-slate-200'
            }`}
          >
            <span className="flex items-center gap-2"><UserCheck className="w-4 h-4 text-cyan-400" /> My Policies &amp; Payments</span>
            {customer && (
              <span className="px-2 py-0.5 text-[10px] bg-cyan-800 text-white rounded-full">{userPolicyCount} Active</span>
            )}
          </button>

          <button
            onClick={() => { setActiveTab('claims'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium ${
              activeTab === 'claims' ? 'bg-[#002B5C] text-[#F3BA2F]' : 'text-slate-200'
            }`}
          >
            <span className="flex items-center gap-2"><FileText className="w-4 h-4 text-emerald-400" /> Claim Center</span>
            {claimCount > 0 && (
              <span className="px-2 py-0.5 text-[10px] bg-emerald-600 text-white rounded-full">{claimCount}</span>
            )}
          </button>

          {isAdmin && (
            <button
              onClick={() => { setActiveTab('admin'); setMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg font-medium ${
                activeTab === 'admin' ? 'bg-purple-900/60 text-purple-200' : 'text-slate-200'
              }`}
            >
              <span className="flex items-center gap-2"><ShieldAlert className="w-4 h-4 text-purple-300" /> Admin Treasury Ledger</span>
            </button>
          )}

          {!customer && (
            <button
              onClick={() => { onOpenAuth('admin'); setMobileMenuOpen(false); }}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg font-medium text-purple-300 hover:bg-purple-900/40"
            >
              <span className="flex items-center gap-2"><Lock className="w-3.5 h-3.5" /> Institutional Admin Access</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
}
