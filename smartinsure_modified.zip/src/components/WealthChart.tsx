import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  ArcElement
} from 'chart.js';
import { Line, Doughnut } from 'react-chartjs-2';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  ArcElement
);

interface WealthChartProps {
  annualPremium: number;
  policyTerm: number;
  premiumTerm: number;
  expectedReturnRate: number;
  sumAssured: number;
  category: string;
}

export default function WealthChart({
  annualPremium,
  policyTerm,
  premiumTerm,
  expectedReturnRate,
  sumAssured,
  category
}: WealthChartProps) {
  // Generate projection points for each year
  const labels: string[] = [];
  const cumulativeInvested: number[] = [];
  const estimatedWealth: number[] = [];
  const lifeCoverTrajectory: number[] = [];

  let currentWealth = 0;
  let currentInvested = 0;
  const growthRate = expectedReturnRate > 0 ? expectedReturnRate / 100 : 0.06;

  for (let year = 1; year <= policyTerm; year++) {
    labels.push(`Yr ${year}`);

    // Premium accumulation
    if (year <= premiumTerm) {
      currentInvested += annualPremium;
      // Add compound growth + bonus addition
      currentWealth = (currentWealth + annualPremium) * (1 + growthRate);
    } else {
      // Compounding without new premium
      currentWealth = currentWealth * (1 + growthRate);
    }

    cumulativeInvested.push(Math.round(currentInvested));

    // For pure term, wealth accumulation is 0, but life cover stays constant
    if (category === 'term') {
      estimatedWealth.push(0);
    } else {
      estimatedWealth.push(Math.round(currentWealth));
    }

    lifeCoverTrajectory.push(sumAssured);
  }

  const lineData = {
    labels,
    datasets: [
      {
        label: 'Total Premium Paid (₹)',
        data: cumulativeInvested,
        borderColor: '#94A3B8',
        backgroundColor: 'rgba(148, 163, 184, 0.1)',
        borderDash: [5, 5],
        tension: 0.2,
        fill: false,
        pointRadius: 2
      },
      {
        label: category === 'term' ? 'Tax-Free Life Cover (₹)' : 'Projected Maturity Value (₹)',
        data: category === 'term' ? lifeCoverTrajectory : estimatedWealth,
        borderColor: '#F3BA2F',
        backgroundColor: 'rgba(243, 186, 47, 0.15)',
        tension: 0.3,
        fill: true,
        pointBackgroundColor: '#002B5C',
        pointBorderColor: '#F3BA2F',
        pointHoverRadius: 6
      }
    ]
  };

  const lineOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          boxWidth: 14,
          font: {
            family: 'Roboto',
            size: 11
          }
        }
      },
      tooltip: {
        callbacks: {
          label: function (context: any) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += new Intl.NumberFormat('en-IN', {
                style: 'currency',
                currency: 'INR',
                maximumFractionDigits: 0
              }).format(context.parsed.y);
            }
            return label;
          }
        }
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        grid: {
          color: '#E2E8F0'
        },
        ticks: {
          callback: function (value: any) {
            if (value >= 10000000) return '₹' + (value / 10000000).toFixed(1) + ' Cr';
            if (value >= 100000) return '₹' + (value / 100000).toFixed(0) + ' L';
            return '₹' + value;
          }
        }
      }
    }
  };

  // Doughnut Chart for Risk Cover vs Investment vs Tax Savings
  const totalPaid = annualPremium * premiumTerm;
  const maturityVal = category === 'term' ? 0 : estimatedWealth[estimatedWealth.length - 1] || 0;
  const taxSavingsEst = Math.min(totalPaid * 0.3, 150000 * 0.3 * premiumTerm);

  const doughnutData = {
    labels: ['Total Capital Paid', 'Projected Growth & Bonus', 'Estimated Tax Saved (80C)'],
    datasets: [
      {
        data: [totalPaid, Math.max(0, maturityVal - totalPaid), taxSavingsEst],
        backgroundColor: ['#002B5C', '#F3BA2F', '#10B981'],
        borderWidth: 2,
        borderColor: '#FFFFFF'
      }
    ]
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          boxWidth: 12,
          font: {
            size: 11
          }
        }
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Line Chart: Timeline Growth */}
      <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-sm text-[#002B5C]">
              {category === 'term' ? 'Protection Trajectory' : 'Maturity & Wealth Compounding Trajectory'}
            </h3>
            <p className="text-xs text-slate-500">
              Guaranteed capital, accrued bonuses and projected payout across {policyTerm} years
            </p>
          </div>
          <span className="px-2.5 py-1 text-xs font-semibold rounded bg-[#F3BA2F]/15 text-[#002B5C] border border-[#F3BA2F]/30">
            {expectedReturnRate > 0 ? `${expectedReturnRate}% Est. Rate` : 'Pure Protection'}
          </span>
        </div>

        <div className="h-64 sm:h-72 w-full">
          <Line data={lineData} options={lineOptions} />
        </div>
      </div>

      {/* Doughnut Chart: Asset Breakdown */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
        <div>
          <h3 className="font-bold text-sm text-[#002B5C] mb-1">
            Financial Value Matrix
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Allocation between capital, investment return, and statutory tax deductions
          </p>

          <div className="h-48 w-full relative">
            <Doughnut data={doughnutData} options={doughnutOptions} />
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-500">100% Tax-Exempt Payout</p>
          <p className="text-xs font-bold text-emerald-700">Section 10(10D) Compliant</p>
        </div>
      </div>
    </div>
  );
}
