import { useState, useMemo } from 'react';
import { 
  ShieldCheck, 
  ArrowRight, 
  Check, 
  Award, 
  FileText, 
  HelpCircle, 
  Search, 
  SlidersHorizontal,
  ChevronRight,
  TrendingUp,
  Heart,
  Calendar,
  Zap,
  Percent,
  Download,
  Printer,
  X,
  Loader2
} from 'lucide-react';
import { ALL_POLICIES } from '../data/mockData';
import { Policy, UserPolicy } from '../types';
import { downloadElementAsPdf, triggerPrintDialog } from '../utils/pdfDownloader';

interface PolicyCatalogProps {
  onSelectPlanForCalculation: (planId: string) => void;
  onQuickBuy: (policy: UserPolicy) => void;
}

export default function PolicyCatalog({ onSelectPlanForCalculation, onQuickBuy }: PolicyCatalogProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [comparisonPlans, setComparisonPlans] = useState<string[]>([]);
  const [showComparisonModal, setShowComparisonModal] = useState<boolean>(false);
  const [brochureModalPlan, setBrochureModalPlan] = useState<Policy | null>(null);
  const [isGeneratingBrochurePdf, setIsGeneratingBrochurePdf] = useState(false);

  // Filtered policies
  const filteredPolicies = useMemo(() => {
    return ALL_POLICIES.filter(policy => {
      const matchCategory = selectedCategory === 'all' || policy.category === selectedCategory;
      const matchSearch = policy.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        policy.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
        policy.planNo.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCategory && matchSearch;
    });
  }, [selectedCategory, searchQuery]);

  const toggleCompare = (planId: string) => {
    if (comparisonPlans.includes(planId)) {
      setComparisonPlans(comparisonPlans.filter(id => id !== planId));
    } else {
      if (comparisonPlans.length >= 3) {
        alert('You can compare up to 3 plans side-by-side.');
        return;
      }
      setComparisonPlans([...comparisonPlans, planId]);
    }
  };

  const comparedPolicyObjects = useMemo(() => {
    return ALL_POLICIES.filter(p => comparisonPlans.includes(p.id));
  }, [comparisonPlans]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
      {/* Title & Filters */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#002B5C]/10 text-[#002B5C] text-xs font-bold mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-[#F3BA2F]" />
            Official Policy Directory &amp; Institutional Portfolios
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold font-['Poppins'] text-[#002B5C]">
            Explore All Insurance Plans
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Compare government-backed endowment guarantees, pure term life covers, child milestone planners, and health shields.
          </p>
        </div>

        {/* Search Bar & Comparison Trigger */}
        <div className="flex items-center gap-3">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search plans (e.g. 936, Term)..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#002B5C]"
            />
          </div>

          {comparisonPlans.length > 0 && (
            <button
              onClick={() => setShowComparisonModal(true)}
              className="px-4 py-2 rounded-xl bg-[#002B5C] text-[#F3BA2F] font-bold text-xs shadow-md hover:bg-[#001D40] transition-all flex items-center gap-1.5 shrink-0"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Compare ({comparisonPlans.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 no-scrollbar">
        {[
          { id: 'all', label: 'All Portfolios (6)' },
          { id: 'term', label: 'Term Life Protection' },
          { id: 'endowment', label: 'Guaranteed Endowment' },
          { id: 'child', label: 'Child Future & Education' },
          { id: 'pension', label: 'Pension & Annuity' },
          { id: 'health', label: 'Critical Health Shield' },
          { id: 'ulip', label: 'Market ULIP Wealth' }
        ].map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCategory === cat.id
                ? 'bg-[#002B5C] text-white shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Policies Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPolicies.map(policy => {
          const isCompared = comparisonPlans.includes(policy.id);

          return (
            <div
              key={policy.id}
              className="bg-white rounded-2xl border border-slate-200 hover:border-[#002B5C]/50 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between overflow-hidden group"
            >
              {/* Card Top */}
              <div>
                {/* Header Strip */}
                <div className="bg-gradient-to-r from-[#002B5C] to-[#003875] text-white p-4 flex items-center justify-between">
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-[#F3BA2F] text-[#002B5C]">
                    {policy.planNo}
                  </span>
                  <div className="flex items-center gap-2">
                    {policy.governmentBacked && (
                      <span className="text-[10px] font-semibold text-amber-300 flex items-center gap-0.5">
                        <Award className="w-3 h-3" /> Sovereign
                      </span>
                    )}
                    {policy.popular && (
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 bg-emerald-500 text-white rounded-full">
                        Most Popular
                      </span>
                    )}
                  </div>
                </div>

                {/* Body Content */}
                <div className="p-5">
                  <h3 className="text-base font-bold text-[#002B5C] group-hover:text-blue-900 transition-colors font-['Poppins']">
                    {policy.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed min-h-[36px]">
                    {policy.tagline}
                  </p>

                  {/* Highlights Grid */}
                  <div className="grid grid-cols-2 gap-2 my-4 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                    <div>
                      <p className="text-[10px] text-slate-400 font-semibold uppercase">Min - Max Age</p>
                      <p className="font-bold text-slate-800">{policy.minAge} to {policy.maxAge} yrs</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 font-semibold uppercase">Min Sum Assured</p>
                      <p className="font-bold text-slate-800">₹{(policy.minSumAssured / 100000).toFixed(0)} Lakhs</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 font-semibold uppercase">Policy Term</p>
                      <p className="font-bold text-slate-800">{policy.minTerm} to {policy.maxTerm} yrs</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 font-semibold uppercase">Tax Exemption</p>
                      <p className="font-bold text-emerald-700">{policy.taxBenefitSection}</p>
                    </div>
                  </div>

                  {/* Key Features List */}
                  <div className="space-y-1.5 mb-4">
                    <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Key Advantages:</p>
                    {policy.features.slice(0, 3).map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-600">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="p-5 pt-0 space-y-2 border-t border-slate-100">
                <div className="pt-3 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setBrochureModalPlan(policy)}
                    className="flex items-center gap-1 text-xs text-slate-600 hover:text-[#002B5C] font-semibold"
                  >
                    <Download className="w-3.5 h-3.5 text-slate-400" />
                    <span>Brochure</span>
                  </button>

                  <button
                    onClick={() => toggleCompare(policy.id)}
                    className={`text-xs font-semibold px-2 py-1 rounded border transition-all ${
                      isCompared
                        ? 'bg-amber-100 text-amber-800 border-amber-300'
                        : 'text-slate-500 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {isCompared ? '✓ Selected' : '+ Compare'}
                  </button>
                </div>

                <button
                  onClick={() => onSelectPlanForCalculation(policy.id)}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#002B5C] hover:bg-[#001D40] text-[#F3BA2F] font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-all group-hover:shadow"
                >
                  <span>Calculate Custom Quote</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Comparison Modal */}
      {showComparisonModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="bg-[#002B5C] text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-[#F3BA2F]" />
                <h3 className="font-bold text-base font-['Poppins']">
                  Side-by-Side Insurance Policy Comparison
                </h3>
              </div>
              <button
                onClick={() => setShowComparisonModal(false)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Comparison Table */}
            <div className="p-6 overflow-y-auto space-y-6">
              <div className="grid grid-cols-4 gap-4 pb-4 border-b border-slate-200 text-xs">
                <div className="font-bold text-slate-400 uppercase">Policy Metric</div>
                {comparedPolicyObjects.map(p => (
                  <div key={p.id} className="text-center font-bold text-[#002B5C]">
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 mr-1">{p.planNo}</span>
                    <p className="mt-1 font-['Poppins']">{p.name}</p>
                  </div>
                ))}
              </div>

              {/* Rows */}
              <div className="space-y-3 text-xs">
                <div className="grid grid-cols-4 gap-4 py-2 border-b border-slate-100">
                  <span className="font-semibold text-slate-600">Category</span>
                  {comparedPolicyObjects.map(p => (
                    <span key={p.id} className="text-center font-medium capitalize">{p.category}</span>
                  ))}
                </div>

                <div className="grid grid-cols-4 gap-4 py-2 border-b border-slate-100">
                  <span className="font-semibold text-slate-600">Eligible Age Range</span>
                  {comparedPolicyObjects.map(p => (
                    <span key={p.id} className="text-center font-medium">{p.minAge} - {p.maxAge} Years</span>
                  ))}
                </div>

                <div className="grid grid-cols-4 gap-4 py-2 border-b border-slate-100">
                  <span className="font-semibold text-slate-600">Sum Assured Range</span>
                  {comparedPolicyObjects.map(p => (
                    <span key={p.id} className="text-center font-medium">₹{(p.minSumAssured / 100000).toFixed(0)}L to ₹{(p.maxSumAssured / 10000000).toFixed(1)}Cr</span>
                  ))}
                </div>

                <div className="grid grid-cols-4 gap-4 py-2 border-b border-slate-100">
                  <span className="font-semibold text-slate-600">Term Options</span>
                  {comparedPolicyObjects.map(p => (
                    <span key={p.id} className="text-center font-medium">{p.minTerm} to {p.maxTerm} Years</span>
                  ))}
                </div>

                <div className="grid grid-cols-4 gap-4 py-2 border-b border-slate-100">
                  <span className="font-semibold text-slate-600">Tax Benefit Sections</span>
                  {comparedPolicyObjects.map(p => (
                    <span key={p.id} className="text-center font-bold text-emerald-700">{p.taxBenefitSection}</span>
                  ))}
                </div>

                <div className="grid grid-cols-4 gap-4 py-2 border-b border-slate-100">
                  <span className="font-semibold text-slate-600">Sovereign Security</span>
                  {comparedPolicyObjects.map(p => (
                    <span key={p.id} className="text-center font-bold text-amber-700">
                      {p.governmentBacked ? '✓ 100% Guaranteed' : 'Market Governed'}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-4 gap-4 pt-4">
                <div></div>
                {comparedPolicyObjects.map(p => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setShowComparisonModal(false);
                      onSelectPlanForCalculation(p.id);
                    }}
                    className="py-2 px-3 rounded-xl bg-[#002B5C] text-[#F3BA2F] font-bold text-xs shadow hover:bg-[#001D40] transition-all"
                  >
                    Select Plan
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Brochure Preview Modal */}
      {brochureModalPlan && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 print:p-0 print:bg-white print:static">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border-4 border-[#002B5C] overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in printable-document print:border-2 print:border-slate-800 print:max-h-none print:shadow-none print:rounded-none">
            {/* Top Action Bar (Hidden in Print) */}
            <div className="bg-[#002B5C] text-white p-4 px-6 flex items-center justify-between border-b-4 border-[#F3BA2F] no-print">
              <div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#F3BA2F] text-[#002B5C] uppercase">
                  Official Brochure
                </span>
                <h3 className="font-bold text-base mt-1 font-['Poppins'] text-white">
                  {brochureModalPlan.name} ({brochureModalPlan.planNo})
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={async () => {
                    await downloadElementAsPdf(
                      'policy-brochure-document',
                      `SmartInsure_Brochure_${brochureModalPlan.name.replace(/\s+/g, '_')}_Plan_${brochureModalPlan.planNo}`,
                      setIsGeneratingBrochurePdf
                    );
                  }}
                  disabled={isGeneratingBrochurePdf}
                  className="px-3.5 py-1.5 rounded-lg bg-[#F3BA2F] hover:bg-amber-400 text-[#002B5C] text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 disabled:opacity-50"
                  title="Download Brochure PDF directly"
                >
                  {isGeneratingBrochurePdf ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{isGeneratingBrochurePdf ? 'Exporting...' : 'Download PDF'}</span>
                </button>

                <button
                  onClick={triggerPrintDialog}
                  className="px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
                  title="Print Brochure / Specification"
                >
                  <Printer className="w-4 h-4 text-[#F3BA2F]" />
                  <span className="hidden sm:inline">Print</span>
                </button>
                <button
                  onClick={() => setBrochureModalPlan(null)}
                  className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
                  title="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div 
              id="policy-brochure-document"
              className="p-8 overflow-y-auto space-y-6 text-xs text-slate-700 bg-[radial-gradient(#f1f5f9_1px,transparent_1px)] [background-size:16px_16px] printable-content print:p-6 print:overflow-visible print:bg-white"
            >
              {/* Institutional Header */}
              <div className="text-center pb-4 border-b-2 border-slate-300">
                <div className="flex items-center justify-center gap-2">
                  <span className="text-xl font-black text-[#002B5C] font-['Poppins'] tracking-tight">
                    Smart<span className="text-[#d99f18]">Insure</span>
                  </span>
                  <span className="text-[10px] uppercase font-bold bg-[#002B5C] text-white px-2 py-0.5 rounded">
                    Product Specification
                  </span>
                </div>
                <p className="text-[11px] font-bold uppercase tracking-widest text-[#002B5C] mt-1">
                  SmartInsure National Life Assurance Corporation of India
                </p>
                <p className="text-lg font-black text-slate-900 font-['Poppins'] mt-1">
                  {brochureModalPlan.name.toUpperCase()} (TABLE NO. {brochureModalPlan.planNo})
                </p>
                <p className="text-xs text-slate-600 font-mono mt-0.5">
                  UIN: 512N{brochureModalPlan.planNo}V02 • IRDAI Registered Assurance Plan
                </p>
              </div>

              {/* Tagline / Overview */}
              <div className="p-3.5 bg-blue-50/80 rounded-xl border border-blue-200">
                <p className="font-semibold text-blue-950 text-xs leading-relaxed">
                  {brochureModalPlan.tagline}
                </p>
              </div>

              {/* Quick Eligibility Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Assurance Type</p>
                  <p className="font-bold text-[#002B5C] capitalize">{brochureModalPlan.category}</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Entry Age</p>
                  <p className="font-bold text-slate-800">{brochureModalPlan.minAge} - {brochureModalPlan.maxAge} Years</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Policy Term</p>
                  <p className="font-bold text-slate-800">{brochureModalPlan.minTerm} - {brochureModalPlan.maxTerm} Years</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Tax Exemption</p>
                  <p className="font-bold text-emerald-700">{brochureModalPlan.taxBenefitSection}</p>
                </div>
              </div>

              {/* Actuarial Specification */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-[#002B5C] uppercase text-[11px] tracking-wider border-b border-slate-100 pb-1">
                  Key Actuarial Features &amp; Coverage:
                </h4>
                <ul className="list-disc list-inside space-y-1.5 text-slate-700">
                  {brochureModalPlan.features.map((f, i) => (
                    <li key={i}>{f}</li>
                  ))}
                </ul>
              </div>

              {/* Key Benefits */}
              <div className="space-y-2">
                <h4 className="font-bold text-[#002B5C] uppercase text-[11px] tracking-wider">
                  Maturity, Survival &amp; Death Clauses:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {brochureModalPlan.keyBenefits.map((b, i) => (
                    <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                      <p className="font-bold text-[#002B5C] text-xs">{b.title}</p>
                      <p className="text-slate-600 mt-1 text-[11px] leading-relaxed">{b.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Statutory Note */}
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-950 leading-relaxed">
                <strong>Statutory Notice:</strong> Insurance is the subject matter of solicitation. For complete terms, exclusions, and waiting periods, please refer to the policy schedule document.
              </div>

              {/* Footer Modal Actions (Hidden in Print) */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-between no-print">
                <button
                  type="button"
                  onClick={() => setBrochureModalPlan(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 font-semibold text-slate-700 text-xs"
                >
                  Close Preview
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const planId = brochureModalPlan.id;
                    setBrochureModalPlan(null);
                    onSelectPlanForCalculation(planId);
                  }}
                  className="px-5 py-2 rounded-xl bg-[#002B5C] text-[#F3BA2F] font-bold text-xs shadow hover:bg-[#001D40] transition-all"
                >
                  Calculate Premium For This Plan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
