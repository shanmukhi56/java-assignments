import { Shield, PhoneCall, Mail, MapPin, Award, Lock, ExternalLink, HeartHandshake } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: 'plans' | 'calculator' | 'claims' | 'dashboard' | 'faq') => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-[#001D40] text-slate-300 text-xs border-t-4 border-[#F3BA2F] no-print">
      {/* Top Institutional Pillar Bar */}
      <div className="border-b border-white/10 py-6 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 text-slate-300">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#002B5C] border border-[#F3BA2F]/40 flex items-center justify-center text-[#F3BA2F]">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-sm font-['Poppins']">IRDAI Regulated &amp; Verified</p>
              <p className="text-[11px] text-slate-400">Statutory protection and sovereign fund guarantee</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#002B5C] border border-[#F3BA2F]/40 flex items-center justify-center text-[#F3BA2F]">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-sm font-['Poppins']">24x7 Claim Hotline</p>
              <p className="text-[11px] text-amber-300 font-semibold">1800-762-784 (1800-SMART-INS)</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#002B5C] border border-[#F3BA2F]/40 flex items-center justify-center text-[#F3BA2F]">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-sm font-['Poppins']">256-Bit Bank Grade Encryption</p>
              <p className="text-[11px] text-slate-400">Digital policy bond vault with biometric verification</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-10 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Column */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-[#F3BA2F]" />
            <span className="text-lg font-bold text-white font-['Poppins']">
              Smart<span className="text-[#F3BA2F]">Insure</span>
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Smart Insurance Policy Recommendation, Lifecycle Management &amp; Claim Settlement System. Securing families with institutional trust across India.
          </p>
          <div className="pt-2 text-[10px] text-slate-500 space-y-1">
            <p>IRDAI Registration No: 512 / LIFE / 2026</p>
            <p>CIN: L66010DL2026GOI094821</p>
          </div>
        </div>

        {/* Insurance Plans */}
        <div>
          <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-3 font-['Poppins']">
            Insurance Portfolios
          </h4>
          <ul className="space-y-2 text-slate-400">
            <li>
              <button onClick={() => onNavigate('plans')} className="hover:text-[#F3BA2F] transition-colors">
                Smart Rakshak Pure Term (Plan 914)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('plans')} className="hover:text-[#F3BA2F] transition-colors">
                Smart Jeevan Labh Endowment (Plan 936)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('plans')} className="hover:text-[#F3BA2F] transition-colors">
                Smart Vidya Child Future (Plan 948)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('plans')} className="hover:text-[#F3BA2F] transition-colors">
                Smart Shanti Pension Annuity (Plan 858)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('plans')} className="hover:text-[#F3BA2F] transition-colors">
                Smart Swasthya Critical Shield (Plan 905)
              </button>
            </li>
          </ul>
        </div>

        {/* Customer Services */}
        <div>
          <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-3 font-['Poppins']">
            Customer Services
          </h4>
          <ul className="space-y-2 text-slate-400">
            <li>
              <button onClick={() => onNavigate('calculator')} className="hover:text-[#F3BA2F] transition-colors">
                Instant Premium &amp; Maturity Calculator
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('claims')} className="hover:text-[#F3BA2F] transition-colors">
                Track Live Claim Pipeline
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('claims')} className="hover:text-[#F3BA2F] transition-colors">
                Intimate Cashless / Reimbursement Claim
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('dashboard')} className="hover:text-[#F3BA2F] transition-colors">
                Download Digital Policy Bond
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('dashboard')} className="hover:text-[#F3BA2F] transition-colors">
                Pay Online Renewal Premium
              </button>
            </li>
          </ul>
        </div>

        {/* Grievance & Ombudsman */}
        <div>
          <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-3 font-['Poppins']">
            Grievance Redressal
          </h4>
          <div className="space-y-2 text-slate-400 text-[11px]">
            <p>
              <strong className="text-white">Principal Grievance Officer:</strong><br />
              SmartInsure Towers, Barakhamba Road, Connaught Place, New Delhi 110001
            </p>
            <p>
              <strong className="text-white">Email:</strong> grievance@smartinsure.gov.in
            </p>
            <p>
              <strong className="text-white">IRDAI Bima Bharosa:</strong> 155255 / 1800-4254-732
            </p>
          </div>
        </div>
      </div>

      {/* Statutory Disclaimer & Copyright */}
      <div className="bg-[#00132B] py-5 px-4 sm:px-8 border-t border-white/5 text-[10px] text-slate-500 leading-relaxed">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p>
            © {new Date().getFullYear()} SmartInsure Life Assurance Corporation. All rights reserved. Insurance is the subject matter of solicitation.
          </p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Privacy Policy</span>
            <span>•</span>
            <span>Terms of Use</span>
            <span>•</span>
            <span>Public Disclosures</span>
            <span>•</span>
            <span>Whistle Blower Policy</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
