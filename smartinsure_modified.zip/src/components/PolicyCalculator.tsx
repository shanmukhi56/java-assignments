import { useState, useMemo } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  Calendar, 
  Percent, 
  Award, 
  Check, 
  Zap, 
  CheckCircle2, 
  AlertCircle,
  TrendingUp,
  Heart,
  Download,
  Printer,
  Loader2
} from 'lucide-react';
import { ALL_POLICIES } from '../data/mockData';
import { Policy, UserPolicy } from '../types';
import WealthChart from './WealthChart';
import { downloadElementAsPdf, triggerPrintDialog } from '../utils/pdfDownloader';

interface PolicyCalculatorProps {
  onBuyPolicy: (policy: UserPolicy) => void;
  onNavigateToClaims: () => void;
}

export default function PolicyCalculator({ onBuyPolicy }: PolicyCalculatorProps) {
  // Input State
  const [age, setAge] = useState<number>(30);
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('male');
  const [annualIncome, setAnnualIncome] = useState<number>(1000000); // 10 Lakhs
  const [tobaccoUser, setTobaccoUser] = useState<boolean>(false);
  const [goal, setGoal] = useState<'protection' | 'guaranteed' | 'child' | 'retirement' | 'health' | 'wealth'>('guaranteed');
  const [selectedPlanId, setSelectedPlanId] = useState<string>('smart-jeevan-labh');
  const [sumAssured, setSumAssured] = useState<number>(1500000); // 15 Lakhs
  const [policyTerm, setPolicyTerm] = useState<number>(20);
  const [premiumTerm, setPremiumTerm] = useState<number>(15);
  const [isGeneratingQuotePdf, setIsGeneratingQuotePdf] = useState(false);

  // Riders
  const [accidentalRider, setAccidentalRider] = useState<boolean>(true);
  const [criticalRider, setCriticalRider] = useState<boolean>(false);
  const [waiverRider, setWaiverRider] = useState<boolean>(false);

  // Selected Policy Object
  const currentPlan = useMemo(() => {
    return ALL_POLICIES.find(p => p.id === selectedPlanId) || ALL_POLICIES[1];
  }, [selectedPlanId]);

  // Recommended Sum Assured using HLV (Human Life Value = 15x annual income)
  const recommendedHLV = useMemo(() => {
    return annualIncome * 15;
  }, [annualIncome]);

  // Actuarial Premium Calculation
  const calculation = useMemo(() => {
    let baseRate = currentPlan.baseRatePerThousand;
    
    // Age multiplier
    const ageFactor = 1 + (age - 25) * 0.025;
    
    // Tobacco surcharge (+30%)
    const tobaccoMultiplier = tobaccoUser ? 1.3 : 0.95;
    
    // Gender discount (Females get 10% lower mortality rates)
    const genderDiscount = gender === 'female' ? 0.9 : 1.0;

    let baseAnnual = (sumAssured / 1000) * baseRate * Math.max(0.6, ageFactor) * tobaccoMultiplier * genderDiscount;

    // Add Rider costs
    let riderCost = 0;
    if (accidentalRider) {
      riderCost += (sumAssured / 1000) * 0.75; // ₹0.75 per ₹1000
    }
    if (criticalRider) {
      riderCost += (Math.min(sumAssured, 2500000) / 1000) * 2.5; // ₹2.50 per ₹1000
    }
    if (waiverRider) {
      riderCost += baseAnnual * 0.04; // 4% of premium
    }

    const totalAnnual = Math.round(baseAnnual + riderCost);
    const monthlyEq = Math.round((totalAnnual * 1.03) / 12);
    const totalInvested = totalAnnual * premiumTerm;

    // Projected Maturity Calculation
    let projectedMaturity = 0;
    if (currentPlan.category === 'term') {
      projectedMaturity = 0; // Pure risk
    } else {
      const growthRate = currentPlan.expectedReturnRate / 100;
      let cumWealth = 0;
      for (let yr = 1; yr <= policyTerm; yr++) {
        if (yr <= premiumTerm) {
          cumWealth = (cumWealth + totalAnnual) * (1 + growthRate);
        } else {
          cumWealth = cumWealth * (1 + growthRate);
        }
      }
      projectedMaturity = Math.round(cumWealth);
    }

    const taxSavings = Math.min(totalAnnual, 150000) * 0.3; // 30% slab benefit

    return {
      annualPremium: totalAnnual,
      monthlyPremium: monthlyEq,
      totalInvested,
      projectedMaturity,
      taxSavings
    };
  }, [currentPlan, sumAssured, age, tobaccoUser, gender, accidentalRider, criticalRider, waiverRider, premiumTerm, policyTerm]);

  // Initiate purchase flow
  const handleInitiateBuy = () => {
    const newPolicyNumber = `POL-${Math.floor(100000000 + Math.random() * 900000000)}`;
    const today = new Date().toISOString().split('T')[0];
    const matureDate = new Date();
    matureDate.setFullYear(matureDate.getFullYear() + policyTerm);

    const nextDue = new Date();
    nextDue.setFullYear(nextDue.getFullYear() + 1);

    const basePrem = calculation.annualPremium;
    const gstAmt = Math.round(basePrem * 0.18);
    const totalPrem = basePrem + gstAmt;

    const userPol: UserPolicy = {
      id: `usr-pol-${Date.now()}`,
      customerId: 'cust-current',
      customerName: 'Authenticated Customer',
      policyNumber: newPolicyNumber,
      policyId: currentPlan.id,
      policyName: currentPlan.name,
      category: currentPlan.category.toUpperCase(),
      sumAssured: sumAssured,
      premiumAmount: basePrem,
      gstAmount: gstAmt,
      totalPremiumPayable: totalPrem,
      premiumFrequency: 'Yearly',
      startDate: today,
      maturityDate: matureDate.toISOString().split('T')[0],
      nextDueDate: nextDue.toISOString().split('T')[0],
      status: 'Active',
      nomineeName: 'Designated Family Nominee',
      nomineeRelation: 'Immediate Family (100% Share)',
      paidInstallments: 1,
      totalInstallments: premiumTerm,
      accumulatedBonus: 0,
      surrenderValue: 0
    };

    onBuyPolicy(userPol);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
      {/* Title Header */}
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#002B5C]/10 text-[#002B5C] text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-[#F3BA2F]" />
            Actuarial Premium &amp; Maturity Recommendation Engine
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold font-['Poppins'] text-[#002B5C]">
            Interactive Smart Policy Quote Calculator
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Customize coverage parameters, test optional riders, visualize compound bonuses, and generate real-time quotes.
          </p>
        </div>

        {/* Human Life Value Quick Stat */}
        <div className="bg-[#002B5C] text-white px-4 py-3 rounded-xl shadow-md border border-[#F3BA2F]/40 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] text-amber-200">Recommended Life Cover (15x HLV)</p>
            <p className="text-lg font-black text-white font-['Poppins']">
              ₹{(recommendedHLV / 100000).toFixed(0)} Lakhs ({(recommendedHLV / 10000000).toFixed(2)} Cr)
            </p>
          </div>
        </div>
      </div>

      {/* Main 2-Column Calculator Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Inputs Panel (7 Cols) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-7 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          {/* Goal Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              1. Select Your Primary Financial &amp; Protection Goal
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'protection', label: 'Pure Life Cover', icon: ShieldCheck, plan: 'smart-rakshak-pure-term' },
                { id: 'guaranteed', label: 'Guaranteed Savings', icon: TrendingUp, plan: 'smart-jeevan-labh' },
                { id: 'child', label: 'Child Education', icon: Heart, plan: 'smart-vidya-child-future' },
                { id: 'retirement', label: 'Pension & Annuity', icon: Calendar, plan: 'smart-shanti-guaranteed-pension' },
                { id: 'health', label: 'Critical Illness Shield', icon: Zap, plan: 'smart-swasthya-critical-shield' },
                { id: 'wealth', label: 'Market Wealth ULIP', icon: Percent, plan: 'smart-sampatti-wealth-ulip' }
              ].map(item => {
                const Icon = item.icon;
                const active = goal === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setGoal(item.id as any);
                      setSelectedPlanId(item.plan);
                    }}
                    className={`flex items-center gap-2 p-3 rounded-xl border text-left text-xs font-semibold transition-all ${
                      active
                        ? 'bg-[#002B5C] text-white border-[#002B5C] shadow-sm'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#F3BA2F]' : 'text-[#002B5C]'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Personal Profile Row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-100">
            {/* Age */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Age: <span className="font-bold text-[#002B5C]">{age} years</span>
              </label>
              <input
                type="range"
                min="18"
                max="65"
                value={age}
                onChange={e => setAge(Number(e.target.value))}
                className="w-full accent-[#002B5C]"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>18 yrs</span>
                <span>65 yrs</span>
              </div>
            </div>

            {/* Gender */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">Gender</label>
              <div className="grid grid-cols-2 gap-1">
                <button
                  type="button"
                  onClick={() => setGender('male')}
                  className={`py-1.5 px-2 text-xs rounded-lg font-medium border ${
                    gender === 'male' ? 'bg-[#002B5C] text-white border-[#002B5C]' : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  Male
                </button>
                <button
                  type="button"
                  onClick={() => setGender('female')}
                  className={`py-1.5 px-2 text-xs rounded-lg font-medium border ${
                    gender === 'female' ? 'bg-[#002B5C] text-white border-[#002B5C]' : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  Female (-10%)
                </button>
              </div>
            </div>

            {/* Tobacco User */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">Tobacco / Smoking</label>
              <div className="grid grid-cols-2 gap-1">
                <button
                  type="button"
                  onClick={() => setTobaccoUser(false)}
                  className={`py-1.5 px-2 text-xs rounded-lg font-medium border ${
                    !tobaccoUser ? 'bg-emerald-700 text-white border-emerald-700' : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  Non-Smoker
                </button>
                <button
                  type="button"
                  onClick={() => setTobaccoUser(true)}
                  className={`py-1.5 px-2 text-xs rounded-lg font-medium border ${
                    tobaccoUser ? 'bg-rose-700 text-white border-rose-700' : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  Smoker
                </button>
              </div>
            </div>
          </div>

          {/* Annual Income */}
          <div className="pt-2 border-t border-slate-100">
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-semibold text-slate-600">Annual Gross Income</label>
              <span className="text-xs font-bold text-[#002B5C]">
                ₹{(annualIncome / 100000).toFixed(1)} Lakhs / year
              </span>
            </div>
            <input
              type="range"
              min="300000"
              max="10000000"
              step="100000"
              value={annualIncome}
              onChange={e => setAnnualIncome(Number(e.target.value))}
              className="w-full accent-[#002B5C]"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>₹3 Lakhs</span>
              <span>₹1 Crore</span>
            </div>
          </div>

          {/* Sum Assured Slider */}
          <div className="pt-2 border-t border-slate-100">
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-bold text-slate-700">
                Sum Assured (Life / Medical Cover)
              </label>
              <span className="text-sm font-extrabold text-[#002B5C] font-['Poppins']">
                {sumAssured >= 10000000 
                  ? `₹${(sumAssured / 10000000).toFixed(2)} Crore`
                  : `₹${(sumAssured / 100000).toFixed(0)} Lakhs`}
              </span>
            </div>
            <input
              type="range"
              min={currentPlan.minSumAssured}
              max={currentPlan.maxSumAssured}
              step={sumAssured >= 10000000 ? 500000 : 100000}
              value={sumAssured}
              onChange={e => setSumAssured(Number(e.target.value))}
              className="w-full accent-[#F3BA2F]"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Min: ₹{(currentPlan.minSumAssured / 100000).toFixed(0)} L</span>
              <span>Max: ₹{(currentPlan.maxSumAssured / 10000000).toFixed(1)} Cr</span>
            </div>
          </div>

          {/* Policy Term & Premium Payment Term */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Policy Coverage Term: <strong className="text-[#002B5C]">{policyTerm} Years</strong>
              </label>
              <select
                value={policyTerm}
                onChange={e => setPolicyTerm(Number(e.target.value))}
                className="w-full text-xs font-semibold p-2.5 rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-[#002B5C]"
              >
                <option value={10}>10 Years</option>
                <option value={15}>15 Years</option>
                <option value={16}>16 Years (Popular)</option>
                <option value={20}>20 Years</option>
                <option value={25}>25 Years</option>
                <option value={30}>30 Years</option>
                <option value={40}>40 Years (Whole Life)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Premium Paying Term: <strong className="text-[#002B5C]">{premiumTerm} Years</strong>
              </label>
              <select
                value={premiumTerm}
                onChange={e => setPremiumTerm(Number(e.target.value))}
                className="w-full text-xs font-semibold p-2.5 rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-[#002B5C]"
              >
                <option value={10}>10 Years (Limited Pay)</option>
                <option value={15}>15 Years</option>
                <option value={16}>16 Years</option>
                <option value={policyTerm}>Regular Pay ({policyTerm} Years)</option>
              </select>
            </div>
          </div>

          {/* Optional Institutional Riders */}
          <div className="pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Add Optional Protection Riders
            </label>
            <div className="space-y-2">
              <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-slate-300 cursor-pointer bg-slate-50">
                <div className="flex items-center gap-2.5">
                  <input
                    type="checkbox"
                    checked={accidentalRider}
                    onChange={e => setAccidentalRider(e.target.checked)}
                    className="w-4 h-4 text-[#002B5C] rounded"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-800">Accidental Death &amp; Disability Benefit Rider</p>
                    <p className="text-[11px] text-slate-500">2x Double Sum Assured in case of accidental eventuality</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#002B5C]">+₹750/yr</span>
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-slate-300 cursor-pointer bg-slate-50">
                <div className="flex items-center gap-2.5">
                  <input
                    type="checkbox"
                    checked={criticalRider}
                    onChange={e => setCriticalRider(e.target.checked)}
                    className="w-4 h-4 text-[#002B5C] rounded"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-800">Critical Illness Benefit Rider (64 Ailments)</p>
                    <p className="text-[11px] text-slate-500">Instant lumpsum payout upon diagnosis of cardiac, cancer, neuro conditions</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#002B5C]">+₹2,500/yr</span>
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-slate-300 cursor-pointer bg-slate-50">
                <div className="flex items-center gap-2.5">
                  <input
                    type="checkbox"
                    checked={waiverRider}
                    onChange={e => setWaiverRider(e.target.checked)}
                    className="w-4 h-4 text-[#002B5C] rounded"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-800">Premium Waiver Benefit (PWB)</p>
                    <p className="text-[11px] text-slate-500">All future premiums completely waived in case of critical disability</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#002B5C]">+4% Prem</span>
              </label>
            </div>
          </div>
        </div>

        {/* Right Output & Summary Card (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Institutional Premium Quote Card */}
          <div className="bg-gradient-to-b from-[#002B5C] to-[#001D40] text-white p-6 sm:p-7 rounded-2xl shadow-xl border-2 border-[#F3BA2F]/40 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 bg-[#F3BA2F]/10 rounded-full blur-2xl pointer-events-none"></div>

            {/* Plan Badge */}
            <div className="flex items-center justify-between mb-4">
              <span className="px-2.5 py-1 text-[11px] font-bold rounded bg-[#F3BA2F] text-[#002B5C]">
                {currentPlan.planNo}
              </span>
              <span className="text-xs text-amber-300 font-semibold flex items-center gap-1">
                <Award className="w-3.5 h-3.5" />
                Sovereign Capital Assurance
              </span>
            </div>

            <h3 className="text-xl font-bold font-['Poppins'] text-white">
              {currentPlan.name}
            </h3>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              {currentPlan.tagline}
            </p>

            {/* Premium Figures */}
            <div className="my-6 p-4 rounded-xl bg-white/10 border border-white/15 backdrop-blur-sm">
              <div className="flex items-baseline justify-between">
                <div>
                  <p className="text-xs text-slate-300">Annual Premium (Excl. GST)</p>
                  <p className="text-3xl font-black text-[#F3BA2F] font-['Poppins']">
                    ₹{calculation.annualPremium.toLocaleString('en-IN')}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[11px] text-slate-300">Monthly Equivalent</p>
                  <p className="text-base font-bold text-white">
                    ₹{calculation.monthlyPremium.toLocaleString('en-IN')}/mo
                  </p>
                </div>
              </div>
            </div>

            {/* Calculated Key Metrics */}
            <div className="space-y-2.5 text-xs border-t border-white/10 pt-4">
              <div className="flex justify-between">
                <span className="text-slate-300">Sum Assured (Guaranteed Risk Cover):</span>
                <strong className="text-white">
                  ₹{sumAssured.toLocaleString('en-IN')}
                </strong>
              </div>

              {currentPlan.category !== 'term' && (
                <div className="flex justify-between">
                  <span className="text-slate-300">Est. Maturity Payout (Sum + Bonus):</span>
                  <strong className="text-emerald-400 font-bold text-sm">
                    ₹{calculation.projectedMaturity.toLocaleString('en-IN')}
                  </strong>
                </div>
              )}

              <div className="flex justify-between">
                <span className="text-slate-300">Total Premium Paid ({premiumTerm} yrs):</span>
                <span className="text-slate-200">
                  ₹{calculation.totalInvested.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-300">Annual Tax Savings (Sec 80C):</span>
                <strong className="text-amber-300 font-semibold">
                  Up to ₹{Math.round(calculation.taxSavings).toLocaleString('en-IN')}/year
                </strong>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-300">Maturity Tax Exemption:</span>
                <span className="text-emerald-400 font-semibold">
                  100% Tax-Free (Sec 10(10D))
                </span>
              </div>
            </div>

            {/* Instant Issuance CTA */}
            <div className="mt-6 pt-4 border-t border-white/15 space-y-2.5">
              <button
                onClick={handleInitiateBuy}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-[#F3BA2F] to-amber-500 hover:brightness-105 active:scale-[0.98] text-[#002B5C] font-black text-sm shadow-lg flex items-center justify-center gap-2 transition-all"
              >
                <span>Proceed to Buy &amp; Secure Policy</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={async () => {
                  await downloadElementAsPdf(
                    'policy-quote-summary-card',
                    `SmartInsure_Benefit_Illustration_${currentPlan.planNo}`,
                    setIsGeneratingQuotePdf
                  );
                }}
                disabled={isGeneratingQuotePdf}
                className="w-full py-2.5 px-4 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                title="Download customized official benefit quote illustration as PDF"
              >
                {isGeneratingQuotePdf ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Download className="w-4 h-4 text-[#F3BA2F]" />
                )}
                <span>{isGeneratingQuotePdf ? 'Exporting PDF...' : 'Download Quote Illustration (PDF)'}</span>
              </button>

              <p className="text-[11px] text-center text-slate-400 mt-2">
                Instant Online Payment via UPI, NetBanking or Card • Digital Bond in Vault
              </p>
            </div>
          </div>

          {/* Institutional Compliance Notice */}
          <div className="bg-amber-50 p-4 rounded-xl border border-amber-200 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 leading-relaxed">
              <strong>Statutory Transparency:</strong> Insurance is the subject matter of solicitation. All guaranteed additions and bonuses are audited in accordance with IRDAI actuary guidelines.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Growth Visualizer Section */}
      <div className="mt-12">
        <div className="mb-4">
          <h3 className="text-lg font-bold text-[#002B5C]">
            Interactive Financial Projection &amp; Growth Analysis
          </h3>
          <p className="text-xs text-slate-500">
            Real-time projection model illustrating capital accumulation, life cover safeguard, and bonus acceleration.
          </p>
        </div>

        <WealthChart
          annualPremium={calculation.annualPremium}
          policyTerm={policyTerm}
          premiumTerm={premiumTerm}
          expectedReturnRate={currentPlan.expectedReturnRate}
          sumAssured={sumAssured}
          category={currentPlan.category}
        />
      </div>
    </div>
  );
}
