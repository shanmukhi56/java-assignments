import { useState } from 'react';
import { 
  Shield, 
  X, 
  Printer, 
  Download, 
  CheckCircle2, 
  Award, 
  QrCode, 
  FileText, 
  Calendar, 
  Building,
  CreditCard,
  Loader2
} from 'lucide-react';
import { CustomerProfile, PaymentTransaction } from '../types';
import { downloadElementAsPdf, triggerPrintDialog } from '../utils/pdfDownloader';

interface PaymentReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: PaymentTransaction | null;
  customer?: CustomerProfile | null;
}

export default function PaymentReceiptModal({
  isOpen,
  onClose,
  payment,
  customer
}: PaymentReceiptModalProps) {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  if (!isOpen || !payment) return null;

  const payerName = payment.customerName || customer?.fullName || 'Verified Policyholder';
  const payerEmail = payment.customerEmail || customer?.email || '';
  const payerPan = payment.customerPan || customer?.panNumber || 'N/A';
  const payerAddress = customer?.address || 'Registered Residential Address, India';

  const paymentDateFormatted = new Date(payment.paymentDate).toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });

  const cgst = Math.round(payment.gstAmount / 2);
  const sgst = payment.gstAmount - cgst;

  const handleDownloadPdf = async () => {
    await downloadElementAsPdf(
      'payment-receipt-document',
      `SmartInsure_Receipt_${payment.receiptNumber || 'TXN'}`,
      setIsGeneratingPdf
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 print:p-0 print:bg-white print:static">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border-4 border-[#002B5C] overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in printable-document print:border-2 print:border-slate-800 print:max-h-none print:shadow-none print:rounded-none">
        {/* Top Action Bar (Hidden during print) */}
        <div className="bg-[#002B5C] text-white p-4 px-6 flex items-center justify-between border-b-4 border-[#F3BA2F] no-print">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F3BA2F] text-[#002B5C] flex items-center justify-center font-bold">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base font-['Poppins']">
                Official Premium Payment Receipt
              </h3>
              <p className="text-xs text-amber-200">
                Receipt No: <strong className="font-mono">{payment.receiptNumber}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="px-3.5 py-1.5 rounded-lg bg-[#F3BA2F] hover:bg-amber-400 text-[#002B5C] text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 disabled:opacity-50"
              title="Download PDF directly"
            >
              {isGeneratingPdf ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              <span>{isGeneratingPdf ? 'Exporting...' : 'Download PDF'}</span>
            </button>

            <button
              onClick={triggerPrintDialog}
              className="px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
              title="Print Receipt"
            >
              <Printer className="w-4 h-4 text-[#F3BA2F]" />
              <span className="hidden sm:inline">Print</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Body */}
        <div 
          id="payment-receipt-document"
          className="p-8 overflow-y-auto space-y-6 text-xs text-slate-700 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:16px_16px] printable-content print:p-6 print:overflow-visible print:bg-white"
        >
          {/* Institutional Header */}
          <div className="text-center pb-4 border-b-2 border-slate-300">
            <div className="flex items-center justify-center gap-2">
              <span className="text-xl font-black text-[#002B5C] font-['Poppins'] tracking-tight">
                Smart<span className="text-[#d99f18]">Insure</span>
              </span>
              <span className="text-[10px] uppercase font-bold bg-[#002B5C] text-white px-2 py-0.5 rounded">
                Official Receipt
              </span>
            </div>
            <p className="text-[11px] font-bold text-slate-600 uppercase tracking-widest mt-1">
              SmartInsure National Life Assurance Corporation of India
            </p>
            <p className="text-[10px] text-slate-400">
              IRDAI Regn. No: 512 • CIN: L66010DL2000GOI104821 • GSTIN: 07AAACS1234F1Z5
            </p>
            <p className="text-[10px] text-slate-400">
              Central Divisional HQ: Smart Tower, 24 Barakhamba Road, Connaught Place, New Delhi 110001
            </p>
          </div>

          {/* Key Reference Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Receipt Number</p>
              <p className="font-bold text-[#002B5C] font-mono">{payment.receiptNumber}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Transaction Ref</p>
              <p className="font-bold text-slate-900 font-mono">{payment.transactionReference}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Date &amp; Time</p>
              <p className="font-semibold text-slate-800">{paymentDateFormatted}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Payment Status</p>
              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                payment.status === 'SUCCESS' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                ✓ {payment.status}
              </span>
            </div>
          </div>

          {/* Payer & Policy Information */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 pb-1">
                Payer / Policyholder Details
              </p>
              <p className="font-bold text-slate-900 text-sm">{payerName}</p>
              <p className="text-slate-600">Email: {payerEmail}</p>
              <p className="text-slate-600">Permanent PAN: <strong className="font-mono">{payerPan}</strong></p>
              <p className="text-slate-500 text-[11px] leading-tight">{payerAddress}</p>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 pb-1">
                Policy Schedule Particulars
              </p>
              <p className="font-bold text-[#002B5C] text-sm">{payment.policyName}</p>
              <p className="text-slate-600">Policy Number: <strong className="font-mono text-slate-900">{payment.policyNumber}</strong></p>
              <p className="text-slate-600">Assurance Category: <span className="capitalize">{payment.planCategory}</span></p>
              <p className="text-slate-600">Payment Purpose: <span className="font-semibold">{payment.notes || payment.paymentType}</span></p>
            </div>
          </div>

          {/* Financial Breakdown Table */}
          <div className="border border-slate-300 rounded-xl overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-[#002B5C] text-white text-[11px] uppercase">
                <tr>
                  <th className="p-3">Description of Assessment</th>
                  <th className="p-3 text-center">Tax Clause</th>
                  <th className="p-3 text-right">Amount (INR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                <tr>
                  <td className="p-3">
                    <p className="font-bold text-slate-800">Gross Premium Installment</p>
                    <p className="text-[10px] text-slate-400">Basic Actuarial Life / Health Cover Charge</p>
                  </td>
                  <td className="p-3 text-center font-bold text-emerald-700">
                    {payment.taxDeductionSection}
                  </td>
                  <td className="p-3 text-right font-semibold font-mono">
                    ₹{payment.baseAmount.toLocaleString('en-IN')}.00
                  </td>
                </tr>

                <tr>
                  <td className="p-3 text-slate-600">Central GST (CGST @ 9%)</td>
                  <td className="p-3 text-center text-slate-400">CGST Act</td>
                  <td className="p-3 text-right font-mono text-slate-700">
                    ₹{cgst.toLocaleString('en-IN')}.00
                  </td>
                </tr>

                <tr>
                  <td className="p-3 text-slate-600">State / UT GST (SGST @ 9%)</td>
                  <td className="p-3 text-center text-slate-400">SGST Act</td>
                  <td className="p-3 text-right font-mono text-slate-700">
                    ₹{sgst.toLocaleString('en-IN')}.00
                  </td>
                </tr>

                <tr className="bg-blue-50/70 font-bold">
                  <td className="p-3 text-[#002B5C] text-sm font-['Poppins']">
                    Total Amount Received &amp; Credited
                  </td>
                  <td className="p-3 text-center text-emerald-800 font-bold text-xs">
                    Sec 10(10D) Tax-Free
                  </td>
                  <td className="p-3 text-right text-[#002B5C] text-base font-black font-['Poppins']">
                    ₹{payment.totalAmount.toLocaleString('en-IN')}.00
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Payment Method & UTR */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
            <div>
              <span className="text-slate-500">Settlement Mode: </span>
              <strong className="text-slate-800">{payment.paymentMethod}</strong>
            </div>
            {payment.bankRefNumber && (
              <div>
                <span className="text-slate-500">Bank Gateway Reference (UTR): </span>
                <strong className="font-mono text-slate-800">{payment.bankRefNumber}</strong>
              </div>
            )}
          </div>

          {/* Statutory Tax Exemption Declaration */}
          <div className="p-3.5 bg-emerald-50/80 rounded-xl border border-emerald-200 text-[11px] text-emerald-900 leading-relaxed">
            <strong>Statutory Tax Exemption Note:</strong> Certified that the amount of ₹{payment.totalAmount.toLocaleString('en-IN')} has been paid towards life assurance / health premium and is eligible for tax deduction under <strong>{payment.taxDeductionSection}</strong> of the Income Tax Act, 1961.
          </div>

          {/* Digital Seal & Actuary Signature */}
          <div className="flex items-center justify-between pt-4 border-t-2 border-slate-200">
            <div className="flex items-center gap-2.5">
              <Award className="w-9 h-9 text-[#002B5C]" />
              <div>
                <p className="text-[10px] font-bold uppercase text-slate-400">Authenticated By</p>
                <p className="text-xs font-bold text-slate-800">SmartInsure Central Depository</p>
                <p className="text-[10px] text-slate-400">Digitally Verified &amp; Timestamped</p>
              </div>
            </div>

            <div className="text-right">
              <p className="font-serif italic font-bold text-slate-900 text-base">V. K. Shrivastava</p>
              <p className="text-[10px] text-slate-500 font-bold uppercase">Chief Accounts Officer &amp; Actuary</p>
              <p className="text-[10px] text-slate-400">SmartInsure Corporation of India</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
