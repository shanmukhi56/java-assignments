import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

/**
 * Downloads a DOM element as a high-quality PDF document file.
 * Handles styling, scaling, fonts, and multi-page or single-page A4 fitting.
 */
export async function downloadElementAsPdf(
  elementIdOrElement: string | HTMLElement,
  filename: string = 'document.pdf',
  onProgress?: (isGenerating: boolean) => void
): Promise<boolean> {
  try {
    if (onProgress) onProgress(true);

    const element =
      typeof elementIdOrElement === 'string'
        ? document.getElementById(elementIdOrElement)
        : elementIdOrElement;

    if (!element) {
      console.error(`Element not found for PDF export`);
      if (onProgress) onProgress(false);
      return false;
    }

    // Scroll to top of element if needed
    const prevScrollTop = element.scrollTop;
    element.scrollTop = 0;

    // Use html2canvas with high DPI scale
    const canvas = await html2canvas(element, {
      scale: 2, // 2x resolution for crisp text & borders
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: element.scrollWidth,
      windowHeight: element.scrollHeight,
    });

    element.scrollTop = prevScrollTop;

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pdfWidth = pdf.internal.pageSize.getWidth(); // ~210mm
    const pdfHeight = pdf.internal.pageSize.getHeight(); // ~297mm

    const imgWidth = pdfWidth - 20; // 10mm margins on left and right
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 10; // 10mm top margin

    // First page
    pdf.addImage(imgData, 'PNG', 10, position, imgWidth, Math.min(imgHeight, pdfHeight - 20));
    heightLeft -= (pdfHeight - 20);

    // Additional pages if document is longer than one A4 sheet
    while (heightLeft > 0) {
      position = heightLeft - imgHeight + 10;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
      heightLeft -= (pdfHeight - 20);
    }

    // Direct browser file download
    const cleanFilename = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
    pdf.save(cleanFilename);

    if (onProgress) onProgress(false);
    return true;
  } catch (error) {
    console.error('Error generating PDF download:', error);
    if (onProgress) onProgress(false);

    // Fallback: try window.print() or alert fallback
    try {
      window.print();
    } catch {
      // ignore
    }
    return false;
  }
}

/**
 * Universal print handler that handles iframe restrictions
 */
export function triggerPrintDialog(): void {
  try {
    window.print();
  } catch (e) {
    console.warn('Standard window.print() was blocked or failed:', e);
  }
}
