export interface Policy {
  id: string;
  name: string;
  planNo: string;
  category: 'term' | 'endowment' | 'child' | 'pension' | 'health' | 'ulip';
  tagline: string;
  minAge: number;
  maxAge: number;
  minSumAssured: number;
  maxSumAssured: number;
  minTerm: number;
  maxTerm: number;
  baseRatePerThousand: number; // For premium calculation
  expectedReturnRate: number; // Annual %
  taxBenefitSection: string;
  features: string[];
  keyBenefits: {
    title: string;
    description: string;
  }[];
  popular?: boolean;
  governmentBacked?: boolean;
}

export interface CustomerProfile {
  id: string;
  userId?: string;
  fullName: string;
  email: string;
  phone: string;
  address: string;
  panNumber: string;
  aadhaarLast4?: string;
  dob?: string;
  gender?: 'male' | 'female' | 'other';
  role: 'customer' | 'admin';
  createdAt: string;
}

export interface UserPolicy {
  id: string;
  customerId: string;
  customerName: string;
  customerEmail?: string;
  policyNumber: string;
  policyId: string;
  policyName: string;
  category: string;
  sumAssured: number;
  premiumAmount: number;
  gstAmount: number;
  totalPremiumPayable: number;
  premiumFrequency: 'Monthly' | 'Quarterly' | 'Half-Yearly' | 'Yearly';
  startDate: string;
  maturityDate: string;
  nextDueDate: string;
  status: 'Active' | 'Grace Period' | 'Matured' | 'Lapsed';
  nomineeName: string;
  nomineeRelation: string;
  paidInstallments: number;
  totalInstallments: number;
  accumulatedBonus: number;
  surrenderValue: number;
  paymentMethodLastUsed?: string;
  taxBenefitSection?: string;
}

export type PaymentStatus = 'SUCCESS' | 'PENDING' | 'FAILED' | 'REFUNDED';
export type PaymentType = 'NEW_POLICY' | 'RENEWAL_PREMIUM' | 'RIDER_ADDON';
export type PaymentMethod = 'UPI' | 'Credit / Debit Card' | 'Net Banking' | 'NEFT / RTGS';

export interface PaymentTransaction {
  id: string;
  transactionReference: string; // e.g. TXN-2026-889412
  receiptNumber: string; // e.g. REC-2026-449102
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPan?: string;
  policyId: string;
  policyNumber: string;
  policyName: string;
  planCategory: string;
  paymentType: PaymentType;
  baseAmount: number;
  gstAmount: number;
  totalAmount: number;
  paymentDate: string; // ISO string
  paymentMethod: PaymentMethod;
  status: PaymentStatus;
  bankRefNumber?: string;
  taxDeductionSection: string; // 'Section 80C' | 'Section 80D' | 'Section 80CCC'
  notes?: string;
  gatewayResponse?: string;
}

export interface Claim {
  id: string;
  customerId: string;
  claimNumber: string;
  policyNumber: string;
  policyHolderName: string;
  claimType: 'Death Benefit' | 'Maturity Claim' | 'Critical Illness' | 'Hospitalization Reimbursement' | 'Accidental Disability';
  claimAmount: number;
  dateOfIncident: string;
  dateSubmitted: string;
  status: 'Submitted' | 'Document Verification' | 'Surveyor Inspection' | 'TPA Medical Audit' | 'Approved' | 'Settled' | 'Rejected';
  stageNumber: number; // 1 to 5
  estimatedSettlementDate: string;
  hospitalOrPlace?: string;
  assignedSurveyor?: {
    name: string;
    phone: string;
    badgeId: string;
  };
  timeline: {
    title: string;
    date: string;
    description: string;
    completed: boolean;
    current?: boolean;
  }[];
  documents: {
    name: string;
    type: string;
    status: 'Verified' | 'Pending Review' | 'Required';
  }[];
  notes?: string;
  settlementUtr?: string;
}

export interface CalculationInput {
  age: number;
  gender: 'male' | 'female' | 'other';
  annualIncome: number;
  tobaccoUser: boolean;
  goal: 'protection' | 'guaranteed' | 'child' | 'retirement' | 'health' | 'wealth';
  sumAssured: number;
  policyTerm: number;
  premiumTerm: number;
  riders: {
    accidentalDeath: boolean;
    criticalIllness: boolean;
    premiumWaiver: boolean;
  };
}

export interface CalculationResult {
  annualPremium: number;
  monthlyPremium: number;
  totalPremiumPaid: number;
  estimatedMaturityValue: number;
  accidentalBenefitCoverage: number;
  criticalIllnessCoverage: number;
  taxSavings80C: number;
  taxFreeMaturity10_10D: boolean;
  recommendedPolicies: Policy[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  suggestions?: string[];
}
