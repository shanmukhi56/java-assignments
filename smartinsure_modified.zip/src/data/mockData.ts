import { Policy, UserPolicy, Claim } from '../types';

export const ALL_POLICIES: Policy[] = [
  {
    id: 'smart-rakshak-pure-term',
    planNo: 'Plan 855',
    name: 'Smart Rakshak Pure Term Shield',
    tagline: 'High sum assured pure risk coverage ensuring comprehensive financial sovereignty for your family.',
    category: 'term',
    minAge: 18,
    maxAge: 65,
    minSumAssured: 5000000,
    maxSumAssured: 50000000,
    minTerm: 10,
    maxTerm: 40,
    baseRatePerThousand: 1.12,
    expectedReturnRate: 0,
    taxBenefitSection: 'Section 80C & 10(10D)',
    popular: true,
    governmentBacked: true,
    features: [
      'Comprehensive Pure Risk Death Benefit payout to nominee',
      'Special 10% lower premium tariff for non-smokers and female lives',
      'Optional Accidental Death & Total Permanent Disability Riders',
      'Terminal Illness Accelerated Benefit with instant 50% payout',
      'Level or Increasing Life Cover options over policy tenure'
    ],
    keyBenefits: [
      {
        title: 'Guaranteed Death Benefit',
        description: 'Highest of 10 times annual premium or 105% of total premiums paid or absolute sum assured paid instantly.'
      },
      {
        title: 'Tax Exemption Under Section 80C',
        description: 'Premiums paid qualify for full tax deduction up to ₹1.5 Lakhs annually under Indian IT Act.'
      }
    ]
  },
  {
    id: 'smart-jeevan-labh',
    planNo: 'Plan 936',
    name: 'Smart Jeevan Labh Endowment Plan',
    tagline: 'Non-linked, with-profits limited premium paying endowment plan providing security and handsome returns.',
    category: 'endowment',
    minAge: 18,
    maxAge: 59,
    minSumAssured: 200000,
    maxSumAssured: 25000000,
    minTerm: 16,
    maxTerm: 25,
    baseRatePerThousand: 44.5,
    expectedReturnRate: 8.2,
    taxBenefitSection: 'Section 80C & 10(10D)',
    popular: true,
    governmentBacked: true,
    features: [
      'Limited Premium Payment: Pay for 10/15/16 yrs for 16/21/25 yrs term',
      'Simple Reversionary Bonus + Final Additional Bonus at maturity',
      'Loan facility available after completion of 2 full policy years',
      'High Sum Assured Rebate up to ₹3 per thousand sum assured',
      'Sovereign state guarantee on sum assured and vested bonuses'
    ],
    keyBenefits: [
      {
        title: 'Lumpsum Maturity Payout',
        description: 'Basic Sum Assured + Vested Simple Reversionary Bonuses + Final Additional Bonus on survival.'
      },
      {
        title: 'Risk Cover on Death',
        description: 'Sum Assured on Death (higher of 105% premiums or 7x annualised premium) + Accrued bonuses.'
      }
    ]
  },
  {
    id: 'smart-vidya-child-future',
    planNo: 'Plan 932',
    name: 'Smart Vidya Child Future Builder',
    tagline: 'Securing your child\'s higher education, medical/engineering milestones, and marriage aspirations.',
    category: 'child',
    minAge: 20,
    maxAge: 50,
    minSumAssured: 500000,
    maxSumAssured: 15000000,
    minTerm: 13,
    maxTerm: 25,
    baseRatePerThousand: 38.2,
    expectedReturnRate: 7.9,
    taxBenefitSection: 'Section 80C & 10(10D)',
    popular: false,
    governmentBacked: true,
    features: [
      'Built-in Premium Waiver Benefit (PWB) in case of unfortunate demise of parent',
      'Staggered Survival Benefits: 20% at age 18, 20% at age 20, and 60% with bonus at age 22',
      'Education fund milestone payouts timed exactly with university admissions',
      'Financial protection stays uninterrupted even after parent eventuality'
    ],
    keyBenefits: [
      {
        title: 'Premium Waiver Assurance',
        description: 'All future premiums waived automatically upon unfortunate death of parent while child benefits continue.'
      },
      {
        title: 'Milestone Disbursals',
        description: 'Guaranteed milestone income for college fees followed by massive maturity bonus.'
      }
    ]
  },
  {
    id: 'smart-shanti-guaranteed-pension',
    planNo: 'Plan 858',
    name: 'Smart Shanti Guaranteed Pension Plan',
    tagline: 'Single premium and regular annuity plan offering lifetime guaranteed pension from Day 1.',
    category: 'pension',
    minAge: 30,
    maxAge: 79,
    minSumAssured: 1000000,
    maxSumAssured: 50000000,
    minTerm: 5,
    maxTerm: 30,
    baseRatePerThousand: 52.0,
    expectedReturnRate: 7.4,
    taxBenefitSection: 'Section 80CCC & 10(10A)',
    popular: false,
    governmentBacked: true,
    features: [
      'Guaranteed lifetime annuity rates locked in at the time of policy purchase',
      'Immediate Annuity & Deferred Annuity options ranging from 1 to 12 years',
      'Joint Life option ensuring continued pension to spouse after primary annuitant',
      '100% Return of Purchase Price (ROP) to legal heirs upon demise of annuitant'
    ],
    keyBenefits: [
      {
        title: 'Lifelong Guaranteed Income',
        description: 'Fixed monthly/quarterly/annual pension credited directly to bank account for life.'
      },
      {
        title: 'Return of Principal to Nominee',
        description: 'Entire purchase amount returned safely to family nominee on completion of life.'
      }
    ]
  },
  {
    id: 'smart-swasthya-critical-shield',
    planNo: 'Plan 905',
    name: 'Smart Swasthya Critical & Hospital Shield',
    tagline: 'Comprehensive indemnity & fixed benefit health cover with cashless hospital network.',
    category: 'health',
    minAge: 18,
    maxAge: 65,
    minSumAssured: 500000,
    maxSumAssured: 5000000,
    minTerm: 5,
    maxTerm: 25,
    baseRatePerThousand: 12.8,
    expectedReturnRate: 0,
    taxBenefitSection: 'Section 80D (Up to ₹75,000)',
    popular: true,
    governmentBacked: false,
    features: [
      'Cashless treatment across 14,500+ premier accredited hospital networks',
      'Covers 64 Major Critical Illnesses including cancer, stroke, bypass, kidney failure',
      'No sub-limits on room rent, ICU charges, and modern robotic surgeries',
      'Restoration benefit: 100% recharge of sum insured if exhausted during same year'
    ],
    keyBenefits: [
      {
        title: 'Tax Deduction Under 80D',
        description: 'Health insurance premiums qualify for high-tier deductions up to ₹75,000 for self & parents.'
      },
      {
        title: 'Direct TPA Cashless Settled in 30 Mins',
        description: 'Pre-authorized cashless hospital desk approvals without paying out-of-pocket.'
      }
    ]
  },
  {
    id: 'smart-sampatti-wealth-ulip',
    planNo: 'Plan 849',
    name: 'Smart Sampatti Market Wealth ULIP',
    tagline: 'Unit-linked endowment life assurance offering market growth potential with sovereign fund switches.',
    category: 'ulip',
    minAge: 18,
    maxAge: 55,
    minSumAssured: 1000000,
    maxSumAssured: 20000000,
    minTerm: 10,
    maxTerm: 25,
    baseRatePerThousand: 22.0,
    expectedReturnRate: 12.5,
    taxBenefitSection: 'Section 80C & 10(10D)',
    popular: false,
    governmentBacked: false,
    features: [
      'Zero Premium Allocation Charges from Year 6 onwards',
      'Choice of 7 diverse investment funds (Equity, Balanced, Bond, Infrastructure)',
      '4 Free Fund switches every policy year to navigate market fluctuations',
      'Mortality charge refund at maturity directly credited back to unit fund value'
    ],
    keyBenefits: [
      {
        title: 'Market Capital Multiplier',
        description: 'High-growth equity compounding paired with 10x life insurance protection cover.'
      },
      {
        title: 'Guaranteed Loyalty Additions',
        description: 'Additional units credited at specified policy durations to boost overall corpus.'
      }
    ]
  }
];

export const INITIAL_USER_POLICIES: UserPolicy[] = [];

export const INITIAL_CLAIMS: Claim[] = [];

export const FAQS = [
  {
    q: 'What is the claim settlement timeline and process?',
    a: 'Claims are processed through our digitized fast-track settlement desk. Digital intimation takes under 2 minutes, survey/medical verification takes 24-48 hours, and upon TPA clearance, funds are credited directly to your registered bank account via NEFT within 3-5 business days.'
  },
  {
    q: 'How do tax exemptions under Section 80C, 80D, and 10(10D) work?',
    a: 'Life insurance premiums qualify for deduction under Section 80C up to ₹1,50,000 annually. Health and Critical illness riders qualify under Section 80D up to ₹75,000 (for self, family, and senior parents). Maturity payouts and death benefits are 100% tax-exempt under Section 10(10D).'
  },
  {
    q: 'Can I pay renewal premiums online using UPI or NetBanking?',
    a: 'Yes, SmartInsure supports instant zero-fee renewal payments via UPI (GPay, PhonePe, Paytm, BHIM), NetBanking across 50+ banks, Debit/Credit Cards, and NACH e-Mandate auto-debit.'
  },
  {
    q: 'Can I take a loan against my Endowment or Money-Back policy?',
    a: 'Yes, policies that have acquired surrender value (typically after 2 to 3 full policy years) are eligible for policy loans up to 90% of the surrender value at competitive sovereign interest rates.'
  },
  {
    q: 'How can I download the official Tax Exemption Certificate and Premium Receipts?',
    a: 'Navigate to Customer Dashboard -> Quick Actions -> "Download Tax (80C) Certificate" or click "View Receipt" next to any completed transaction to print or export formal digitized PDF receipts.'
  }
];

export const BRANCH_OFFICES = [
  {
    city: 'Bengaluru (Zonal HQ)',
    address: 'SmartInsure Towers, 14th Floor, MG Road, Ashok Nagar, Bengaluru 560001',
    phone: '+91 80 2558 9900',
    timing: 'Mon - Sat: 9:30 AM - 5:30 PM',
    type: 'Zonal Operational Headquarter'
  },
  {
    city: 'Mumbai (Treasury & Underwriting)',
    address: 'Sovereign Insurance Chambers, Nariman Point, Marine Drive, Mumbai 400021',
    phone: '+91 22 6620 4400',
    timing: 'Mon - Sat: 9:30 AM - 5:30 PM',
    type: 'Central Underwriting & Actuarial Center'
  },
  {
    city: 'New Delhi (Claims Settlement Hub)',
    address: 'Jeevan Prakash Building, 25 Kasturba Gandhi Marg, Connaught Place, New Delhi 110001',
    phone: '+91 11 2331 8800',
    timing: 'Mon - Sat: 9:30 AM - 5:30 PM',
    type: 'National Fast-Track Claims Division'
  },
  {
    city: 'Chennai (Southern Division)',
    address: 'LIC Divisional Complex, Mount Road, Anna Salai, Chennai 600002',
    phone: '+91 44 2852 1100',
    timing: 'Mon - Sat: 9:30 AM - 5:30 PM',
    type: 'Regional Operations Center'
  }
];
