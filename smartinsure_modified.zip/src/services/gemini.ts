import { GoogleGenAI } from '@google/genai';

let aiInstance: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI | null {
  if (aiInstance) return aiInstance;
  const env = (import.meta as any).env || {};
  const apiKey = env.VITE_GEMINI_API_KEY || (typeof process !== 'undefined' ? process.env.GEMINI_API_KEY : '');
  if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
    try {
      aiInstance = new GoogleGenAI({ apiKey });
    } catch (e) {
      console.warn('Error initializing GoogleGenAI client:', e);
    }
  }
  return aiInstance;
}

export async function askInsuranceAdvisor(userPrompt: string, context?: string): Promise<string> {
  const ai = getAIClient();

  if (ai) {
    try {
      const systemInstruction = `You are "SmartInsure Advisor", an expert institutional insurance actuary and policy assistant for the SmartInsure Portal (inspired by trusted institutions like LIC & IRDAI).
Provide helpful, authoritative, concise, and structured guidance on:
- Term Insurance vs Endowment vs ULIP vs Health Shield policies
- Human Life Value (HLV) calculation rules
- Tax savings under Section 80C, 80D, 10(10D), and 80CCC
- Claim filing process, required documents, TPA medical audit stages, surveyor inspection
- Grace periods, policy revival, nomination, and loan against insurance policies.
Keep responses crisp, clear, reassuring, and bullet-pointed when appropriate.`;

      const fullPrompt = context 
        ? `${systemInstruction}\n\nCurrent User Context:\n${context}\n\nUser Question:\n${userPrompt}`
        : `${systemInstruction}\n\nUser Question:\n${userPrompt}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: fullPrompt,
      });

      if (response && response.text) {
        return response.text;
      }
    } catch (err) {
      console.warn('Gemini live call fallback triggered:', err);
    }
  }

  // Authoritative intelligent fallback responses based on keywords
  const lower = userPrompt.toLowerCase();

  if (lower.includes('tax') || lower.includes('80c') || lower.includes('10(10d)') || lower.includes('80d')) {
    return `### 🏛️ Insurance Tax Benefits Overview (FY 2025-26):
1. **Section 80C**: Life insurance premiums up to **₹1,50,000/year** are eligible for tax deduction from gross total income.
2. **Section 10(10D)**: All Death benefits and Maturity proceeds are **100% Tax-Free**, provided the annual premium is less than 10% of the Sum Assured (or within the statutory ₹5 Lakh annual threshold for traditional policies).
3. **Section 80D**: Health Insurance and Critical Illness riders provide additional tax deductions up to **₹25,000** for self/family, and up to **₹50,000** for senior citizen parents.
4. **Section 80CCC**: Pension annuities and retirement plan contributions qualify for deductions up to ₹1.5 Lakhs.`;
  }

  if (lower.includes('claim') || lower.includes('track') || lower.includes('death') || lower.includes('hospital') || lower.includes('settle')) {
    return `### 📋 Smart Fast-Track Claim Guidelines:
1. **Cashless Hospitalization**: Intimate within 24 hours of emergency admission or 48 hours prior to planned surgery. Show your SmartInsure Digital Health Card at any network hospital desk.
2. **Reimbursement Claims**: Submit within 15 days of discharge with original discharge summary, itemized pharmacy bills, diagnostic reports, and a cancelled cheque.
3. **Death Claim Settlement**: Nominee needs to submit Claim Form 3783, Death Certificate issued by Municipal Authority, original policy bond, and KYC identification.
4. **Settlement SLA**: Under SmartInsure express processing, verified claims are settled directly via NEFT into your bank account within **3 to 7 working days**.`;
  }

  if (lower.includes('term') || lower.includes('how much') || lower.includes('cover') || lower.includes('sum assured')) {
    return `### 🛡️ Recommended Life Coverage (HLV Rule):
- **Ideal Sum Assured**: Rule of thumb is **15x to 20x your Annual Income**. For example, with an annual income of ₹10 Lakhs, a minimum Term Cover of **₹1.5 to ₹2.0 Crores** is strongly recommended.
- **Riders to add**: Accidental Death Benefit Rider (2x payout in case of road mishaps) + Critical Illness Rider (instant lump-sum on 64 major diseases).
- **Duration**: Choose a policy term that protects your family until your planned retirement age (typically age 60-65).`;
  }

  if (lower.includes('loan') || lower.includes('surrender') || lower.includes('grace')) {
    return `### 💼 Policy Liquidity & Grace Rules:
- **Grace Period**: 30 days for Yearly/Half-Yearly/Quarterly payment modes, and 15 days for Monthly ECS modes. During grace, your full insurance protection remains active.
- **Loan against Policy**: Available on Endowment plans (like Smart Jeevan Labh) after 2 completed years. You can borrow up to **90% of Surrender Value** at subsidized interest rates.
- **Revival of Lapsed Policy**: Can be revived within 5 years of first unpaid premium by paying arrears with nominal interest and good health declaration.`;
  }

  return `### 💡 SmartInsure Policy Guidance:
Thank you for reaching out to the SmartInsure Helpdesk.
- **Explore Plans**: Use our **Smart Policy Calculator** above to calculate instant quotes tailored to your age and income.
- **Active Policies**: Head to the **Customer Dashboard** to view your active bond details, next premium due dates, and download digital certificates.
- **Claims**: Track your active claims using your Claim Reference ID (e.g. \`CLM-2026-8891\`) or click **File New Claim** for instant pre-authorization.
- **Helpline**: You can also reach our 24x7 toll-free helpline at **1800-762-784 (1800-SMART-INS)**.`;
}
