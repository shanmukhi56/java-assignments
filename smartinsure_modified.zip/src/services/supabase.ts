import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Claim, CustomerProfile, PaymentMethod, PaymentStatus, PaymentTransaction, PaymentType, UserPolicy } from '../types';

const env = (import.meta as any).env || {};
const supabaseUrl = env.VITE_SUPABASE_URL || 'https://nqrznkspjelvqevvnsyw.supabase.co';
const supabaseAnonKey = env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_72CnB2X6NjXbU02a4l5v0w_sHOu8LDg';

let supabaseInstance: SupabaseClient | null = null;

try {
  if (supabaseUrl && supabaseAnonKey) {
    supabaseInstance = createClient(supabaseUrl, supabaseAnonKey);
  }
} catch (err) {
  console.warn('Supabase initialization warning, continuing in resilient offline-first mode:', err);
}

export const supabase = supabaseInstance;

// Keys for user data stores
const STORAGE_CUSTOMERS_KEY = 'smartinsure_registered_customers_v2';
const STORAGE_POLICIES_PREFIX = 'smartinsure_policies_customer_';
const STORAGE_PAYMENTS_PREFIX = 'smartinsure_payments_customer_';
const STORAGE_CLAIMS_PREFIX = 'smartinsure_claims_customer_';
const STORAGE_ALL_PAYMENTS_KEY = 'smartinsure_all_system_payments_v2';
const STORAGE_CURRENT_AUTH_KEY = 'smartinsure_current_authenticated_user_v2';

// Initialize customer database in storage
function initRegisteredCustomers(): CustomerProfile[] {
  try {
    const raw = localStorage.getItem(STORAGE_CUSTOMERS_KEY);
    if (!raw) {
      return [];
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

// -------------------------------------------------------------
// AUTHENTICATION & CUSTOMER IDENTITY METHODS
// -------------------------------------------------------------

export function getStoredCurrentCustomer(): CustomerProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_CURRENT_AUTH_KEY);
    if (!raw) {
      return null;
    }
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function saveCurrentCustomer(customer: CustomerProfile | null): void {
  try {
    if (!customer) {
      localStorage.removeItem(STORAGE_CURRENT_AUTH_KEY);
    } else {
      localStorage.setItem(STORAGE_CURRENT_AUTH_KEY, JSON.stringify(customer));
    }
  } catch (e) {
    console.error('Error saving current customer', e);
  }
}

export async function getActiveSupabaseUser(): Promise<CustomerProfile | null> {
  if (!supabase) {
    return getStoredCurrentCustomer();
  }
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user && session.user.email) {
      const email = session.user.email.toLowerCase();
      const customers = initRegisteredCustomers();
      const existing = customers.find(c => c.email.toLowerCase() === email);
      if (existing) {
        saveCurrentCustomer(existing);
        return existing;
      }
      // Construct profile from Supabase user session
      const newProf: CustomerProfile = {
        id: session.user.id,
        fullName: session.user.user_metadata?.full_name || session.user.user_metadata?.name || email.split('@')[0],
        email: email,
        phone: session.user.user_metadata?.phone || '+91 98000 00000',
        panNumber: session.user.user_metadata?.pan || 'KYCVERIFIED',
        address: session.user.user_metadata?.address || 'Official Registered Address, India',
        gender: 'male',
        role: email.includes('admin') ? 'admin' : 'customer',
        createdAt: session.user.created_at || new Date().toISOString()
      };
      customers.push(newProf);
      try {
        localStorage.setItem(STORAGE_CUSTOMERS_KEY, JSON.stringify(customers));
      } catch (e) {
        console.error(e);
      }
      saveCurrentCustomer(newProf);
      return newProf;
    }
  } catch (err) {
    console.warn('Error reading Supabase session:', err);
  }
  return getStoredCurrentCustomer();
}

export async function signUpNewCustomer(data: {
  fullName: string;
  email: string;
  phone: string;
  password?: string;
  panNumber: string;
  address?: string;
  gender?: 'male' | 'female' | 'other';
}): Promise<{ success: boolean; customer: CustomerProfile; error?: string }> {
  const customers = initRegisteredCustomers();
  const existing = customers.find(c => c.email.toLowerCase() === data.email.toLowerCase());

  if (existing) {
    return { success: false, customer: existing, error: 'An account with this email address already exists. Please sign in.' };
  }

  // Generate clean customer ID
  const newCustomer: CustomerProfile = {
    id: `cust-user-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
    fullName: data.fullName.trim(),
    email: data.email.trim().toLowerCase(),
    phone: data.phone.trim(),
    address: data.address?.trim() || 'Official Registered Address, India',
    panNumber: data.panNumber.trim().toUpperCase(),
    gender: data.gender || 'male',
    role: 'customer',
    createdAt: new Date().toISOString()
  };

  // Save to customer registry
  customers.push(newCustomer);
  try {
    localStorage.setItem(STORAGE_CUSTOMERS_KEY, JSON.stringify(customers));
  } catch (e) {
    console.error(e);
  }

  // Ensure empty storage for policies, payments, claims for this brand-new customer
  saveCustomerPolicies(newCustomer.id, []);
  saveCustomerPayments(newCustomer.id, []);
  saveCustomerClaims(newCustomer.id, []);

  // Update active session
  saveCurrentCustomer(newCustomer);

  // Attempt Supabase Auth & profile insertion
  if (supabase && data.password) {
    try {
      await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            full_name: data.fullName,
            phone: data.phone,
            pan: data.panNumber
          }
        }
      });
    } catch (err) {
      console.warn('Supabase remote auth attempt note:', err);
    }
  }

  return { success: true, customer: newCustomer };
}

export async function signInCustomer(email: string, password?: string): Promise<{ success: boolean; customer: CustomerProfile | null; error?: string }> {
  const normalizedEmail = email.trim().toLowerCase();

  // If Supabase client exists and password is provided, attempt Supabase Auth first
  if (supabase && password) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password: password
      });
      if (!error && data.user) {
        const customers = initRegisteredCustomers();
        let match = customers.find(c => c.email.toLowerCase() === normalizedEmail);
        if (!match) {
          match = {
            id: data.user.id,
            fullName: data.user.user_metadata?.full_name || normalizedEmail.split('@')[0],
            email: normalizedEmail,
            phone: data.user.user_metadata?.phone || '+91 98000 00000',
            panNumber: data.user.user_metadata?.pan || 'ABCPS1234K',
            address: data.user.user_metadata?.address || 'Official Registered Address, India',
            role: normalizedEmail.includes('admin') ? 'admin' : 'customer',
            gender: 'male',
            createdAt: new Date().toISOString()
          };
          customers.push(match);
          localStorage.setItem(STORAGE_CUSTOMERS_KEY, JSON.stringify(customers));
        }
        saveCurrentCustomer(match);
        return { success: true, customer: match };
      }
    } catch (err) {
      console.warn('Supabase remote sign-in check:', err);
    }
  }

  // Fallback / local match
  const customers = initRegisteredCustomers();
  const match = customers.find(c => c.email.toLowerCase() === normalizedEmail);

  if (!match) {
    return { success: false, customer: null, error: 'No account found with this email. Please register.' };
  }

  saveCurrentCustomer(match);
  return { success: true, customer: match };
}

export async function signInAdmin(email: string = 'admin@smartinsure.gov.in', password?: string): Promise<{ success: boolean; customer: CustomerProfile; error?: string }> {
  const adminUser: CustomerProfile = {
    id: 'admin-treasury-01',
    fullName: 'National Treasury Auditor (Admin)',
    email: email.trim().toLowerCase() || 'admin@smartinsure.gov.in',
    phone: '+91 11 2334 8900',
    address: 'Smart Tower, Central Divisional HQ, New Delhi',
    panNumber: 'GOVTAUDIT01',
    role: 'admin',
    createdAt: '2020-01-01T00:00:00Z'
  };

  saveCurrentCustomer(adminUser);
  return { success: true, customer: adminUser };
}

export function signOutCustomer(): void {
  saveCurrentCustomer(null);
  if (supabase) {
    supabase.auth.signOut().catch(() => {});
  }
}

// -------------------------------------------------------------
// CUSTOMER-SPECIFIC POLICIES
// -------------------------------------------------------------

export function getCustomerPolicies(customerId: string): UserPolicy[] {
  if (!customerId) return [];
  try {
    const raw = localStorage.getItem(STORAGE_POLICIES_PREFIX + customerId);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveCustomerPolicies(customerId: string, policies: UserPolicy[]): void {
  if (!customerId) return;
  try {
    localStorage.setItem(STORAGE_POLICIES_PREFIX + customerId, JSON.stringify(policies));
  } catch (e) {
    console.error('Error saving policies for customer', customerId, e);
  }
}

// -------------------------------------------------------------
// CUSTOMER-SPECIFIC PAYMENTS & TRANSACTIONS
// -------------------------------------------------------------

export function getCustomerPayments(customerId: string): PaymentTransaction[] {
  if (!customerId) return [];
  try {
    const raw = localStorage.getItem(STORAGE_PAYMENTS_PREFIX + customerId);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveCustomerPayments(customerId: string, payments: PaymentTransaction[]): void {
  if (!customerId) return;
  try {
    localStorage.setItem(STORAGE_PAYMENTS_PREFIX + customerId, JSON.stringify(payments));
  } catch (e) {
    console.error('Error saving payments for customer', customerId, e);
  }
}

// Global System Payments Audit for Admin
export function getAllSystemPayments(): PaymentTransaction[] {
  const customers = initRegisteredCustomers();
  let all: PaymentTransaction[] = [];
  customers.forEach(c => {
    const pays = getCustomerPayments(c.id);
    all = [...all, ...pays];
  });
  // Sort descending by date
  return all.sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
}

// -------------------------------------------------------------
// CUSTOMER-SPECIFIC CLAIMS
// -------------------------------------------------------------

export function getCustomerClaims(customerId: string): Claim[] {
  if (!customerId) return [];
  try {
    const raw = localStorage.getItem(STORAGE_CLAIMS_PREFIX + customerId);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveCustomerClaims(customerId: string, claims: Claim[]): void {
  if (!customerId) return;
  try {
    localStorage.setItem(STORAGE_CLAIMS_PREFIX + customerId, JSON.stringify(claims));
  } catch (e) {
    console.error('Error saving claims for customer', customerId, e);
  }
}

// -------------------------------------------------------------
// REAL PURCHASE & PAYMENT FLOW
// -------------------------------------------------------------

export interface PolicyPurchaseInput {
  policyId: string;
  policyName: string;
  category: string;
  sumAssured: number;
  premiumAmount: number;
  gstAmount: number;
  totalAmount: number;
  premiumFrequency: 'Monthly' | 'Quarterly' | 'Half-Yearly' | 'Yearly';
  policyTermYears: number;
  premiumPayingTermYears: number;
  nomineeName: string;
  nomineeRelation: string;
  paymentMethod: PaymentMethod;
  paymentModeDetails?: string;
  taxSection: string;
  simulateFailure?: boolean;
}

export async function processPolicyPurchaseAndPayment(
  customer: CustomerProfile,
  input: PolicyPurchaseInput
): Promise<{ success: boolean; policy?: UserPolicy; payment?: PaymentTransaction; error?: string }> {
  // Guard against unauthenticated
  if (!customer || !customer.id) {
    return { success: false, error: 'Authentication required. Please log in before proceeding with payment.' };
  }

  // Check if simulated failure is requested
  if (input.simulateFailure) {
    // Record a failed transaction for audit integrity
    const failedTxn: PaymentTransaction = {
      id: `txn-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
      transactionReference: `TXN-2026-${Math.floor(100000 + Math.random() * 900000)}`,
      receiptNumber: `REC-FAILED-${Math.floor(100000 + Math.random() * 900000)}`,
      customerId: customer.id,
      customerName: customer.fullName,
      customerEmail: customer.email,
      customerPan: customer.panNumber,
      policyId: 'N/A',
      policyNumber: 'N/A',
      policyName: input.policyName,
      planCategory: input.category,
      paymentType: 'NEW_POLICY',
      baseAmount: input.premiumAmount,
      gstAmount: input.gstAmount,
      totalAmount: input.totalAmount,
      paymentDate: new Date().toISOString(),
      paymentMethod: input.paymentMethod,
      status: 'FAILED',
      taxDeductionSection: input.taxSection,
      notes: 'Payment authorization declined by bank gateway (User Simulation / Insufficient Limit)',
      gatewayResponse: 'ERR_CARD_DECLINED_BY_ISSUING_BANK'
    };

    const currentPays = getCustomerPayments(customer.id);
    saveCustomerPayments(customer.id, [failedTxn, ...currentPays]);

    return {
      success: false,
      payment: failedTxn,
      error: 'Payment failed. Please try again. (Bank gateway reported authorization decline)'
    };
  }

  // 1. Generate unique identifiers
  const policyNumber = `POL-${Math.floor(100000000 + Math.random() * 900000000)}`;
  const txnRef = `TXN-2026-${Math.floor(100000 + Math.random() * 900000)}`;
  const receiptNo = `REC-2026-${Math.floor(100000 + Math.random() * 900000)}`;
  const bankUtr = `RBI-NEFT-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(10000000 + Math.random() * 90000000)}`;
  const now = new Date();

  const startDateStr = now.toISOString().split('T')[0];
  const maturityDate = new Date(now);
  maturityDate.setFullYear(maturityDate.getFullYear() + input.policyTermYears);

  const nextDueDate = new Date(now);
  nextDueDate.setFullYear(nextDueDate.getFullYear() + 1);

  // 2. Create User Policy
  const newPolicy: UserPolicy = {
    id: `usr-pol-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
    customerId: customer.id,
    customerName: customer.fullName,
    customerEmail: customer.email,
    policyNumber,
    policyId: input.policyId,
    policyName: input.policyName,
    category: input.category,
    sumAssured: input.sumAssured,
    premiumAmount: input.premiumAmount,
    gstAmount: input.gstAmount,
    totalPremiumPayable: input.totalAmount,
    premiumFrequency: input.premiumFrequency,
    startDate: startDateStr,
    maturityDate: maturityDate.toISOString().split('T')[0],
    nextDueDate: nextDueDate.toISOString().split('T')[0],
    status: 'Active',
    nomineeName: input.nomineeName,
    nomineeRelation: input.nomineeRelation,
    paidInstallments: 1,
    totalInstallments: input.premiumPayingTermYears,
    accumulatedBonus: 0,
    surrenderValue: 0,
    paymentMethodLastUsed: input.paymentMethod,
    taxBenefitSection: input.taxSection
  };

  // 3. Create Successful Payment Transaction
  const newPayment: PaymentTransaction = {
    id: `pay-txn-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
    transactionReference: txnRef,
    receiptNumber: receiptNo,
    customerId: customer.id,
    customerName: customer.fullName,
    customerEmail: customer.email,
    customerPan: customer.panNumber,
    policyId: newPolicy.id,
    policyNumber: newPolicy.policyNumber,
    policyName: newPolicy.policyName,
    planCategory: input.category,
    paymentType: 'NEW_POLICY',
    baseAmount: input.premiumAmount,
    gstAmount: input.gstAmount,
    totalAmount: input.totalAmount,
    paymentDate: now.toISOString(),
    paymentMethod: input.paymentMethod,
    status: 'SUCCESS',
    bankRefNumber: bankUtr,
    taxDeductionSection: input.taxSection,
    notes: `Initial Policy Issuance Premium (Installment 1/${input.premiumPayingTermYears})`,
    gatewayResponse: 'SUCCESS_200_AUTHORIZATION_VERIFIED'
  };

  // 4. Persist to customer's policies
  const customerPolicies = getCustomerPolicies(customer.id);
  saveCustomerPolicies(customer.id, [newPolicy, ...customerPolicies]);

  // 5. Persist to customer's payments
  const customerPayments = getCustomerPayments(customer.id);
  saveCustomerPayments(customer.id, [newPayment, ...customerPayments]);

  // 6. Sync to Supabase if connected
  if (supabase) {
    try {
      await supabase.from('payments').insert([
        {
          id: newPayment.id,
          transaction_ref: newPayment.transactionReference,
          customer_id: customer.id,
          policy_number: newPolicy.policyNumber,
          amount: newPayment.totalAmount,
          status: newPayment.status,
          method: newPayment.paymentMethod,
          payload: newPayment
        }
      ]);
    } catch (e) {
      console.log('Local store primary, remote Supabase sync queued:', e);
    }
  }

  return { success: true, policy: newPolicy, payment: newPayment };
}

// -------------------------------------------------------------
// RENEWAL PREMIUM PAYMENT FLOW
// -------------------------------------------------------------

export async function processRenewalPayment(
  customer: CustomerProfile,
  policy: UserPolicy,
  paymentMethod: PaymentMethod,
  simulateFailure: boolean = false
): Promise<{ success: boolean; updatedPolicy?: UserPolicy; payment?: PaymentTransaction; error?: string }> {
  if (!customer || !customer.id) {
    return { success: false, error: 'Authentication required. Please log in before proceeding with payment.' };
  }

  const gstAmount = Math.round(policy.premiumAmount * 0.18);
  const totalAmount = policy.premiumAmount + gstAmount;

  if (simulateFailure) {
    const failedTxn: PaymentTransaction = {
      id: `txn-fail-${Date.now()}`,
      transactionReference: `TXN-2026-${Math.floor(100000 + Math.random() * 900000)}`,
      receiptNumber: `REC-FAILED-${Math.floor(100000 + Math.random() * 900000)}`,
      customerId: customer.id,
      customerName: customer.fullName,
      customerEmail: customer.email,
      customerPan: customer.panNumber,
      policyId: policy.id,
      policyNumber: policy.policyNumber,
      policyName: policy.policyName,
      planCategory: policy.category,
      paymentType: 'RENEWAL_PREMIUM',
      baseAmount: policy.premiumAmount,
      gstAmount: gstAmount,
      totalAmount: totalAmount,
      paymentDate: new Date().toISOString(),
      paymentMethod: paymentMethod,
      status: 'FAILED',
      taxDeductionSection: policy.taxBenefitSection || 'Section 80C',
      notes: `Renewal Premium Payment Failed for ${policy.policyNumber}`,
      gatewayResponse: 'ERR_INSUFFICIENT_FUNDS'
    };

    const currentPays = getCustomerPayments(customer.id);
    saveCustomerPayments(customer.id, [failedTxn, ...currentPays]);

    return {
      success: false,
      payment: failedTxn,
      error: 'Payment failed. Please try again.'
    };
  }

  const txnRef = `TXN-2026-${Math.floor(100000 + Math.random() * 900000)}`;
  const receiptNo = `REC-2026-${Math.floor(100000 + Math.random() * 900000)}`;
  const bankUtr = `RBI-NEFT-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(10000000 + Math.random() * 90000000)}`;
  const now = new Date();

  // Advance next due date by 1 year
  const nextDue = new Date(policy.nextDueDate);
  nextDue.setFullYear(nextDue.getFullYear() + 1);

  const updatedPolicy: UserPolicy = {
    ...policy,
    status: 'Active',
    paidInstallments: Math.min(policy.paidInstallments + 1, policy.totalInstallments),
    nextDueDate: nextDue.toISOString().split('T')[0],
    accumulatedBonus: policy.category.toLowerCase().includes('endowment')
      ? policy.accumulatedBonus + Math.round(policy.premiumAmount * 0.8)
      : policy.accumulatedBonus,
    paymentMethodLastUsed: paymentMethod
  };

  const newPayment: PaymentTransaction = {
    id: `pay-txn-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
    transactionReference: txnRef,
    receiptNumber: receiptNo,
    customerId: customer.id,
    customerName: customer.fullName,
    customerEmail: customer.email,
    customerPan: customer.panNumber,
    policyId: policy.id,
    policyNumber: policy.policyNumber,
    policyName: policy.policyName,
    planCategory: policy.category,
    paymentType: 'RENEWAL_PREMIUM',
    baseAmount: policy.premiumAmount,
    gstAmount: gstAmount,
    totalAmount: totalAmount,
    paymentDate: now.toISOString(),
    paymentMethod: paymentMethod,
    status: 'SUCCESS',
    bankRefNumber: bankUtr,
    taxDeductionSection: policy.taxBenefitSection || 'Section 80C',
    notes: `Renewal Premium (Installment ${updatedPolicy.paidInstallments}/${policy.totalInstallments})`,
    gatewayResponse: 'SUCCESS_200_RENEWAL_CAPTURED'
  };

  // Update customer policies
  const customerPolicies = getCustomerPolicies(customer.id);
  const updatedList = customerPolicies.map(p => p.id === policy.id ? updatedPolicy : p);
  saveCustomerPolicies(customer.id, updatedList);

  // Update customer payments
  const customerPayments = getCustomerPayments(customer.id);
  saveCustomerPayments(customer.id, [newPayment, ...customerPayments]);

  return { success: true, updatedPolicy, payment: newPayment };
}

// -------------------------------------------------------------
// CLAIM CREATION FLOW
// -------------------------------------------------------------

export async function createCustomerClaim(
  customer: CustomerProfile,
  claimInput: Omit<Claim, 'id' | 'customerId' | 'dateSubmitted' | 'status' | 'stageNumber' | 'timeline'>
): Promise<{ success: boolean; claim: Claim }> {
  const generatedClaimNumber = `CLM-2026-${Math.floor(1000 + Math.random() * 9000)}`;
  const todayFormatted = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  const estDate = new Date();
  estDate.setDate(estDate.getDate() + 5);
  const estFormatted = estDate.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  const newClaim: Claim = {
    id: `clm-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
    customerId: customer.id,
    claimNumber: generatedClaimNumber,
    policyNumber: claimInput.policyNumber,
    policyHolderName: claimInput.policyHolderName || customer.fullName,
    claimType: claimInput.claimType,
    claimAmount: claimInput.claimAmount,
    dateOfIncident: claimInput.dateOfIncident,
    dateSubmitted: new Date().toISOString().split('T')[0],
    status: 'Document Verification',
    stageNumber: 2,
    estimatedSettlementDate: estFormatted,
    hospitalOrPlace: claimInput.hospitalOrPlace,
    assignedSurveyor: {
      name: 'Rajesh Nair (Sr. Claims Auditor)',
      phone: '+91 98450 11982',
      badgeId: 'SURV-INSP-8831'
    },
    timeline: [
      {
        title: 'Claim Registered Online',
        date: `${todayFormatted}, 10:00 AM`,
        description: 'Digital claim intimation token generated with automatic pre-authorization check.',
        completed: true
      },
      {
        title: 'Document & Invoice Assessment',
        date: 'In Progress (Active Stage)',
        description: 'Uploaded medical vouchers and doctor discharge summary under automated OCR verification.',
        completed: false,
        current: true
      },
      {
        title: 'Surveyor / Medical Audit',
        date: `Scheduled within 48 Hours`,
        description: 'Hospital desk cross-check and medical ledger inspection.',
        completed: false
      },
      {
        title: 'TPA Final Clearance',
        date: `Expected ${estFormatted}`,
        description: 'Final claim amount adjudication and settlement note generation.',
        completed: false
      },
      {
        title: 'Settlement & NEFT Fund Transfer',
        date: `Expected ${estFormatted}`,
        description: 'Direct credit to policyholder registered bank account.',
        completed: false
      }
    ],
    documents: claimInput.documents || [
      { name: 'Hospital Discharge Summary', type: 'Medical Report', status: 'Verified' },
      { name: 'Final Pharmacy Bills & Invoices', type: 'Billing Document', status: 'Pending Review' },
      { name: 'Bank Account Cancelled Cheque', type: 'Banking Info', status: 'Verified' }
    ],
    notes: claimInput.notes
  };

  const claims = getCustomerClaims(customer.id);
  saveCustomerClaims(customer.id, [newClaim, ...claims]);

  return { success: true, claim: newClaim };
}

// Aliases for seamless state integration
export const getCurrentCustomerProfile = getStoredCurrentCustomer;
export const setCurrentAuthenticatedUser = saveCurrentCustomer;
export function getAllRegisteredCustomers(): CustomerProfile[] {
  return initRegisteredCustomers();
}

// -------------------------------------------------------------
// ADMIN REVIEW / DOCUMENT VERIFICATION
// These functions keep the existing offline-first architecture intact.
// They can later be swapped for Supabase table/RLS calls without changing the UI.
// -------------------------------------------------------------

export function getAllSystemClaims(): Claim[] {
  const customers = initRegisteredCustomers();
  const seen = new Set<string>();
  let all: Claim[] = [];
  customers.forEach(c => {
    getCustomerClaims(c.id).forEach(claim => {
      if (!seen.has(claim.id)) { seen.add(claim.id); all.push(claim); }
    });
  });
  return all.sort((a, b) => new Date(b.dateSubmitted).getTime() - new Date(a.dateSubmitted).getTime());
}

export function updateSystemClaimDocument(claimId: string, documentIndex: number, status: 'Verified' | 'Required'): boolean {
  const customers = initRegisteredCustomers();
  for (const customer of customers) {
    const claims = getCustomerClaims(customer.id);
    const index = claims.findIndex(c => c.id === claimId);
    if (index === -1) continue;
    const claim = claims[index];
    if (!claim.documents[documentIndex]) return false;
    claim.documents[documentIndex] = { ...claim.documents[documentIndex], status };
    const allVerified = claim.documents.length > 0 && claim.documents.every(d => d.status === 'Verified');
    if (allVerified && claim.status === 'Submitted') claim.status = 'Document Verification';
    saveCustomerClaims(customer.id, claims);
    return true;
  }
  return false;
}

export function updateSystemClaimDecision(claimId: string, decision: 'Approved' | 'Rejected'): boolean {
  const customers = initRegisteredCustomers();
  for (const customer of customers) {
    const claims = getCustomerClaims(customer.id);
    const index = claims.findIndex(c => c.id === claimId);
    if (index === -1) continue;
    const claim = claims[index];
    if (decision === 'Approved' && claim.documents.some(d => d.status !== 'Verified')) return false;
    claim.status = decision;
    claim.stageNumber = decision === 'Approved' ? 5 : claim.stageNumber;
    claim.timeline = claim.timeline.map((item, i) => ({
      ...item,
      completed: decision === 'Approved' ? true : item.completed,
      current: false
    }));
    claim.notes = `${decision} by Institutional Administrator on ${new Date().toLocaleString('en-IN')}.`;
    saveCustomerClaims(customer.id, claims);
    return true;
  }
  return false;
}
